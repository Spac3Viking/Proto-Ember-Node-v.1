# Cache Bootstrap — Green Fire Saga Smith Practice

This cache is the **Saga Smith practice pack** for the Green Fire Archive. It contains the canonical Field Rule, field exercises, seed tables, and supporting practice materials for Saga Smith play.

## What This Cache Is For

This cache provides material for:

- **Saga Smith play** — the Field Rule is the canonical instruction set for all Saga Smith sessions.
- **Seed drawing** — seven categories of procedural myth seeds for framing worlds, characters, factions, conditions, and pressures.
- **Reflection** — journaling guidance, signal thread notes, and field records.
- **Offline use** — everything needed to run a Saga Smith session without access to the live website.

## Operating Principles

1. **Seeds are not commands.** Each seed is a question pointed at the storyteller, not an instruction any system executes. The Saga Smith chooses which seeds enter play.
2. **Pressure over plot.** Green Fire sagas resolve through alignment under pressure, not through narrative completion.
3. **The Spiral is a pattern, not a sequence.** Observe → Reflect → Act → Refine → Remember → Relate may emerge through play; it is not a mandatory turn structure.
4. **Signal over noise.** When mechanics and meaning diverge, follow meaning.
5. **No prior cache required.** This cache may be used independently. No particular application or prior ingestion sequence is needed.

## How To Use This Cache

- Start with `field-rule.md` — the canonical instruction set for all Saga Smith play.
- Use `field-exercises.md` for ready-to-play opening exercises.
- Draw from the seed documents as needed. Do not load all seeds at once — draw 1–3 from relevant categories per session.
- Consult `reflective-journaling.md` for end-of-session reflection guidance.
- Review `signal-threads.md` if you choose to name and preserve recurring meanings (optional).

## What This Cache Contains

- The canonical Saga Smith Field Rule and field exercises
- Seven seed categories: World, Regional, Faction, Character/Archetype, Loadout/Tool, Condition, Catalyst
- Supporting practice documents: familiarity modes, continuity pressure, reflective journaling, saga fragments, signal threads

## What This Cache Does Not Contain

- The two published Sentinel Sagas (Ash and Bloom — Volume I; Brothers Saga). Those are in the Library.
- The full Codices, Grimoire, or Symbolic Legend. Those are in the Library and Core.
- A combat or resolution system. Binary uncertainty uses coin flips or even/odd die rolls.

ᚠ
