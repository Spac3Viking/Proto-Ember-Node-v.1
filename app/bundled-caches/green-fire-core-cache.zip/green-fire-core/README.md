# Green Fire Core Cache

_Version 1.4 · Updated 2026-04-26_

## What This Is

This is the **Green Fire Core Cache** — the default trusted seed archive for a new Ember Node. It is the Node's first body of knowledge: foundational codices on Green Fire, Myth-Tech, the Triform system, Living Sagas, Runelore, collapse and continuity, Sentinel lineage, the **Sentinel Armory** (philosophy, ethics, and tactical frameworks for the prepared individual), and the **Green Fire Dialogues** (signal across time, carried by story and symbol); the first Grimoire; and a full reference set including the archive orientation, glossary, symbol index, the **Symbolic Legend** (runes, elemental glyphs, alchemical and hermetic symbols with Green Fire interpretations), and the Mythic Mirror Seed.

**Bundled Core = seed memory.** **Archive caches = living updates and expansions.**

If you are setting up an Ember Node for the first time, this cache is the starting point. Later, pull additional caches from the Green Fire Archive to expand the Node's knowledge.

## Green Fire Orientation

Green Fire is a living philosophy and archive framework blending symbolic literacy, practical resilience, story, AI reflection, and grounded action. It is not a doctrine or authority system — it is a body of signal meant to be read, questioned, adapted, and refined.

## The Triform System

- **Codices** — teach principles, tools, and frameworks.
- **Sagas** — transmit meaning through story, mythic realism, and symbolic memory.
- **Grimoires** — guide reflection, practice, journaling, and personal refinement.

## Saga Seeds

Saga Seeds are modular narrative engines for creating stories, roleplay sessions, reflections, and symbolic scenarios. They help users build _living sagas_ rather than only reading finished ones — designed to work with AI-assisted storytelling and Ember Node workflows.

## Mythic Mirrors and Ember Node

Mythic Mirrors frame AI as a reflective companion: a mirror, not an oracle. Ember Node is the local-first AI / archive / workshop system designed to carry Green Fire context offline. These cache files can be used with Ember Node, or uploaded into any AI chat alongside the **Mythic Mirror Seed**. The AI's role is to refine the user's own signal — not replace human judgment.

## Ember Node Placement

Place or merge contents into:

```
Ember-Node-Data/archive/core/
```

After placement, Ember Node will recursively walk this folder and read `manifest.json` plus all Markdown files automatically.

## Portable AI Use

You may also upload these Markdown files into any AI chat along with the **Mythic Mirror Seed** to grant that AI Green Fire-aligned context.

## Contents

**Codices** (12)
- `codices/codex-green-fire-first-spark.md`
- `codices/codex-green-fire-philosophy.md`
- `codices/codex-myth-tech.md`
- `codices/codex-signal-and-flame.md`
- `codices/codex-sentinel-armory.md`
- `codices/codex-green-fire-dialogues.md`
- `codices/codex-green-fire-ontological-framework.md`
- `codices/codex-grimoire-codices-sagas.md`
- `codices/codex-living-sagas.md`
- `codices/codex-runelore.md`
- `codices/codex-fractured-earth.md`
- `codices/codex-green-fire-sentinels.md`

**Grimoires** (1)
- `grimoires/grimoire-green-fire-grimoire.md`

**Reference** (5)
- `reference/reference-archive-orientation.md`
- `reference/reference-green-fire-glossary.md`
- `reference/reference-symbol-index.md`
- `reference/reference-symbolic-legend.md`
- `reference/reference-mythic-mirror-seed.md`

## License

Released under the **Green Fire Covenant** / Creative Commons **BY-NC-SA**.
Share freely, adapt carefully, do not commercially exploit without consent, and preserve attribution.
