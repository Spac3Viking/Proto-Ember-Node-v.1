# Level 1 — What is Green Fire?

Green Fire is a collection of stories, ideas, tools, and conversations designed to help people think more clearly, learn from experience, and stay connected to what matters.

At its heart, Green Fire is built around a simple belief:

> Wisdom comes from experience, reflection, and action.

Many people spend their lives collecting information. Green Fire is more interested in helping people use information.

## A Typical Green Fire Cycle

1. Experience something.
2. Reflect on it.
3. Try something.
4. Observe the results.
5. Share what you learned.

Then repeat.

The stories, codices, archive, and AI tools all exist to support that process.

## How People Use Green Fire

Some people use Green Fire for:

- writing stories
- journaling
- philosophy
- preparedness
- personal growth
- creativity
- teaching
- exploring ideas

Others simply enjoy reading the stories and reflections.

## What Green Fire Is Not

Green Fire is not a religion. It is not a political movement. It is not an ideology.

It is an ongoing experiment in learning, reflection, and practical wisdom.

The goal is not to tell people what to think. The goal is to help people notice more, think more deeply, and participate more fully in reality.

Everything else grows from there.

---

*Stewarded through the Green Fire Archive. Distributed for reflection, participation, continuity, and long transmission.*
