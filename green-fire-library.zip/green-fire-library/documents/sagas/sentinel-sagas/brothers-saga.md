---
title: "ᛋ: Brothers Saga"
description: "Two brothers venture beyond the tree line and find themselves aboard a battle train, discovering what it means to earn your place"
category: sentinel-sagas
order: 2
---

# The Brothers Saga

## Chapter I — Into the Tree Line

Dawson wasn't much to look at on a map—wedged between an old highway and an even older rail line. But in the Turning, that obscurity became a blessing.

Some towns died. Others faded away. Dawson adapted.

The adults still spoke of the time "before," when screens flickered and engines hummed past endlessly. But Felix and Sam, twelve and ten, had only faint memories of that world—flickers of blue light, the sound of sirens, and the glow of far off fires lighting the sky on quiet nights. What they knew now was simpler. Sturdier. Gardens, trading, hunting. Neighbors who waved. Watch rotations. Rail deliveries. And chores—always chores.

This morning, the boys had earned their freedom. Felix had checked the fences and stacked the firewood. Sam fed the hens, then oiled the gears and wound the springs on the torsion generator. Just like their dad taught them—slow, steady, no wasted motion.

Earlier today around sunrise, they waved goodbye and watched their dad walk down to the small rail station in Dawson. The tools he took with him were always different depending on his job that day. The boys never knew what he would be doing next. Only that he would return with stories of the things he fixed and the people he met, and sometimes, eyes that had seen more than he let on. Today they saw him leave carrying a lumpy old green sea bag, they could only guess what was doing that day. When they asked he simply said "Not really sure, but I'll let you know when I get home, love you guys be good for your mom!"

Now, mom and their little sister Nora were inside cleaning up after breakfast.

"Back by sundown," Mom said to them when they headed back outside, wiping her hands on her apron as she continued drying dishes and putting them away.

"Okay mom, love ya!" They both replied, but Sam had other plans.

---

"Let's cut past the tree line," Sam whispered as they crossed the backyard. "Farther than last time."

Felix stopped. "That's not the deal."

"Come on," Sam grinned, as he started walking. "You said we could do some recon after chores."

"Scout the perimeter. Not disappear into the woods."

Sam, broad and stocky, already had a small pack on. Water, knife, dried apple slices. He patted his blowgun—strapped snug alongside the quiver of darts he'd whittled himself.

"We'll be back before dark."

Felix sighed. He was taller, wiry, always watching. "You just want to find that old track again."

"Maybe." Sam shrugged.

"I'm serious, Sam. You know what Dad said about going too far."

Sam looked up. "Yeah. Don't go alone."

Felix groaned. Sam grinned wider.

So Felix adjusted the slingshot in his belt and followed his brother. Not because he wanted to—but because if he didn't, he knew his brother would get into trouble by himself and he'd get in trouble for letting him go.

---

The woods behind Dawson weren't wild, not exactly. Locals foraged them for mushrooms, herbs, old fence posts. But there were pockets—overgrown, inaccessible—where the boys imagined strange things slumbered beneath the leaves. Sam led them toward one of those now, feet light, eyes scanning like their father had shown them.

"See that groove?" Sam pointed to a sunken rut, moss-grown. "Old rail line."

"Maybe, looks like it hasn't been used in a while" Felix muttered, his attention piqued. Living near the rail line through Dawson he'd been a train enthusiast since he was a baby.

"Well maybe it still leads to somethin." Sam suggested.

They followed it for what seemed like miles. Branches scraped their sleeves. Birds fluttered overhead. Somewhere behind them, a woodpecker knocked in rhythm.

Sam moved like a fox, crouching to test the ground, checking for fresh prints. He didn't say it, but part of him hoped they'd find something exciting—something forgotten. A treasure. A secret. A piece of the old world.

What they found was stranger.

At first it was just scraps: twisted sheet metal, rusting vehicles, a lone bucket from an excavator. Then the trees thinned and the path widened. Vines curled around a crumpled loader. More wreckage. Old machines scattered like the bones of giants.

Felix slowed. "This isn't some farmer's junk. This is a scrapyard."

Sam stepped forward, eyes scanning. "Think it's abandoned?"

"Maybe."

That's when they saw the wall—just barely visible between the trees. Scrap stacked high, braced with steel beams and logs. Not just dumped—built. Like a fortress.

Felix pulled Sam behind a tangle of brush. "Wait."

"I just want to—"

"Shh."

Voices.

Close.

Rough. Not angry. But not kind either.

Sam froze.

Felix's hand went to his slingshot.

The brothers ducked behind a hollow shell of an old semi trailer. They crouched there, breath shallow, eyes wide.

Someone was coming.

---

## Chapter II — Scrap and Signal

The voices were getting closer.

Felix didn't panic. He tapped Sam once on the shoulder—soft, quick. Sam nodded.

The boys moved fast, silent. A signal they'd practiced a hundred times in games with their Dad.

"Leave something visible," Felix whispered.

Sam slid his pack halfway out from behind the wrecked trailer, making it look like they were hiding. Then they slipped back ten feet behind a pile of overgrown axles for cover and dropped low, breath slow.

Their dad had a silly name for the trick: bamboozled. Make them look where you were, not where you are. He got them with it all the time when they played hide and seek. Now they were putting it into action.

Two figures emerged into the clearing—one tall and broad, the other shorter, features obscured under their patchwork armor.

"Got somethin," the tall one said, gesturing toward the fake hide. "Over there, go slow."

They approached.

Felix gave a hand sign.

Sam nodded.

The moment one of the men leaned toward the bag, Felix stepped out with his slingshot drawn. Sam followed a second later, blowgun raised.

"Back up," Felix said, steady.

The tall man froze. Then… chuckled.

"Clever," he said. "Very clever, you got us."

He pulled back his hood, his face was leathered from years working outside, jaw bristled with gray stubble. His jacket was pieced from old workwear and armored plates. His partner lifted a welding mask to reveal that he was young, probably only a teenager.

"You boys must be from Dawson," the tall man said.

The boys didn't lower their weapons.

"Easy," he said. "Name's Cliff. No one's gonna hurt you."

Felix narrowed his eyes. "How do you know where we're from?"

"I don't—not exactly. But Dawson's not far. Good people. Nice place. I figured the only kids bold enough to sneak through the woods and make it this far had to be from there."

"Why does that matter?"

Cliff shrugged. "Because Dawson's Sentinel country."

Sam blinked. "What's that supposed to mean?"

Cliff smiled, not unkindly. "Means you've probably got more skills and common sense than most grown men. And you don't trust easy. Which is wise."

There was a long pause.

Then Felix slowly lowered his slingshot. "You really not gonna hurt us?"

"Not unless you start it." Cliff replied with a smirk.

Sam grinned.

Cliff waved them forward. "Come on. You've earned a look around. Might even learn something."

---

The scrapyard wasn't just junk. It was structured. Machinery positioned like pieces on a board. Shipping containers stacked into towers. Cranes turned into perches. Tunnels formed from hollowed mounds of junk. Every pile had purpose.

"I was a heavy equipment operator once," Cliff said as they walked. "Back before everything fell apart. I watched cities eat themselves trying to pretend nothing was wrong. So me and a few buddies came out here and built a little paradise for ourselves."

"You live here?" Sam asked.

"Some of us do. Some just pass through. We keep to ourselves. Fix what we can. Salvage what's useful. Teach those who wanna learn."

They passed a workshop with an open garage door. Kids that couldn't be much older than Felix were working on the engine of a massive wheeled loader with a battering ram instead of a bucket.

"You trained them?" Felix asked.

"They teach themselves. I just give 'em tools and show them where to start."

They passed through a gate bristling with rail spikes welded together like thorns. Beyond it was a camo netting canopy stretched wide, shading a track spur… and there it was.

The battle train.

It stood quiet, like a sleeping dragon. Armor-plated. Heavy. Powerful. The engine had a spiked plow that looked like it was the jaw of a metal beast. Behind the locomotive were two boxcars and a caboose all heavily armored with slit window firing positions, crenellations along the top of all the cars, with a walkway connecting them. The scent of grease, smog, and hot metal hung in the air.

Sam stopped in his tracks. "That thing runs?"

Cliff smirked. "Better than you'd think. She's headed east in twenty. Your town's on the line, want a lift?"

Felix looked up at the massive machine, engine humming low beneath the steel skin.

"You mean we can ride that?"

"You've earned it. You found the Yard. You caught us by surprise and held your ground. That's rare. That's… Sentinel stuff."

He paused, then added, "We've got room up front. But you took the old line through the woods to get here, the only usable tracks loop back around to Dawson, I hope you don't mind a long trip."

Sam's face lit up like sunrise.

Felix gave a half-smile. "You sure it's alright?"

Cliff looked them both in the eye. "Boys like you? You walked far, trust me, you earned a ride back home. Come on."

Behind them, as the crew started loading up, the battle train's engine roared to life as it belched out a plume of smoke—ready to carry them home.

---

## Chapter III — Smoke on the Line

The train moved like a beast remembering how to run as it was soon galloping along the tracks through the woods.

Sam leaned out the side hatch, wind whipping through his hair, eyes wide as the treeline blurred into motion. Felix stood across from him, legs braced, watching the dials on the forward console flick and twitch like blinking eyes.

Cliff stood near the engine controls, hand on a throttle lever made from an old wrench, his face stoic with focus.

It wasn't a passenger liner. This train was a weapon.

"She doesn't go too fast," Cliff said. "But she'll go through anything."

He explained to the boys how he had found this old freight train on a track near the scrapyard. They overhauled it and tuned its old V16 EMD 710 to run on biodiesel that they could get from the local communities along the line, like Dawson. The engine was common so it was easy enough to find spare parts. Then they made the armored boxcars and a matching caboose. Complete with bunks, a workshop, armory, observation deck, heavy weapon mounts, and storage. He showed them how all onboard systems and weapons ran off of the locomotive's electrical and air systems. Giving it powerful communications, jamming, and targeting capabilities coupled with high powered pneumatic and gauss cannons. Cliff excitedly explained how all the exterior launchers had adjustable breeches to shoot any scrap rail components such as spikes, base plates, or even sections of rail. They could be shot spinning like a top or straight like a dart. To demonstrate he radioed the roof gunner for a test fire off the port side. The boys were amazed as they watched a large boulder explode when it was struck by the first shot with a resounding "Clang".

---

After the display of firepower, the ride was relatively quiet and the boys enjoyed the scenery—clustered pines giving way to rolling fields and rusted radio towers half-swallowed by green. Sam pointed out deer and old fence lines. Felix noticed the discipline of the crew—quiet, alert, watching.

About half an hour in, the mood suddenly shifted. A persistent buzz echoed through the comms bay. One of the younger operators grabbed a headset, adjusted dials, and nodded toward Cliff.

"Callsign Elhaz. Six miles South of the junction, past the Quarry."

Cliff didn't speak. He took the headset, listened. His brow furrowed.

Then he looked at the boys.

"You two alright with a detour?"

Felix glanced up. "What kind?"

Cliff exhaled through his nose. He spoke so everyone in the control room could hear him over the roar of the engine behind them. "Emergency extraction. Sounds like a few Sentinels got drones on their tail out near the watershed junction. We're the only rig close enough to make it before sundown."

"Drones?" Sam asked.

"A lot of mercenaries and remnant forces like to send in their toys to do the dirty work for them nowadays. They've been using drones to harass the locals into leaving. I'm guessing these sentinels got in the way."

The train's cabin tensed.

The boys had heard similar stories from their dad. But they didn't realize it was happening this close to home.

"They know we're coming?" Felix asked.

Cliff cracked a small grin. "We'll be hard to ignore."

---

They changed tracks at an old switch, passing through a tunnel of trees that stank of rot and old tires. The forest grew darker here. Tighter. More quiet.

Cliff handed Felix a folded map. "Keep an eye on the land as we roll. If we have to stop, I need to know exactly where we are."

Felix opened it with care and started examining the terrain.

To Sam, he handed a small pouch. Inside: crimpers, bolt cutters, wrenches, and various metal fittings.

"What's this for?" Sam asked.

"Just in case," Cliff said. "Do you like tinkering?"

Sam smiled. "I watch my Dad make stuff out of scrap and junk all the time."

Cliff nodded, serious. "Good. Get ready you may need to put that stuff to use."

---

The train rolled deeper into the quiet countryside.

The boys were no longer just passengers.

Now they were part of the crew.

In the distance, a low column of smoke rose—thin and gray, barely visible against the pine ridges. Felix tried to find where it could be on the map. Sam watched the tree line. Cliff leaned forward on the throttle.

No one mentioned the word battle.

But the rumbling steel beneath them felt like it knew what was coming.

---

## Chapter IV — Breakthrough

The train rolled to a halt at the watershed junction, air brakes hissing from the undercarriage like a snorting beast of burden. The tracks ahead split into broken spurs. Trees loomed close. Rusted towers leaned over the clearing like old watchmen standing guard.

Cliff stood at the console. "Elhaz's last call was north of this area. This is as close as we can get. Everyone—horns primed, flare launchers and weapons ready."

He turned to Sam. "Go with the ground team to car two. Look for a red panel, that's the defensive cache. Inside you'll find a spool of eighth-inch steel cable. Grab it and go with the ground team."

Sam blinked. "Go outside?"

"Yeah. We're locking down the perimeter."

Sam headed towards the back of the train with the ground team.

Cliff keyed the radio. "Hammerhead Actual to Elhaz. You still active? Confirm you can reach the rail spur."

Skrrtchhhh—krrrk.

Then, faint:

"…bearing south west… drones disengaged… still moving… need—"

Signal gone.

Cliff grunted. "Lost em."

He turned to Felix. "How's the map look? Is this rise to our east here a ridge?

Felix nodded. "Yeah, it looks like the hill east of us curves to the north. It's flat to the west."

"Okay the sentinels are coming from the north so this hill must be blocking their signal. He's gonna follow you up there so he can get talkin to 'em." Cliff said pointing his thumb at the radio operator readying his gear and grabbing a rifle from the rack by the hatch.

"You lead the way, kid." He said as he turned the latch and opened the door. He was wearing light patchwork industrial steel armor on his shoulder and knees. Work coveralls with a belt and harness for his radio equipment, batteries, and ammo, he wore no helmet only a faded trucker hat and headphones. He couldn't have been older than twenty.

They stepped outside and climbed down quickly before Felix took off with the operator on his heels. They scrambled up the shale and pine-needle slope, boots slipping, hearts pounding. Felix didn't know what he'd find. But he knew he wanted to help.

---

Sam found the cable spool, it had a rope looped through the middle, he slung it over his shoulder and followed the ground team out.

Cliff stepped out onto the catwalk on the side of the engine to talk to the gathered crew that were standing in a rough arc around the locomotive. "Alright you know the drill, we don't want 'em getting anywhere near the train so string up some cable and toss out the caltrops along these avenues of approach." He motioned with his arm to the pitiful trees along the sides of the track.

Sam went over by a crewman to hand over his roll of cable. He wasn't too old, maybe mid late teens but he looked like he knew what he was doing. Without a word, he grabbed the crimpers from Sam's hand and showed him how to wrap the cable around the tree, and squish the metal fittings over the cable to hold it tightly looped. Then handed the crimpers back to Sam and told him to secure the rest of the trees along the train. Sam was all too happy to put these new tools and skills to use.

---

Cliff's voice snapped through the train's loudspeakers. "Ground crew back on board, battle stations." Once everyone was on board they heard from the other crew that ground drones had been spotted with the scopes.

"Let 'em know we're ready to go." Cliff said over his shoulder as he looked out a window slit. The nearest crewman pulled the cord hanging from the ceiling.

The train roared so loud it startled Sam inside the control room.

9 horns blown in unison—three low, three sharp, three impossibly deep—shook the clearing. Birds scattered. Loose rust jumped from beams. It was a thunderous cacophony that was reminiscent of a beast from a primordial age.

Felix was midway up the hill so he barely had time to think before he clamped his hands over his ears, he loved trains and he'd heard plenty up close, but never one that loud.

Minutes later, the mercenary drone buggies appeared from the west—three of them—low, sleek, sand-colored rigs with angular armor and silent engines. They came fast. Not bothering to hide. They didn't have visible weapons which meant they were likely suicide drones, now headed for the train.

"Flare volley!" Cliff barked.

Dozens of magnesium flares launched in staggered arcs—some screaming into the air, some fired just ahead of the approaching buggies. The forest lit up like midday. Sparks rained, white-hot and searing.

One buggy faltered, swerving wide, its sensors momentarily overwhelmed.

Another veered toward the left side of the engine.

One of Sam's wires snapped tight.

THRANG—WHAM!

The buggy's axle caught hard. It twisted violently, skidded sideways, and slammed into a stump, its wheels spinning helplessly in the mud, it self-detonated but was far enough away to leave the train unscathed.

Cliff glanced back. "Nice work ground crew."

Sam peeked around his shoulder to look through the window at the billowing smoke as he heard shrapnel from the drone raining down on the train's armored skin, his heart was pounding. "Thanks…"

Cliff turned forward and keyed his intercom handset. "Gauss cannon—ready. Target the second buggy."

The train's magnetic cannoneer released the charge built up in a series of capacitors that fed the powerful gauss cannon. Sam watched a hunk of metal blur out away from the train impossibly fast.

WHOOMPH! CRACK!

The shot lanced through the second buggy's body housing, cleaving it apart. The vehicle bucked, turned, and crashed into the underbrush in a cloud of smoke.

The third rig, paused at the treeline.

Its lights blinked out as it turned and headed north up into the brush covered ridge.

---

Up on the eastern ridge, Felix reached the shelf and helped the operator unfold the antenna. The static faded.

A voice came through—closer now. Tighter.

"…north shelf still clear. Three on foot. We're goin slow. Keeping overwatch for drones."

The young operator keyed the radio back to the train. "Cliff. Got them. Bearing two-one-zero. Closing fast. Sounds like they're still fightin."

Felix heard distant gunshots as if to punctuate the operator's words.

"Visual?" Cliff asked.

"Confirmed." The operator said as he stood shading his eyes to get a better view of the distant figure.

Felix followed his gaze along the ridgeline until he spotted the movement too.

The front figure climbed into view from the northern crest of the ridge—cloak whipping in the wind, rifle held in one hand as he climbed behind a boulder. Looked like he was getting into a good firing position to cover the others coming up behind him.

Felix's chest froze. He didn't blink.

He didn't need to see the face.

He knew the shape of that movement. The rhythm of it.

He swallowed hard and didn't speak.

---

Back at the train, a few minutes later, Cliff and Sam stood on the catwalk of the engine.

They could barely see the figures making their way down the slope through the tangle of branches. Gradually emerging from the brush about fifty yards from the front of the locomotive.

Breaking through the last few branches, the three Sentinels finally burst into the clearing. One was limping, helped by the second. The third was catching up to them after just pulling out of his overwatch position. They were half way back to the train as the last drone buggy, now riddled with fresh bullet wounds, jumped from the brush at full speed near where the sentinels just emerged. It had quietly followed their trail and was trying to eliminate them now before they escaped.

Cliff moved fast, jumping forward, grabbing the handles as he lowered the barrel of the pneumatic spike cannon mounted to the railing. He sent a hail of railroad spikes whizzing past the sentinels to obliterate the approaching buggy behind them. It was so mangled by the lumps of metal it didn't even detonate.

One of the crew dropped a side ramp

The first two climbed without hesitation.

The last paused. Eyes scanned the train.

He saw Sam—near Cliff and the deck gun.

Then Felix—descending the slope with the radio operator. Folded antenna in hand.

The Sentinel didn't flinch.

Didn't speak.

But for a second, he paused.

He took a deep breath.

Then he turned and walked straight to Cliff.

The crew parted.

The two men stood face to face at the top of the ramp.

Cliff's mouth broke into a toothy grin. "Flame alive. You made it. We caught your last call and pushed hard."

The Sentinel's voice was calm, low, clipped.

"What are these kids doing here?"

Cliff didn't flinch. "They're part of my crew."

A beat passed. The Sentinel's jaw tightened.

"This isn't a joke, they're too young."

"They did fine. They held their ground. And they earned their place." Replied Cliff.

Cliff then went on to tell him what had happened that day, from the late morning in the scrapyard until now.

No names spoken.

Only a conductor's pride in his crew.

Felix and Sam stood still—close enough to hear it all.

Their father looked around at the crew, gave a nod. Then toward them.

Finally—

he turned back to Cliff.

"Thanks for the lift."

And stepped aboard.

Cliff exhaled through his nose, muttering to himself.

"…Flame alive."

---

## Chapter V — Sunset Run

The train rolled steady along the eastbound line again, wheels humming, the last flares of day flickering against its steel skin. Pine gave way to pasture. The air smelled of soil and sun-warmed grasses.

Inside the forward box car, the three of them sat quietly on a bench. The other two sentinels were in the crew compartment visiting the medic.

Felix on the left. Sam on the right. Their father between them.

He still hadn't taken off his cloak. His rifle rested across his knees. He stared ahead for a long while before finally speaking.

"So."

Felix and Sam both looked up.

"You're going to tell me exactly how you two boys ended up riding a battle train into an extraction zone."

Sam shrugged. "We finished our chores."

Felix added, "And we were just doing some recon."

"Recon?" the man repeated.

Sam nodded. "We found the scrapyard by accident."

Felix glanced down. "We didn't mean to go this far."

"Are we in trouble?" Sam asked flatly.

There was a pause.

Then their father leaned back against the hull, arms crossed, exhaling through his nose.

"Well," he said, "You tell me."

The boys waited.

"You went way farther than I ever allow, You apparently snuck into a scrapyard fortress, and hitched a ride on a battle train..."

Sam winced.

"Then you joined its crew in battle, and went outside unarmed to establish comms? you definitely could have gotten yourselves killed." He said looking at each of them solemnly

They replied, resigned to whatever fate was in store. "Yes, dad."

The man nodded slowly.

Then a long silence.

Finally, he leaned forward, looked at both of them again.

"I'm proud of you boys."

Sam grinned. Felix relaxed and smiled.

"But," their father added quickly, voice low and serious again, "Don't ever take pride in battle. You take pride in how you carry yourself during it."

He looked at Sam. "You did a man's job, used what you knew."

Then to Felix. "You did what needed to be done. You didn't hesitate."

Another pause.

"Honestly you guys saved me, thank you." He said genuinely before he continued.

"I don't know how I'm gonna explain this to your mom."

The boys both laughed.

Felix said, "We won't tell her yet."

Sam added, "At least not tonight."

Their dad nodded. "That's the first smart decision you've made all day, I'll tell her when the time is right."

---

The train slowed as Dawson came into view.

The town looked golden in the last light—quiet fields, soft shadows, the old grain silo lit like an ember. From this side, nothing looked changed.

The engine pulled into the side rail and eased to a stop with a gentle hiss.

The boys stood. Their dad stood beside them.

Cliff was waiting by the door. He gave the three of them a short nod.

Their dad gave one back. "We'll talk later."

"You know where to find me," Cliff said. "Bring them by sometime, I'll let 'em turn some wrenches."

"I just might." He said with a faint smile

He turned to his two Sentinel brothers who were staying with the train. "I'll see you gents tomorrow." They exchanged a nod and a warrior's handshake, clasping forearms.

Their dad turned back to the boys and the three of them stepped off the train.

The gravel crunched beneath their boots. The air was cooler now that the sun was dropping below the trees, shadows stretching long across the road toward home.

No one said much.

But as they walked—

Side by side, boots in step, dusk at their backs—

Felix looked up.

"Dad?"

"Yeah?"

"Next time… can we shoot the guns?"

Their father looked at him.

"Next time," he said, "you two are staying home."

Sam grinned. "Sure, Dad."

And they all agreed—

they definitely would tell Mom.

When the time was right.
