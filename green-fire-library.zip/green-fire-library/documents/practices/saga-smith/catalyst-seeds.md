# Catalyst Seeds

*Why the Story Can No Longer Wait*

The moment the spiral begins. Catalysts include: discovery of forbidden knowledge, AI awakening, faction betrayal, environmental collapse, death of a mentor, arrival at a sealed vault. Catalysts are rarely quests or "calls to adventure." They are interruptions.

## Seeds

### 1. The Contract Offered

A job promises stability or survival—but acceptance binds the character to unseen consequences.

### 2. The Signal Detected

A transmission appears briefly, then vanishes. Someone else heard it too.

### 3. The Resource Claim

A critical resource is discovered or contested. Delay means losing leverage.

### 4. The Missing Runner

A courier fails to arrive. What they carried may matter more than their life.

### 5. The Border Incident

A small violation threatens to escalate into open conflict.

### 6. The Cache Revealed

Hidden supplies, records, or gear surface—clearly left for someone.

### 7. The Evacuation Window

A narrow chance to move people or assets before conditions close in.

### 8. The Betrayal Exposed

Proof surfaces that someone trusted has already chosen another side.

### 9. The System Fails

Power, water, defense, or automation collapses without warning.

### 10. The Call for Aid

A request arrives from a group that may not deserve help.

### 11. The Rule Broken

A foundational law or taboo is violated. Response will redefine the culture.

### 12. The Artifact Found

An object appears that changes power dynamics simply by existing.

### 13. The Forced Alliance

Survival requires cooperation with a known adversary.

### 14. The Weather Front

Environmental conditions create a narrow opportunity—or threat.

### 15. The Leadership Death

A central figure is removed suddenly. Authority fractures.

### 16. The AI Awakens

A dormant system begins issuing guidance—or warnings.

### 17. The Lie Confirmed

A long-held belief is proven false. Adaptation is painful.

### 18. The Child Taken

Someone vulnerable is removed or threatened, demanding response.

### 19. The Route Opens

A previously impassable path becomes available—for now.

### 20. The Reputation Tested

Past actions catch up. Trust or fear precedes arrival.

### 21. The Silent Approach

An unseen force moves without warning. Preparation time is minimal.

### 22. The Moral Line

Success requires crossing a boundary once believed absolute.

### 23. The Offer of Power

Control is within reach—at a cost that won't be paid immediately.

### 24. The Countdown

An irreversible event is approaching. No one agrees on the solution.

### 25. The Message from the Past

Records, journals, or AI logs surface, reframing current choices.

### 26. The Encroachment

Another faction expands into contested space, intentionally or not.

### 27. The System Exploited

A loophole is discovered. Using it may break everything later.

### 28. The Return

Someone presumed dead or gone reappears with altered allegiance.

### 29. The Trial Demanded

Entry, aid, or passage requires a public test or sacrifice.

### 30. The Pattern Recognized

Repeated events reveal a larger structure. Ignoring it feels dangerous.

### 31. The False Calm

Everything is quiet—but preparations are visible beneath the surface.

### 32. The Choice Deferred Too Long

Avoidance becomes the catalyst. Consequences arrive uninvited.

### 33. The Alignment Moment

Two paths remain. One ensures survival. The other preserves meaning.

---

*33 seeds. Derived from `client/src/data/saga-seeds.ts`. Re-run `tsx scripts/build-saga-cache-content.ts` after edits.*
