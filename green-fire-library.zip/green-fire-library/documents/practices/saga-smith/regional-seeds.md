# Regional Seeds

*Terrain as actor*

Regions are constraints, not backdrops. Examples: Frozen agricultural heartlands, smog-choked megacity basins, wind corridors and sky routes, desert bunker zones, forested enclaves and river networks. Each Regional Seed encodes: resource flows, tactical realities, cultural adaptations, and environmental memory.

## Seeds

### 1. Frozen Breadbasket

Once the agricultural core. Vast fields lie fallow beneath snow and ice. Grain silos are fortresses. Winter decides who eats.

### 2. Smog Basin

A lowland trapped beneath permanent pollution. Light is dim. Masks are heirlooms. Children don't know the color of the sky.

### 3. Reclaimed Suburb

Cul-de-sacs swallowed by forest. Homes repurposed into longhouses. Lawns turned gardens. Streets are now hunting paths.

### 4. Dead Interstate

A cracked highway stretching for hundreds of miles. Trade caravans move like blood through an artery that might clot at any time.

### 5. River of Bones

A once-great river reduced to shallow channels. Control of crossings means power. Old bridges are contested ground.

### 6. The Quiet City

A metropolis that never fully collapsed—just emptied. Lights flicker on timers. Wind moves papers through empty streets.

### 7. Wind Corridor

High plains or ridgelines where wind never stops. Ideal for power generation and flight—but brutal to inhabit.

### 8. Ash Forest

Trees stand blackened but alive. Soil is fertile and toxic. Fire is both memory and threat.

### 9. High Ground Enclave

Mountain settlements accessible only by narrow passes. Secure, isolated, and one bad winter away from starvation.

### 10. Floodplain Ruins

Seasonally submerged cities. Navigation shifts with the waterline. Old maps lie.

### 11. Salt Flats

Blinding white expanses where sound travels for miles. Easy to spot intruders. Impossible to hide mistakes.

### 12. Industrial Wound

A region poisoned by refineries, mines, or reactors. Survival requires adaptation—or mutation.

### 13. Rail Spine

An operational rail line kept alive through ritual maintenance and scavenged parts. Whoever controls it controls movement.

### 14. Forest Enclave Network

Hidden communities linked by trails, signals, and trust. Outsiders rarely see the same path twice.

### 15. Sky Routes

Invisible highways used by gliders, drones, or airships. Weather and altitude are the real gatekeepers.

### 16. Bunker Belt

A region dense with sealed facilities. Each promises safety. Most deliver something else.

### 17. Dry Basin

A cracked lakebed turned settlement. Water is hauled from afar. Dust storms erase footprints and history alike.

### 18. Scrap Sea

Endless fields of wreckage—cars, machines, twisted steel. A resource trove and a death trap.

### 19. The Borderlands

A liminal zone between factions or biomes. Law is temporary. Reputation matters more than force.

### 20. Blackout Zone

A place where electronics fail unpredictably. Either due to interference, damage, or something watching.

### 21. Old Growth Refuge

Ancient forests spared by collapse. Rare species thrive. Entry is restricted—by people or by something older.

### 22. Agrarian Holdfast

Low-tech farming region using pre-industrial methods. Stable, slow, and suspicious of outsiders.

### 23. Collapsed Coast

Rising seas swallowed ports and cities. Boat travel dominates. Land claims are fluid—literally.

### 24. Skyline Graveyard

A cluster of skyscrapers stripped for materials. Vertical movement defines class and danger.

### 25. Weather Front

A migratory region where storms dominate life. Communities move with the seasons to survive.

### 26. The Crossing

A single bridge, tunnel, or pass connecting two major regions. Every traveler is a negotiation.

### 27. Power Ruins

Hydro dams, wind farms, or solar arrays still produce energy—but not consistently. Control brings enemies.

### 28. Memory Ground

A place of mass death or historical rupture. People report dreams, echoes, or compulsions here.

### 29. Buried City

Urban remains beneath earth, ash, or sand. Excavation reveals both wealth and ghosts.

### 30. Trade Spiral

A rotating circuit of settlements that rely on timed exchange. Miss one stop, and the system collapses.

### 31. Cold Iron Hills

Ore-rich terrain worked by hand. Metal defines power. Tools are sacred.

### 32. The No-Man's Land

Scorched, empty, and avoided. Everyone has a story about what happened here. None agree.

### 33. The Returning Wild

A frontier where animal populations outnumber humans. Predators are patient. Survival requires humility.

---

*33 seeds. Derived from `client/src/data/saga-seeds.ts`. Re-run `tsx scripts/build-saga-cache-content.ts` after edits.*
