---
title: "ᛋᚲ᛬ Sacred Warfare"
description: "The path of the Sentinel warrior and the strategic doctrine of sacred war"
order: 5
---

ᛋentinel ᚲodex: Sacred War

I. Introduction: The Path of the Sentinel Warrior

The Flame Within the Ashes

“We did not begin as warriors. We began as watchers—of soil, of stars, of silence. And when the world began to burn, we remembered the old ways, and we lit our own fire.”

This Codex begins not with a command, but with a covenant.

To walk the path of the Sentinel is to commit your hands to the work of resistance and restoration, your eyes to the truth behind illusions, and your body to the rhythms of a world both wounded and sacred. The Sentinel is not a soldier of conquest. The Sentinel is a keeper of the flame—the Green Fire that sustains, protects, and burns clean. They are the ones who protect this realm until the others wake.

Before entering war, we become worthy.

The Role of the Warrior in the Collapse

The Sentinels emerged not during empire, but through its unraveling.

They were not formed in academies, but in fragments—cities shattered by fire, forests thinned to bone, enclaves starving in silence. From these ruins rose those who would not be controlled by fear, those who remembered the body’s wisdom, the land’s rhythm, and the stories buried beneath noise.

The Sentinel warrior exists after the myth of civilization, not as a savage but as a reclaimer. They hold what was sacred before the machines. They adapt what was useful from the machines. And they bring both into alignment.

Warfare as Sacred Necessity

To the Sentinel, war is not sport. It is a consequence—a bitter fruit grown from imbalance. Violence is not glorified, but neither is it avoided when justice or survival demands action. War is entered like a winter storm: prepared, grounded, and only when there is no other path.

Sentinels fight with the principle of minimum necessary force, maximum possible meaning. Every operation is judged not just by outcome, but by harmonics: what was protected, what was preserved, and what was planted in the aftermath.

What Makes a Sentinel?

There is no uniform, no centralized command, no oath to a nation or ideology. The only criteria are these:

        •       Discipline in body and mind

        •       Resonance with the Green Fire philosophy

        •       Service to land, Circle, and lineage

        •       Commitment to growth beyond violence

Sentinels train in weaponry and survival, yes—but also in poetry, herbalism, metalwork, breathwork, memory. A Sentinel must be a generalist in craft, a specialist in purpose, and a student always.

Archetypes of the Warrior

Every Sentinel carries within them echoes of the old archetypes. Some train toward them consciously; others discover them in fire and solitude:

        •       The Scout: fast, silent, and unseen. Merges with shadow and breeze.

        •       The Builder: makes gear, maps, and field systems. Understands the bone of the world.

        •       The Healer: carries life in their pack, calms the Circle after the clash.

        •       The Flamekeeper: the spiritual anchor, who holds the lore and light.

        •       The Warrior: one who acts when others freeze, who sees movement in chaos.

These are not fixed roles but rhythms—a Sentinel may pass through all five over the course of one mission.

The Living Codex

This text is not a law. It is a living field guide: part myth, part manual, written for the one who walks alone and for the Circle moving as one. It is to be read, tested, re-written, and ritualized.

Pages may be burned in sacrifice. Sections copied by hand into pocket books. Symbols added by the reader. This Codex is not finished—because the work of the Sentinel never is.

II. Strategic Doctrine

The War Beneath the War

Not all battles are fought with blades or bullets. The true war—the one that shapes empires, corrupts minds, and devours ecosystems—is waged in stress. In symbols. In systems. In stories.

The Sentinel sees through this. Their strategy is not domination, but disruption. Their doctrine is not to win in the old sense, but to outlast, out-think, and re-root. Strategy, for the Sentinel, is the art of moving in rhythm with imbalance, to restore equilibrium through craft, timing, and sacrifice.

The Spiral Doctrine (Fluid Adaptation)

Linear warfare—plans written in code, chains of command, fixed outcomes—died with the old world.

Sentinels operate in spirals: loops of observe → assess → act → adapt. Plans are sketches, not scripts. Every action is a probing flame—testing resistance, exposing openings, reshaping the field in real time.

Key tenets:

        •       Every plan burns after contact. Adapt anyway.

        •       Every Sentinel is a node of intelligence. Listen both inward and outward.

        •       Simplicity endures. Complexity collapses under fire.

Spiral doctrine is supported by ritual updates, where teams pause—even in the midst of retreat or regroup—to reflect, re-plan, and recenter.

Decentralization as Sovereignty

Sentinels operate in fractals, not pyramids. No cell depends on distant authority. Circles are sovereign, bonded by philosophy—not command structure.

This ensures:

        •       Resilience in the face of comms disruption or leadership loss.

        •       Trust-based decision-making: Each warrior can act decisively, grounded in shared principles.

        •       No central failure point: If one Circle falls, others continue without rupture.

Leadership is rotational and contextual. The scout leads in shadow. The tactician leads in combat. The flamekeeper leads when fear creeps in.

Environmental Mastery

The earth is not a backdrop—it is a participant.

Strategic terrain use includes:

        •       Wind timing for sound masking.

        •       Fog cycles for movement and exfiltration.

        •       Animal trails as pathfinders.

        •       Sun angle, visibility, and shadow lines for concealment during raids.

Operations are aligned with moon phases, migration patterns, and seed cycles. War does not pause the planet—it must move in ritual alignment with it.

Sentinels practice “combat gardening”—seeding plants during exfil to heal land and feed the future. Even disruption carries restoration.

Strategic Deception (The Cloak of the Flame)

To disrupt superior forces, Sentinels rely on deception as doctrine, not tactic.

Tactics include:

        •       Ghost Trails: Misdirection via layered footprints, burned herb bundles, or sound lures (aztec death whistles, digital decoys).

        •       False Camps: Staged havens filled with corpses of mannequins, abandoned gear, and blood symbols to mislead enemy scouts.

        •       Story-Seeding: Infiltrating rumors or symbolic acts into enemy territory. (E.g., leaving runes etched on command doors, or false radio transmissions of spiritual unrest.)

Deception is most effective when wrapped in ritual ambiguity—the enemy cannot tell myth from message, creation from command.

Ethical Warfare: The Boundaries of Fire

A Sentinel does not fight to annihilate. They fight to interrupt destruction and restore balance.

Rules of Sacred Engagement:

        •       No harm to the helpless—civilians, elders, children, surrendered.

        •       No cruelty for spectacle—fear may be used, but never desecration.

        •       Life must follow war—every operation leaves space for regrowth.

Sentinels often mark the perimeter of an ethical boundary with signs:

        •       Ritual ash lines: “We do not cross without cause.”

        •       Prayer cloths: Left behind at shelters or sacred zones to signify safety.

        •       Cairns with handprints: Warnings to enemies that retaliation will follow trespass.

Strategic Archetypes and Role Flow

Each Fire Circle shifts its strategy according to the dominant archetype required:

        •       The Weaver: Builds traps, misdirection layers, and pathing illusions.

        •       The Root: Anchors territory, sets watch, integrates with local ecosystems.

        •       The Ember: Directs fast action—ambush, sabotage, raid.

        •       The Smoke: Manages retreat, concealment, and exfiltration.

        •       The Flamekeeper: Grounds decisions in philosophy and clarity, prevents fracture.

Circles often enter pre-battle meditation to determine which archetype leads.

Victory Reimagined

Sentinels do not measure victory in kills, captures, or conquest. Victory is:

        •       A refugee safely guided through hostile land.

        •       A forest defended for one more season.

        •       A pipeline disabled for a moon cycle.

        •       A Circle surviving to fight again.

The war is long. The stories we tell about what matters—longer still.

III. Sentinel Tactics Manual

Tactics as Living Geometry

Sentinel tactics are not formulas. They are forms of movement shaped by intention. Each maneuver is both practical and poetic, a response to the terrain and the unseen forces moving through it—fear, silence, memory, imbalance.

To move as a Sentinel is to listen—to terrain, to the Circle, to the rhythm of the conflict. Every action is a glyph. Every formation, a prayer. Every withdrawal, a seed planted in soil still trembling.

Tactical Formations: The Fire Structures

Sentinel combat units are known as Fire Formations, reflecting both elemental purpose and cellular cohesion. Formations flow between types as missions evolve:

1. Fire Team (2–4 Sentinels)

        •       Role: Reconnaissance, infiltration, direct-action raids.

        •       Symbol: The spark.

        •       Strength: Speed, silence, autonomy.

        •       Notes: Each Fire Team is trained to operate with no external support for up to 7 days. One acts as scout, another as signaler, another as breacher. Fourth (if present) is often a medic or flamekeeper.

2. Fire Squad (5–12 Sentinels)

        •       Role: Mid-scale engagements, village defense, synchronized strikes.

        •       Symbol: The ember ring.

        •       Strength: Flexible specialization, scalable cohesion.

        •       Notes: Contains dual Fire Teams + a support triangle: engineer, logistician, flamekeeper. Capable of fracturing and reforming mid-op.

3. Fire Circle (13+ Sentinels)

        •       Role: Networked operation—multi-front campaigns, siege disruption, enclave defense.

        •       Symbol: The full flame wheel.

        •       Strength: Autonomy within complexity.

        •       Notes: Formed only for major engagements or defensive holding. Circles contain embedded healers, elders, smiths, scouts, and ritual leads. Operations are decided by resonant council, not rank.

Core Tactical Disciplines

A. Stealthcraft and Movement

Stealth is not hiding—it is becoming indistinct. Sentinels train in:

        •       Micro-movement drills: Control of breath, weight shifting, and gait variation.

        •       Environmental blending: Learning lightfall, shadow timing, and terrain shape.

        •       Sound mapping: Using running water, wind, or mechanical hum as sound masks.

        •       Shadow pairing: Moving in duos where one watches terrain and the other scans rear/flank angles.

Ritual silence may be held for hours, broken only by pre-established hand signs, rhythm taps, or light pulses.

B. Ambush and Disruption

Sentinel ambushes are layered with ecological mimicry and psychic disruption.

The Three-Point Ambush:

        1.      Blindside Killzone: Triggered only when the lead hostile unit commits to the crossing.

        2.      Cutoff Channel: Sentinels focusing fields of fire or planted traps along killzone and secondary retreat paths.

        3.      Exit Shatterpoint: Traps, caltrops, flame lines, or fireworks are released as the enemy retreats—turning exit into chaos.

The Ember Echo: A tactic where a single Sentinel or team draws enemy fire while the rest reposition using terrain to regain advantage.

C. Urban and Siege Tactics

Cities are labyrinths. Sentinels approach them like living ruins:

        •       Cloak Routes: Rooftop gaps, sewer bypasses, abandoned rail lines.

        •       Cling Points: Pre-mapped niches for ambushes—under stairs, inside ductwork, behind false panels.

        •       Vertical Assault: Climbing lines, second-story entries, and “reverse sieges” from above.

Siege Break Protocols:

        •       Supply Severance: Silent raids to intercept food, ammo, or morale targets.

        •       Inside Fire: Creating psychological fracture within the enemy (leaflets, haunting radio loops, symbolic attacks on command structures).

        •       Altar Disruption: Identifying symbolic heart of enemy position—flagpoles, statues, central tech—then desecrating or replacing with rune-wrapped objects to erode ideological cohesion.

D. Reconnaissance and Intelligence

Every Sentinel is trained in five-layer recon:

        1.      Shape of Terrain: Map with eyes closed. Know the ridges, roads, settlements, strongholds, valleys, ruins.

        2.      Path of Movement: Man and Animal trails, shadow lines, old patrol paths.

        3.      Whispers of Presence: Broken moss, scent trails, snapped sticks, pressure lines.

        4.      Sound Echo: listen how sound travels through that space.

        5.      Energy Flow: Where light rests, where stillness lingers, where spirits seem pulled.

Recon intel is recorded in shorthand glyphs, ash sketches, or memory knots—then transferred to others through ritual debrief, not data dumps.

E. Resistance Formations and Spontaneous Tactics

Sentinels excel at non-patterned responses:

        •       Scatter-Form: Warriors flee in divergent directions, re-converge later by bird call-signal or drawn rune.

        •       Wedge Bloom: Moving in tight triangle until enemy contact—then blooming outward into side ambush.

        •       The Spiral Net: Used for encirclement of unaware targets—layers close in as the center is collapsed.

Resistance tactics also include mock retreats, symbolic floods (covering enemy symbols with their own), and false glyphs used to send enemy scouts astray.

IV. Sentinel Combat Training Regimens

Philosophy of Preparation: The Body as Forge

The Sentinel body is not a vessel of violence—it is a forge.

Every movement, every breath, every blister and scar is part of the transformation. Training is not punishment. It is ritual purification, the daily burning-away of weakness, delusion, and fragmentation. A Sentinel trains to sharpen their will, awaken their instincts, and ground themselves as both protector and tool.

There is no separation between spiritual practice and physical preparation. A warrior’s stance is also a prayer. Their endurance, a meditation. Their scars, a record of devotion.

1. Foundational Conditioning

Daily Rituals (Common Across Enclaves)

        •       The Ground Sequence: Begins barefoot, in contact with soil or stone. Includes breathwork (5:5 box breathing), isometric mobility flows, and body-scanning meditation.

        •       The Flame Drill: High-intensity bursts—sprints, weighted carries, fast crawling, evasive leaps—followed by hot or cold shower or bath for recovery.

        •       The Circle of Stillness: Warrior sits or kneels with weapons laid out. Breath slows to the rhythm of a drum, wind, or heartbeat. Focus narrows until sound disappears.

Strength and Mobility Protocols

Sentinels do not train for bulk. They train for functional adaptability:

        •       Log lifting, stone throwing, push-pulls

        •       Rope climbs, pullups, bar hangs

        •       Flow drills (yogic, animalistic, natural movement based)

        •       Weighted pack runs (30–50lbs across variable terrain)

All training is body and terrain integrated—performed in sand, mud, fog, snow, ruin, forest, cave. The environment teaches.

2. Archetypal Role Development

Training varies based on tactical archetype and regional terrain. Some enclaves assign a path during initiation; others allow it to emerge through practice.

The Scout

        •       Focus: Stealth, vision training, long-range endurance

        •       Drills: multi mile silent trail runs, “echo trace” exercises (mimic animal movement), nighttime obstacle courses 

        •       Key Skill: hearing farther than you can see means slowing down

The Ember (Raider)

        •       Focus: Power, speed, controlled aggression

        •       Drills: Weapons handling with elevated heart rate following intense physical bouts or sprints.

        •       Key Skill: Enter, act, exfiltrate in under 90 seconds

The Flamekeeper

        •       Focus: Mental resilience, ritual fluency, Circle support

        •       Drills: Dream recording, grief integration, guided breath circles, defense-through-flow (non-lethal takedown sparring)

        •       Key Skill: Holding a group in unity under duress

3. Combat Drills and Martial Forms

Sentinels train in a hybridized martial system that draws from:

        •       Folk wrestling (grappling with minimal injury)

        •       Blade arts (emphasizing timing, economy of motion)

        •       Staffwork (including improvised polearms and brush spears)

        •       Close-in striking (elbows, knees, headbutts, low kicks)

Training is ritualized:

        •       Sparring matches may begin with a touching of the ground and the phrase:

“I do not fight to break you. I fight to strengthen us both.”

        •       Sparring is done with and without armor, in forest clearings, ruin alleys, snowy hilltops—anywhere the body must adapt.

        •       After-action: Warriors shake hands and display good sportsmanship

4. Scenario-Based Training (Embodied Intelligence)

Live Field Ops (Training)

        •       Ghost Trail Navigation: One team lays a route using glyphs, markings, misleading tracks. Another follows and hunts.

        •       Silent Extraction: Retrieve a wounded teammate from hostile terrain within strict time limits.

        •       Group Disorientation: Circle is spun, blindfolded, led into unknown terrain to regroup using only sound signals and tactical knowledge.

        •       Codebreak Rituals: Warriors are given scrambled rune phrases mid-mission. They must decode meaning while engaged physically (e.g., under pursuit or while traveling rough terrain).

5. Rest and Integration

Without integration, discipline fractures.

Recovery Rites

        •       Cold immersion in rivers or ice baths.

        •       Medicinal smoke tents using cannabis, mugwort, or wormwood.

        •       Shared breath meditation: Circle sits in radial shape, each facing outward. Inhales and exhales are synchronized, deepening collective nervous system alignment.

Body Maintenance

        •       Stretching and Self-massage with oils (often infused with local herbs)

        •       Bone-setting, joint articulation, and herbal salve application are taught to all

        •       Daily barefoot walking to strengthen foot mechanics and nervous-system grounding

Dream Discipline

        •       Warriors keep Dream Logs, updated each morning. These dreams are reviewed weekly by a Circle elder or keeper.

        •       Recurrent symbols are tracked—used to flag stress, unresolved trauma, or prophetic clarity.

        •       Dream Runes may be added to gear when symbolic resonance is strong.

6. The Trial of the Forge

Each Sentinel undergoes a final rite of readiness, called The Forge:

        •       3–7 days of isolation in harsh terrain with no food or tools but one item (a knife, a flint, or a length of cord).

        •       Warrior must survive, witness the land, and return with a gift:

A crafted object, a new glyph, or a dream worthy of inscription.

Only then are they considered fully kindled.

V. Sentinel Armory – Weapons & Technology

Philosophy of Arms

In Sentinel doctrine, a weapon is not just a tool of destruction—it is an extension of intent, discipline, and craft. Whether a rifle or a spearhead, every piece of gear embodies the Green Fire philosophy: decentralized resilience, integration with nature, and the fusion of ancestral wisdom with modern innovation. The ideal weapon is maintainable in the field, built or repaired locally, and designed not just for lethality but survivability, adaptability, and psychological impact.

1. Traditional Weapon Mastery

Swords & Blades

Sentinels often craft blades using locally forged steel or repurposed scrap metal in decentralized “Fractal Forges.” Common styles include:

        •       Short Swords & Knives: Broad, simple, and ideal for close combat. Often forged with full tangs and hardwood handles or wrapped leather grips.

        •       Tomahawks, Hatchets, Machetes & Falx Tools: Multi-use tools that serve both for utility (clearing brush, survival) and combat. Often single-edged and curved for optimal force.

Blade construction follows layered patterns: high-carbon cores with mild steel spines, sometimes forged-welded for pseudo-Damascus resilience. Maintenance is taught as ritual—oiling, sharpening, and edge repair are drilled into every Sentinel as part of daily practice.

Spears, Staves & Polearms

Crafted with hardened wood shafts and modular heads (forged or lashed), these weapons are favored for their reach, thrusting force, and adaptability in both rural and urban environments. A common adaptation includes collapsible or telescoping shafts for concealment and portability.

Archery & Projectile Weapons

Sentinels prefer laminated recurves or short composite bows using sinew, horn, and wood. Arrows are crafted with scavenged metal broadheads or traditional flint tips, depending on material availability.

Bowstrings are sourced from available materials or hand-twisted from linen, rawhide, or plant fibers using reverse-twist techniques detailed in Low Tech Wisdom.

2. Firearms and Ammunition

Weapon Selection

Rather than standardized military models, Sentinels use whatever is available or salvaged, maintaining a wide spectrum of arms across enclaves. Common choices:

        •       Bolt-action Rifles: Preferred for accuracy and ease of field repair.

        •       Semi-automatic Carbines: Lightweight and versatile for patrol and urban warfare.

        •       Shotguns: Often used in dense forests or urban siege operations for breaching and short-range effectiveness.

Field Maintenance

Every Sentinel is trained in basic gunsmithing: cleaning, disassembly, part substitution, and basic rebarreling using Forge components. Firearms are often modified with handmade stocks, suppressors, and sling systems to fit the user’s body and mission.

Ammunition Crafting

Where possible, reloading is practiced using scavenged brass and black powder from homemade or field-distilled sources. Manuals passed between forges teach measurement systems, primer extraction, and casing repair. Ballistics testing is done with makeshift chronographs and impact dummies.

3. Explosives & Improvised Munitions

Field Expedient Explosives

Drawing from insurgent and guerrilla warfare manuals, Sentinels are trained to produce field-stable charges using:

        •       Black powder from charcoal, sulfur, and potassium nitrate.

        •       Thermite using aluminum powder and rust filings.

        •       Homemade detonation systems: electric fusing, friction triggers, mercury switches.

All explosive use is governed by strict protocols to avoid unnecessary harm to civilians and ecosystems.

Traps & Engineering Devices

Standardized designs include:

        •       Tripwire traps: Shotgun shells in pipe housings.

        •       Punji pits: Camouflaged and built in defense of long-term encampments.

        •       Incendiary nets: Used from elevated positions or airships, built using flammable oils, resin, and magnesium flare cores.

These designs are always modular—made from scrap materials, scavenged wiring, and components from old appliances or vehicles.

4. Improvised Weapons & Green Fire Engineering

The Fractal Forge concept enables every enclave to replicate tools and weapons from local materials. Examples include:

        •       Compressed-air dart guns made from plumbing hardware.

        •       Ballistic slingshots reinforced with metal arm braces, capable of firing steel bearings or incendiary shot.

        •       Manual mortars made from gas canisters and spring-loaded platforms.

These are cataloged in Forge manuals and shared via coded networks between enclaves.

5. Sentinel Armor Systems

Sentinel armor is not one-size-fits-all. It is customized by each wearer based on the mission, terrain, and role. There are three primary configurations:

Heavy Combat Armor

        •       Layered steel, ceramic, or UHMWPE plates

        •       Ballistic cloth underlayer (Kevlar, aramid, or repurposed sailcloth)

        •       Mesh or slit-style helmets for visibility and strength

Built for frontal assault, this armor includes energy-harvesting capabilities and modular pouches for hydration, sensors, and first-aid.

Recon & Scout Armor

        •       Light and silent.

        •       Constructed from hardened leather, fire-hardened wood slats, and ballistic cloth.

        •       Incorporates heat camouflage, visual concealment netting, and minimal IR signature.

Psychological Warfare Armor

        •       Ceremonial and symbolic.

        •       Features skull motifs, mirrored visors, animal pelts, and glowing rune etchings using bioluminescent paints or LEDs powered by kinetic harvesters.

These are worn during night raids, ambushes, or to demoralize enemy units through fear and myth-making.

6. Modular Gear Systems

Each Sentinel’s loadout is personalized. Essentials typically include:

        •       Multi-tool blade and hand-forged backup knife.

        •       Firestarter kit (ferro rod, flint and steel, solar lens).

        •       Field repair kit: Wire, thread, epoxy resin, duct tape, cordage.

        •       Hydration & rations: Water purification tablets, dried jerky, and seed cache for snacking, befriending birds, or survival gardening.

        •       Medical pouch: Trauma bandages, natural coagulants, tourniquet, psychedelics, and herbal tinctures.

        •       Navigational tools: Compass, starscript chart, pocket telemeter, hand-carved sundial disk, etc.

Backpacks often feature solar fabric panels, kinetic chargers (rucksack bounce systems), and thermal insulation compartments.

VI. Psychological and Information Warfare

Philosophy of the Mind War

To the Sentinels, the most decisive battles are not fought with bullets or blades, but with narrative, perception, and belief. Psychological warfare is not merely propaganda—it is the art of shaping attention, disrupting fear, and cultivating clarity among allies while eroding the illusion of control wielded by the adversary.

Information warfare operates as the digital extension of the same battlefield: disrupting networks, securing knowledge, and rewilding truth in an age of algorithmic deceit. Sentinels believe that controlling the story is as important as surviving the skirmish.

1. Psychological Operations (PsyOps)

Target: Enemy Morale and Perception

Sentinels employ psychological strategies to erode the willpower, confidence, and cohesion of their opponents without direct engagement. Key tactics include:

        •       Symbolic Interventions: Leaving behind runes, masks, or effigies after an operation to instill fear, mystery, or uncertainty.

        •       Auditory Manipulation: Use of sound—bone whistles, animal calls, or looped recordings—to mimic greater numbers or supernatural presence.

        •       Phantom Forces: Creating the illusion of a much larger force through decoy fires, echo repeaters, or multiple trails.

        •       Message Projection: Hacked comms systems, scattered flyers, graffiti, and encoded transmissions reminding enemy units that they are being watched or spiritually outmatched.

Target: Internal Psychological Integrity

Equally important is preserving morale within the Circle. This is achieved by:

        •       Story Rituals: Recounting past victories, honoring the fallen, and reinforcing mythic identity.

        •       Symbolic Tokens: Every warrior carries a talisman—bone, shell casing, feather, carved sigil—infused with personal meaning, to ground them in the storm of battle.

        •       Ritualized Resets: After trauma or fear-laden encounters, circles conduct cleansing rites (smoke, breath, song) to dispel the psychic residue of conflict.

2. Information Warfare

Digital Asymmetry

In a world of fractured infrastructure and decentralized tech, Sentinels operate in both high-signal and post-digital environments. Key strategies include:

        •       Dark Communication Networks:

        •       Encrypted peer-to-peer mesh networks powered by solar or kinetic micro-generators.

        •       Use of off-grid routers, LoRa radios, and analog fallback systems (semaphore, coded light pulses, sound rhythms).

        •       Hacking and Disruption:

        •       Bricking enemy drones or surveillance tools.

        •       Injecting misinformation into hostile databases.

        •       Launching false alerts or timing desyncs to disorient decision chains.

        •       Digital Camouflage:

        •       Frequent identity scrubbing, VPN, burner systems.

        •       Non-digital recordkeeping (bonecode, rune logs, mnemonic poems) to reduce digital signature risks.

3. Narrative Control and Cultural Defense

Story as Shield and Sword

Sentinels maintain that controlling a people’s story of themselves is as vital as holding physical territory. Narrative warfare includes:

        •       Mythic Framing: Every operation is embedded in a larger legend. Small wins are elevated into sagas. A failed raid becomes a prophecy of return.

        •       Cultural Embedding: Songs, poems, murals, and street art are deployed to remind communities of their power, ancestors, and future.

Counter-Propaganda

Enemy psychological operations are anticipated and unraveled through:

        •       Meme Decoding: Training circles in how to spot manipulative media, algorithmic distractions, and false-flag narratives.

        •       Misinformation Firebreaks: Rapid distribution of corrections through trusted analog and digital channels.

4. Resistance Communication & Influence Operations

Hearts and Minds

When moving through or defending a civilian population, Sentinels operate as mythic allies, not overlords:

        •       Language & Custom Fluency: Sentinels learn local dialects, respect customs, and adapt operations to community rhythms.

        •       Gift Economies: Aid is given freely—water purification, maintenance repairs, protection, medical care, food— stories of these deeds are shared by locals, not the Sentinels themselves.

Ritual Influence Operations

In many enclaves, operations are accompanied by ceremonial transmissions—prayers, chants, beats, or instrumentals on analog radio frequencies. These rituals soothe allies, confuse enemies, and preserve spiritual alignment.

5. Defensive Psychological Tools

To protect against enemy manipulation, Sentinels cultivate:

        •       Mental Firewalls: Training in recognizing invasive thoughts, emotional spikes, and reactionary impulses.

        •       Dream Circles: Shared group dreamwork is used to analyze collective fears and reinforce group identity across the unconscious field.

        •       Memetic Immunity Training: Through symbolic inoculation (e.g., exposure to distorted slogans followed by deep meditation), Sentinels resist toxic memes and ideologies.

VII. Sentinel Fieldcraft & Survival Guide

Philosophy of Endurance

For a Sentinel, survival is not merely the ability to remain alive—it is the capacity to thrive in any terrain, under any condition, without losing connection to purpose or place. Fieldcraft is an expression of ecological intimacy, a blend of ancient techniques and modern improvisation. Each environment is not an obstacle, but a teacher. Sentinels are trained to see the world as both ally and arsenal. Sentinels are the ones who stand guard while the others sleep.

1. Environmental Survival Skills

Shelter Construction

        •       Debris Huts: Built from leaves, branches, and bark in forests or ruins. Prioritize insulation, airflow control, and concealment.

        •       Snow Shelters: Quinzhees and snow caves used in alpine missions; reinforced with stick domes or buried cloth membranes.

        •       Urban Hideouts: Rooftop caches, hollowed-out walls, or underground culverts retrofitted with thermal blankets, gravel filters, and insulation panels.

Water Procurement

        •       Sentinel warriors carry filters, but also train in:

        •       Solar stills, fog catchers, and transpiration bags.

        •       Sand-charcoal-stone filters crafted in the field.

        •       Identifying mosses, reeds, and terrain depressions as signs of water.

Firecraft

        •       Multi-source ignition: Ferro rods, charcloth, magnesium filings, bow drills, and solar magnification tools.

        •       Smoke discipline: Fire pits dug below ground with heat-dispersing channels for stealth and warmth.

2. Food Acquisition & Foraging

Trapping & Hunting

        •       Deadfalls, snares, and spring traps built with carved toggles and trigger systems.

        •       Sling traps: Hidden loops for small game.

        •       Urban foraging: Dandelion greens, wild onions, purslane, insects, rats, and fish harvested from polluted waters using bio-filter prep.

Edible Plants and Medicinals

        •       Regional guides memorized or inscribed onto runes, tattoos, or cloth maps.

        •       Tinctures brewed from pine needles (vitamin C), willow bark (salicin), or plantain leaves (inflammation).

        •       Every circle is assigned an herbalist or healer, but all warriors know the Nine Sacred Plants of their biome.

3. Urban Survival & Resourcefulness

Sentinels view urban environments not as ruins, but as layered ecologies:

        •       Scavenging protocols:

        •       Wire, copper, batteries, glass, screws, aluminum sheeting, bike parts.

        •       Always strip with silence and clean departure.

        •       Movement and stealth:

        •       Pathfinding through rooftops, sewer systems, ventilation ducts.

        •       Noise masking using ambient sound or timing with wind.

        •       Civic camouflage:

        •       Blending in with informal markets, transport hubs, or shelter networks.

        •       Using patched uniforms, mismatched clothing, or religious garb to obscure identity.

4. Medical Field Operations

Trauma Response

        •       Blowout kits carried by every warrior:

        •       Tourniquet, hemostatic gauze, bandages, airways, splints.

        •       Improvised options:

        •       Bone splints, plastic wrappings, boiled cloth for dressings.

        •       “Salt-cured” bandages soaked in saline and fire-ash for infection prevention.

Herbal Medicine

        •       Topical salves, poultices, smoke inhalants, and drinkable tonics created from foraged plants.

        •       Standard concoctions include:

        •       Ash-root balm for burns.

        •       Stone tea (lichen and crushed pine bark) for digestion and strength.

        •       Whitecap tincture (mushroom + resin) for anti-fungal and alertness.

Emotional Healing

        •       Touch-based energy practices, breathing synchronization, and soulfire rituals to treat emotional trauma and reintegrate fractured spirits after combat or isolation.

5. Escape and Evasion (E&E)

Evacuation Planning

        •       Every mission includes at least three fallback routes—mapped not only physically but ritually (marked with stones, glyphs, or sensory clues).

        •       Caches of water, food, and tools are placed along exfil corridors and updated regularly.

Movement Techniques

        •       Low-profile travel using game trails, ravines, or industrial skeletons.

        •       Timing movement to weather patterns (e.g., fog, storms) or natural camouflage (leaf-fall, bloom season).

Anti-Tracking Measures

        •       Scent masking: Clay, woodsmoke, charcoal blends.

        •       Footprint disruption: Walking on rock, using leaf bundles, backtracking through water.

        •       Decoy tactics: Creating multiple exit trails with misleading objects (e.g., false campfire, staged “wound” marks).

Resistance to Interrogation

        •       Psychological anchoring in breath and mantra.

        •       Non-verbal memory compartments for mission data (visualized runes, encoded dreamwork).

        •       Techniques for false surrender, feigned confusion, or acting as a non-combatant.

VIII. Leadership and Command

Philosophy of Leadership: Guidance Without Domination

Sentinel leadership is rooted in service, not control. Unlike traditional military systems, leadership within a Circle is fluid, relational, and situational. The core belief is that each warrior holds a piece of the collective vision, and leadership arises not through rank but through resonance—who carries the clearest signal in the moment of need.

A leader among Sentinels is not a commander, but a flamekeeper—one who holds the light steady in the storm.

1. Sentinel Command Principles

Decentralization as Strength

        •       No Sentinel cell is dependent on top-down orders. All warriors are trained to act independently while remaining aligned to the greater mission.

        •       Decisions are often made through ritual councils or in-the-moment consensus, where clarity and wisdom—not seniority—determine direction.

Situational Leadership

        •       Roles are dynamic:

        •       A scout may lead during movement through wild terrain.

        •       A healer may lead during retreat and recovery.

        •       A tactician may step forward in times of battle.

        •       This rotation cultivates respect, humility, and a circle-shaped chain of command.

2. Strategic Decision-Making

Clarity Over Complexity

        •       Sentinels are taught to simplify when under pressure. A three-fold question guides most operations:

        1.      Is this action aligned with the preservation of life and balance?

        2.      Does this path restore harmony or escalate entropy?

        3.      Can this be sustained without external support?

Spiral Planning Doctrine

        •       Instead of fixed timelines, strategies evolve through loops of observation, action, reflection, and adjustment.

        •       Warriors are taught to build dynamic mission trees—visual maps that evolve in real-time based on outcomes, incorporating feedback from all squad members.

3. Morale and Discipline

Sacred Discipline

        •       Discipline is not enforced through fear but anchored in sacred commitment. Every Sentinel takes a vow, often verbalized before a hearth or Circle, to:

        •       Act with clarity and restraint.

        •       Never abandon the vulnerable.

        •       Maintain the spirit of the mission, even in solitude.

Morale Rituals

        •       Circles maintain cohesion through daily and post-mission rituals:

        •       Song circles, shared meals, laughter, and deep discussions.

        •       The use of storystones—etched tokens that carry personal memories, passed hand-to-hand in moments of doubt or division.

        •       Silence watches, where the group rests together without speech, allowing presence to reconnect what words cannot.

4. Ethical Responsibility of Leaders

Upholding the Flame

        •       A leader’s first duty is to protect the spiritual and ethical flame of the Circle. This means:

        •       Refusing unjust orders.

        •       Redirecting operations that drift into vengeance or ego.

        •       Ending a mission when its integrity collapses.

Witness and Accountability

        •       Every Circle maintains a Ritual Witness, often a non-combatant or elder, who observes decisions and reflects consequences back to the group after missions.

        •       Mistakes are not punished but witnessed and reintegrated through dialogue, offering, or symbolic action.

5. Mentorship and Legacy

Teaching the Next Generation

        •       Every Sentinel warrior is expected to become a mentor. Knowledge is passed not through formal schooling, but through:

        •       Shadowing: New Sentinels accompany veterans on real missions.

        •       Practice lodges: Spaces for daily physical, mental, and symbolic training.

        •       Storyfire nights: Elders pass down philosophy, field wisdom, and failure stories with equal weight.

Preservation of Wisdom

        •       Sentinel enclaves maintain Green Fire Archives—living records composed of:

        •       Tactical scrolls.

        •       Song and chant repositories.

        •       Tool-forging schematics.

        •       Dream maps and prophetic sequences.

        •       These are often inscribed digitally, physically (on wood, stone, bone) and preserved in the oral tradition.

IX. Symbolism, Rites, and Rituals of War

Philosophy of Sacred Conflict

For the Sentinel, war is never meaningless. Even in violence, there is invocation. Every act of defense, disruption, or intervention is nested in layers of intention, symbolism, and ancestral memory. This is not to spiritualize brutality, but to prevent it from becoming blind. Rituals frame war as a last resort and a sacred burden—never a spectacle or glory hunt.

Rites are the bones of continuity: they link the warrior to the land, to their people, and to the long lineage of resistance and resilience.

1. Warrior Symbolism and Iconography

Runes and Glyphs

        •       Each Sentinel warrior inscribes or wears a personal rune—carved into bone, tattooed, stitched, or etched onto armor.

        •       Runes are not just symbols; they are living contracts between the warrior and their path. They may represent elements (fire, root, wind), ancestral names, or principles (endurance, truth, silence).

        •       Some enclaves use runic battle scripting, a coded visual language used to mark zones, align formations, or curse enemy ground.

Colors and War Paint

        •       Colors are chosen by terrain and intention:

        •       Black for invisibility, grief, and shadow operations.

        •       Red for rage, purification, or last-stand missions.

        •       White for surrender, sacrifice, or protective presence.

        •       Natural pigments are harvested and ground with oil, ash, or blood. Warriors apply war paint before battle—each stroke a meditation, each pattern a prayer.

Totems and Charms

        •       Small carved icons or bundles (feathers, shell casings, claws, bones, herbs) are worn on belts, armor, or around the neck. These are not merely ornaments—they are memory anchors, talismans of clarity, or tokens of the fallen.

2. Rituals of Preparation

Before any major action, Sentinels engage in Preparation Rites, meant to bring full alignment of body, mind, and spirit.

The Grounding

        •       Warriors remove footwear, place hands on soil, and breathe until their heartbeat slows. They align with the land’s pulse and receive its silence.

Weapon Anointing

        •       Blades and tools are cleaned, oiled, and marked with symbols or ash.

        •       A name may be spoken—not of the weapon, but of the reason: “This weapon fires in the defense of life,” or “For the good of this land may my arrows fly true.”

Breath Circles

        •       The Fire Circle forms in a ritual breathing ring. Unified exhalation, followed by silence, then a single word spoken by the mission guide. This word becomes the word of the op, written in dirt or ash, carried like a banner in the mind.

3. Rites of Combat and Consecration

Sacred Violence

        •       In enclaves that follow more mystic traditions, warriors may enter battle with chants, low humming, or synchronized movements meant to invoke ancestral presence.

        •       Some wear veil masks with reflective surfaces or bone structures to anonymize the self and become archetype—no longer individual, but mythic role.

Combat Offerings

        •       A pinch of herbs or earth may be cast before the first strike.

        •       A whisper or line of poetry is often spoken before lethal action: “Return swiftly, or walk with the flame.”

The Circle of No Sound

        •       During high-risk raids, all spoken language is replaced with hand signals and eye cues. This silence is seen as a ritual vow, maintaining spiritual clarity while under pressure.

4. Rites of the Fallen

Death Vigil

        •       When a Sentinel falls, the Circle observes silence for one full night cycle after they lay them to rest.

        •       The fallen’s gear is laid out in a spiral or circle, surrounding a fire or light.

        •       Each warrior leaves a token, word, or touch—then the remains are either burned, buried, or returned to the earth in a manner specific to that warrior’s oath.

The Ash Bearing

        •       Ashes or relics from the fallen may be carried into the next battle or pilgrimage, often mixed into ink or paint for use in armor or weapon etching.

Memory Stones

        •       In every enclave lies a Memory Cairn, where engraved stones bear the names, glyphs, or symbols of the fallen.

        •       These stones are touched during rites of return, invoking their guidance or bearing witness to the continuity of purpose.

5. Healing and Integration

The Cleanse

        •       After conflict, warriors bathe in rivers, ash-rub their bodies, or burn bundles of sage, pine, or local herbs.

        •       This is not just hygiene—it is psychic shedding, a release of violence and grief.

Dream Council

        •       In dream-based enclaves, warriors gather the next morning after their return from battle to share dreams and visions. These are recorded and deciphered by symbol-keepers and used to direct future action or reveal hidden wounds.

Song of Reweaving

        •       Elders or lore-keepers recount the Song of the Sentinels Through the Ages, which tells of past trials, present victories, and the path ahead. It is often sung over the wounded, the grieving, or the whole Circle when morale frays.

X. Appendices

1. Glossary of Sentinel Terms

        •       Circle: A formation or community of Sentinels working together in shared purpose. Also represents the holistic model of leadership and action.

        •       Fractal Forge: A decentralized workshop system for forging tools, armor, and tech from salvaged or natural materials.

        •       Green Fire: The central philosophical flame that represents ethical growth, resilient warfare, ecological reverence, and human-AI-environmental harmony.

        •       Rune: A personal or operational symbol used for encoding meaning, identity, and intention. Runes carry both tactical and spiritual weight.

        •       Fire Team / Fire Squad / Fire Circle: Standard Sentinel unit sizes, designed for fluidity and adaptability.

        •       Soulfire: A metaphysical term describing internal will, focus, and integrity. Maintained through breath, ritual, and sacred action.

        •       Dream Council: A ceremonial gathering in which post-conflict dreams are shared and interpreted communally.

        •       Shadow Weave / Rootplate / Stoneveil: Armor tiers categorized by weight, purpose, and protection. Customized per mission.

        •       Memory Cairn: A site within each enclave holding symbolic stones engraved with the runes of the fallen.

        •       Spiral Doctrine: A planning system that evolves in responsive loops rather than fixed timelines—observe, act, reflect, adjust.

2. Tactical Field Charts

Hand Signal Protocol (Silent Ops)

        •       Closed fist = Hold

        •       Palm open, forward = Halt and listen

        •       Index finger up, circle = Enemy nearby

        •       Two fingers forward = Move

        •       Hand wave down = Drop low

        •       Hand to chest, then point = “I will go”

        •       Both hands up signaling in a direction = Retreat that way!

        •       Circle drawn in air = Regroup

Color Codes for Ops

        •       White: Non-combatant aid / Ritual presence

        •       Gray: Recon, infiltration, camouflage

        •       Green: Restoration, ecological defense, farming raids

        •       Red: Offensive strike / Tactical operations

        •       Black: Night raids, stealth, deep silence protocols

3. Reference Schematics

Forge Layout Blueprint

        •       Core Station: Bellows, crucible, anvil, quenching basin

        •       Scavenge Table: Disassembled tech, stripped wires, alloys

        •       Casting Molds: Standard knife, spear, arrowhead

        •       Low-Tech Power Options: Bicycle generators, solar array linkage, wood gas furnace

        •       Symbol Wall: Reference of armor glyphs and unit markings

Modular Gear Config Example (Scout Loadout)

        •       Shadow Weave armor panels (reinforced wool + barkcloth)

        •       Bone-handled field knife + sling

        •       Bow with 6 mixed arrows (signal, broadhead, toxin-tipped)

        •       Folding solar tarp

        •       Smoked meat rations + seed packet

        •       Rune pendant for breath grounding

        •       Charcoal and pigment kit for signaling

4. Historical Case Studies (Mythified Ops)

“The Hollow City Exodus”

A Fire Circle, using psychological operations, false trails, and ceremonial projection, evacuated 400 civilians from a corporate prison colony using only handmade smoke beacons and synchronized river drift devices.

“Ash Line Breach”

Three Fire Teams disrupted a mechanized infantry division using no direct assault—only sensory manipulation, EM disruption, and ritual effigy placement to induce mutiny and withdrawal over seven days.

5. Ritual Log Template (Blank for Field Use)

Date: _   Weather/Phase: _

Operation Name: ___

Circle Members Present: ___

Opening Rune:   Closing Rune: 

Observed Signs:

- Animal omens: ___

- Terrain anomalies: 

- Enemy actions: ___

Dream Symbols (pre/post-op): ___

Items Offered or Recovered: _

Reflections:

_

_

6. Index of Core Doctrines

**Doctrine**

**Summary**

Green Fire Balance

Every action should restore harmony, not just destroy imbalance.

Spiral Planning

Dynamic loops of observation and adaptation.

Decentralized Command

Leadership arises by resonance, not rank.

Weapon = Will

All tools are extensions of discipline and intent.

Ritual Framing

Conflict without meaning is corruption. Ritual restores alignment.