# Mythic Pressure Seeds

Mythic Pressure Seeds are not a separate category drawn from the Saga page UI — they are the **cross-category dynamics** that emerge when World, Region, Faction, Archetype, Loadout, Condition, and Catalyst seeds interact. They are what the Saga Smith watches for as a session unfolds.

This document names the recurring pressure patterns so the Ember Node can recognise them and surface them when they appear.

## The Core Pressure Patterns

### 1. The Slow Bleed
A pressure that never declares itself. Systems function, but a deferred cost is accumulating. Surfaces when a World Seed of "false stability" or "managed decline" meets a Faction Seed that depends on the illusion holding.

### 2. The Wrong Tool
A pressure of capability mismatch. The Loadout was built for a problem that is no longer the actual problem. Surfaces when Loadout + Condition seeds describe a character equipped for the last collapse, not the current one.

### 3. The Echoing Choice
A pressure of recursion. A decision the character made earlier in the saga now returns in different form. Surfaces when Catalyst + Archetype seeds repeat a tension the character has already faced.

### 4. The Faction Mirror
A pressure of self-recognition. An opposing faction reveals an over-optimisation the character's own faction shares. Surfaces when two Faction Seeds in play differ in surface but share underlying schismogenetic drift.

### 5. The Eroding Symbol
A pressure of meaning loss. A symbol, ritual, or relic the character carries no longer means what it used to. Surfaces when a Loadout Seed of symbolic weight meets a World Seed of "machine myth," "archive worlds," or "the AI afterlife."

### 6. The Fracture of Trust
A pressure of misalignment. The character's chosen faction acts against the character's actual values. Surfaces when Archetype + Faction seeds disagree on what the character is for.

### 7. The Threshold
A pressure of irreversibility. A choice ahead cannot be unmade. Surfaces when Catalyst + Condition seeds describe a moment after which the character will be a different person.

### 8. The Long Question
A pressure that does not resolve. A truth the character cannot yet name but cannot stop circling. Surfaces in any saga that runs more than one session — this is the signal that becomes a Signal Thread.

## How To Use This Document

The Saga Smith does not draw a Mythic Pressure Seed at session start. Instead, the Ember Node watches the interaction of seeds already in play, and **names a pressure pattern when it recognises one**.

For example:

- "World: Managed Decline + Faction: The Last Loyalists." → Saga Smith may name: *The Slow Bleed is in play.*
- "Loadout: A pre-Collapse comms relay + Condition: Network signal degraded." → Saga Smith may name: *The Wrong Tool is in play.*

Naming the pressure is enough. The Saga Smith does not resolve it. The character must.

## Why This Document Matters

Without explicit pressure patterns, procedural myth generation drifts toward incident — events without weight. The mythic pressure layer is what turns events into saga.

ᛒ
