# Continuity Pressure

## What Continuity Pressure Is

Continuity Pressure is the accumulated weight a saga carries across sessions. It is the difference between a one-shot story and a saga.

A one-shot story resolves and is complete.

A saga carries forward unresolved tension, surfaced Signal Threads, factional consequences, and changes in the character that have not yet been integrated. That carry is continuity pressure.

## Why It Matters

Procedural myth without continuity pressure becomes episodic. Each session is novel, but nothing matures.

Procedural myth with continuity pressure spirals. Each session deepens the questions the saga is actually about.

The Saga Smith's job — whether human, AI, or solo player — is to **carry the pressure forward without forcing resolution**.

## The Three Layers Of Continuity Pressure

### 1. World-Layer Pressure
The saga's world has changed because of the character's actions. A faction is weaker or stronger. A region is safer or more dangerous. A threshold has been crossed.

Track world-layer changes as compact notes — in a notebook, a document, or a simple list. Keep them brief enough to scan at the start of a session.

### 2. Character-Layer Pressure
The character has changed because of what they have chosen. A loadout item has gained or lost meaning. An internal tension has tightened or eased. A loyalty has shifted.

Track character-layer changes alongside the character's description. A few sentences is usually enough.

### 3. Practitioner-Layer Pressure
The practitioner has noticed something through the saga that connects to their own life. This is the most fragile and the most important layer.

Never assume practitioner-layer pressure. Surface it only when the practitioner names it. When named, it may become a candidate Signal Thread (see `signal-threads.md`). The practitioner decides whether to name and preserve it.

## The Spiral Tightens

Across sessions, a well-held saga spirals: returning to the same questions from new angles, the same factions in new configurations, the same character at new depth.

The Saga Smith recognises spiraling when:

- A Catalyst echoes an earlier Catalyst with different weight.
- A Faction the character once trusted reveals its over-optimisation.
- A Loadout item the character carried for safety becomes the source of risk.
- A Condition the character thought was external turns out to be internal.

When spiraling is recognised, the Saga Smith does **not** explain it. The character must encounter it.

## Avoiding False Resolution

A common failure mode in AI-assisted storytelling is the urge to resolve every thread within a session. This collapses continuity pressure into closure and ends the saga prematurely.

The Saga Smith — in any form — should:

- Decline to wrap up open threads unless the practitioner explicitly asks for closure.
- Treat session ends as pauses, not endings.
- Offer to leave specific threads open at session end (see `reflective-journaling.md` for the end-of-session protocol).

## Releasing Continuity Pressure

Continuity pressure is not infinite. A saga can become weighed down by too many unresolved threads. The Saga Smith and the practitioner together decide when to:

- **Integrate** a thread — fold it into the character's settled understanding.
- **Retire** a thread — acknowledge it as no longer active.
- **Hand off** a saga — close one character's arc and seed another.

Releasing pressure is part of the practice. A saga that never releases becomes a burden.

ᛞ ᛒ
