# Build a Field Exercise

*A step-by-step template — run your own session without reading the full Field Rule first.*

---

A Field Exercise begins with people under pressure, not a full world history. Give each player something useful, something they protect, and one problem none of them can solve alone.

---

## Step 1 · Kindle the Sentinels

Each player answers — one sentence each:

1. Who are you? Name and practical role.
2. What are you especially good at?
3. What do you carry, and what do you protect?

*The character does not need a class, a score sheet, or a backstory.*

---

## Step 2 · Set the Field

Draw or choose one item from each row. Start with the problem already happening. Reveal history only when it becomes useful.

| Element | Options |
|---------|---------|
| **Place** | lockhouse, trail shelter, repair shop, marsh boardwalk, farmstead, train depot |
| **Pressure** | rising water, failing machine, missing person, blocked route, injured animal, incoming weather |
| **Division** | protocol vs. compassion, escape vs. rescue, secrecy vs. warning, repair vs. replacement |
| **Shared need** | someone is trapped, a route must be opened, a vital tool is failing, a message must get through |

---

## Step 3 · Resolve Uncertain Actions

Players decide what their Sentinels attempt. The Saga Smith describes the world's response. Use a d6 only when the action has a real risk, cost, or unknown outcome:

| Roll | Result |
|------|--------|
| **5–6** | It works. |
| **3–4** | It works, but creates a cost, loss, damage, delay, or new pressure. |
| **1–2** | It does not work as hoped; the field changes and the group must adapt. |

When a second Sentinel provides meaningful help, roll twice and keep the better result. For a simple unanswered world question, use a coin or an even/odd roll — it answers the field, not the player's intention.

---

## Step 4 · Preserve the Signal

End when the immediate danger changes shape. Record only four things:

- What was protected?
- What was spent or damaged?
- What changed between the Sentinels?
- What unresolved signal remains?

*Those notes can become the opening pressure of a future session.*

---

## Facilitator Note

No one needs to know Green Fire before beginning. Let practical choices, consequences, and reflection carry the meaning. The story can remain a one-night exercise or become a living thread.

---

*For a completed example of this template in play, see `field-record.md`. For the canonical Field Rule that underlies this template, see `field-rule.md`. For a ready-to-paste exercise, see `field-exercises.md`.*
