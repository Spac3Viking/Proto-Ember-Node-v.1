---
title: "ᛋᚲ᛬ Sentinel Archetypes"
description: "The five core archetypes of the Sentinel path"
category: "foundational-works"
order: 4
---

## CODEX: SENTINEL ARCHETYPES

A Guide to Tactical Identity, Symbolic Function, and the Modular Self

“This is not who you are. This is the place you begin.”

### 

### Prologue – The Pattern Beneath the Skin

Archetypes are not roles to perform, but fields of resonance to recognize and refine.

This Codex is not here to define you. It is here to give you the materials to forge yourself — for story, for spirit, for survival.

## 

## CHAPTER I: WHAT IS AN ARCHETYPE?

“An archetype is not who you are. It’s the pattern you learn to carry, shape, and eventually pass on.”

### I. The Pattern Beneath the Mask

Most people believe that who they are is the sum of their personality, history, or emotions. But deeper than preference, deeper than belief, there are patterns—shared shapes of consciousness that repeat across people, time, and culture.

These patterns are known as archetypes. A concept popularised by Carl Jung. 

An archetype is not a costume you wear. It is not a job, a role, or a mood.

It is a resonant form of identity—a gravitational field of story, instinct, behavior, and function.

Every person moves through these patterns whether they realize it or not. The Warrior who acts before thinking. The Scholar who seeks to understand. The Healer who absorbs others’ pain. The Rebel who challenges the structure. The Seeker who must leave home to find what is real.

These are not new ideas. But how we use them can be.

### II. Ancient Foundations: Archetypes Across Traditions

The idea of archetypes is as old as human thought:

- In Jungian psychology, archetypes are deep, mythic structures that live in the collective unconscious—shared forms like the Shadow, the Hero, the Mother, the Trickster. They shape our dreams, fears, and compulsions, often without our awareness.  

- In myth and storytelling, archetypes are the invisible engines of narrative. They are the templates behind heroes, mentors, villains, and threshold guardians. They help us understand transformation through the logic of story.  

- In astrology, each sign is a living archetype—a specific pattern of behavior and purpose echoed in cosmic rhythm.  

- In ancient runic and symbolic systems, archetypes are embedded in geometry and glyphs. Each rune holds not only a sound and meaning, but a behavioral pattern. A way energy flows in the world.  

- In personality theory—from MBTI to Enneagram to the Big Five—modern science still seeks to name and measure the same ancient truths: we are shaped by recurring patterns, but we are also capable of working with them intentionally.  


What makes the Green Fire approach unique is that we do not seek to define you using archetypes.

We offer them as tools for clarity, ritual, self\-design, and tactical functionality.

### III. Archetypes as Strategic Forms

In the Sentinel Path, we see archetypes as functional strategy forms.

They are not boxes, they are loadouts—modular configurations of behavior, strengths, and challenges that adapt depending on your situation, season, or phase of growth.

You might take on the pattern of the Warrior when precision and defense are needed.

You might shift to the Scholar when the moment demands analysis and teaching.

You might pass through the Mystic during grief or ritual.

You might embody the Builder when it’s time to establish a forge or a stronghold.

Or you might become the Wanderer—not lost, but purposefully navigating between identities.

In the field, on the path, and in the self, archetypes are tools—each with its own rhythm, logic, and flame.

They are symbols with personalities.

### IV. Fields of Resonance: The Green Fire Model

In Green Fire, we do not treat archetypes as fixed identities. We treat them as Fields of Resonance—overlapping energetic patterns that move through the body, mind, and narrative.

Each archetype is a configuration of seven key fields:

1. Core Drive – What moves you  

2. Field Function – How you operate in practice and reality  

3. Perception Mode – How you interpret experience  

4. Shadow Trial – Your recurring internal challenge  

5. Elemental Pulse – Symbolic elemental expression  

6. Craft Specialty – What you offer to the Circle  

7. Training Style – How you grow and refine  


This system allows for complexity, flexibility, and customization.

You do not “choose” an archetype once—you refine into it, or remix it based on your needs.

This makes archetypes not just self\-descriptions, but living systems of growth.

### V. Archetypes as Living Flame

To carry an archetype is to accept a discipline.

To train, to embody, to understand where you are strong—and where your pattern betrays you.

Every archetype includes its own:

- Power \(strengths\)  

- Shadow \(weakness or distortion\)  

- Resonance \(what it harmonizes with\)  

- Toolset \(practices, rituals, roles, and reflections\)  


But none of them are permanent.

As a Sentinel, you will shift forms over time. You might fuse archetypes. You might cannibalise an old loadout to enter a new phase. You may even evolve past an individual archetype once you’ve internalized its lessons.

The Green Fire does not offer fixed roles. It offers refinement through form.

### VI. The Key Insight

An archetype is not who you are. It is the pattern you learn to carry, shape, and eventually pass on.

Archetypes are blueprints for growth. They are inner armor and outer symbols.

They are not rigid maps, but mythic instruments.

They are not your destiny, but the language through which you shape it.

You are not here to be boxed in. You are here to become forged.

The Sentinel Path begins when you stop asking “What am I?”

And begin asking:

What pattern am I refining?

What field am I tuning?

What story am I walking into?

Let’s begin.

## 

## CHAPTER II: FIELDS OF RESONANCE

The Modular Core of Archetype Formation

“The self is not a statue. It is a set of frequencies.”

“To know yourself is not to name a form—but to map the fields that move through you.”

Archetypes are not identities.

They are configurations of internal forces—energetic, symbolic, behavioral, and philosophical.

In the Green Fire system, we call these forces Fields of Resonance.

Each field is a layer of pattern that influences how you act, perceive, train, and relate. By understanding which traits resonate within each field, you gain the ability to forge archetypes, track your growth, and adapt to new circumstances without losing your center.

Every archetype is a configuration of fields.

Every person is a dynamic resonance pattern—sometimes aligned, sometimes in flux, always in motion.

## The Seven Fields of Resonance

### 1. Core Drive

“What fuels your motion?”

This is your engine—the inner fire that compels action. Core Drive reveals your instinctual purpose, what you are always moving toward, consciously or not.

#### Frequencies:

- \(Fire\)  – friction, action, pressure, conquest \(Fire\)  

- \(Earth\) – Stability, endurance, rootedness  

- \(Air\) – Exploration, novelty, mental expansion  

- \(Water\) – Union, healing, intimacy  

- \(Æther\) – Pattern\-breaking, liberation, synthesis  


#### Rune Alignments:

- ᚱ Raidho – Direction, movement, pilgrimage  

- ᚠ Fehu – Vital energy, motivation, circulation  

- ᛗ Mannaz – Purpose through shared humanity  

- ᛇ Eihwaz – Will to endure and transform  


#### Reflection Prompts:

- What am I always chasing, even when I try not to?  

- What kind of friction do I secretly thrive in?  

- If I do nothing else, what must I become?  


### 2. Field Function

“How do you act under pressure?”

This field describes your tactical expression—your reflexive role in crisis, change, or mission.

#### Frequencies:

- Initiator – First to act, break inertia  

- Stabilizer – Holds form, protects, anchors  

- Observer – Watches patterns, gathers insight  

- Supporter – Enhances others, maintains morale  

- Disruptor – Breaks patterns, introduces chaos strategically  


#### Rune Alignments:

- ᚦ Thurisaz – Tactical force, breakthrough  

- ᛉ Algiz – Protection, defense, vigilance  

- ᛈ Perthro – Observation, probability, unseen shifts  

- ᛞ Dagaz – Sudden change, quantum movement  


#### Reflection Prompts:

- What role do I instinctively take when things go sideways?  

- Do I prefer to lead, to stabilize, or to observe from the edge?  

- When I’m most effective, what function am I fulfilling?  


### 3. Perception Mode

“How do you interpret the world?”

This field maps your cognitive resonance—the lens through which reality is perceived and decoded.

#### Frequencies:

- Tactile – Learns through body, craft, presence  

- Analytical – Prioritizes logic, detail, system  

- Symbolic – Sees through metaphor, ritual, pattern  

- Intuitive – Feels resonance, nonverbal truth  

- Reflective – Processes internally, quietly, cyclically  


#### Rune Alignments:

- ᚲ Kenaz – Vision, inner light, comprehension  

- ᛁ Isa – Stillness, internal depth, reflective clarity  

- ᚨ Ansuz – Language, communication, inspired understanding  

- ᛜ Ingwaz – Inner gestation, mental fertility  


#### Reflection Prompts:

- What do I notice that others miss?  

- Do I process before I act—or act before I understand?  

- What is my natural mental terrain: word, form, sensation, or silence?  


### 4. Shadow Trial

“What challenge tests your pattern?”

This field reveals your recurring internal obstacle—where your resonance becomes distorted under stress or imbalance.

#### Frequencies:

- Stagnation – Resistance to change, fear of motion  

- Overreach – Control, aggression, spiritual pride  

- Collapse – Emotional flood, burnout, helplessness  

- Disillusion – Meaning crisis, cynicism  

- Fragmentation – Identity drift, avoidance, self\-doubt  


#### Rune Alignments:

- ᚺ Hagalaz – Crisis, shattering  

- ᚾ Nauthiz – Inner tension, need, friction  

- ᛃ Jera – Patience through cyclic difficulty  

- ᛉ Algiz \(inverted\) – False defenses, self\-sabotage  


#### Reflection Prompts:

- What emotion or story do I return to when uncentered?  

- What pattern sabotages me again and again?  

- How might this trial be a tool, not just a trap?  


### 5. Elemental Pulse

“What element shapes your flow?”

This is your symbolic current—the elemental signature that governs how your energy moves through time, space, and relation.

####  Resonance:

- Fire – Will, motion, purification, clarity  

- Water – Feeling, flow, intuition, adaptation  

- Earth – Strength, presence, memory, ritual  

- Air – Mind, voice, mapping, perspective  

- Ether – Myth, transformation, chaos\-as\-creation  


#### Rune Alignments:

- ᛋ Sowilo – Fire / clarity / solar essence  

- ᛚ Laguz – Water / emotional depth / life force  

- ᛟ Othala – Earth / ancestry / boundary  

- ᚨ Ansuz – Air / spirit wind / intellect  

- ᛈ Perthro – Ether / hidden pattern / fate  


#### Reflection Prompts:

- What is my elemental rhythm? How do I move, feel, relate?  

- When I am in alignment, which element is most alive in me?  

- What element do I resist—and why?  


### 6. Craft Specialty

“What do you offer to the Circle?”

This is your gift field—your natural area of skill, creation, or service.

#### Frequenciesᛝ:

- Builder – Systems, rituals, infrastructure  

- Tracker – Terrain, patterns, foresight  

- Speaker – Storytelling, teaching, voice of the fire  

- Healer – Restoration, tending, transmutation  

- Warden – Defense, boundary, vigilance  

- Mythkeeper – Lorecraft, dreamwork, symbolic weaving  

- Initiator – Guides trials, ritual thresholds  


#### Rune Alignments:

- ᛏ Tiwaz – Discipline, leadership, responsibility  

- ᛞ Dagaz – Cycles, transitions, dawns  

- ᚾ Nauthiz – Necessity as initiation  

- ᛒ Berkano – Nurturing, healing, sacred form  


#### Reflection Prompts:

- What do others rely on me for—even when I don’t try?  

- What work energizes me, even when it’s hard?  

- What is the role I play when no one tells me to?  


### 7. Training Style

###  

“How do you refine and evolve?”

Not all Sentinels train the same. This field identifies your learning strategy—how you grow, adapt, and embody new resonance.

#### Frequencies:

- Solo Path – Refines through solitude and repetition  

- Mirror Training – Learns through others, conflict, relationship  

- Circle Training – Grows in group reflection and exchange  

- Immersion – Needs full sensory, environmental engagement  

- Apprenticeship – Evolves through close transmission and mentorship  


#### Rune Alignments:

- ᛉ Algiz – Protection through guided learning  

- ᛗ Mannaz – Mutual development  

- ᛜ Ingwaz – Slow integration, inner cultivation  

- ᛇ Eihwaz – Depth through trial and personal forging  


#### Reflection Prompts:

- What conditions accelerate my growth?  

- Do I thrive in solitude, pressure, structure—or immersion?  

- Who are my past mentors, and what styles left a mark on me?  


## Final Reflections: The Map Before the Forge

Understanding your Fields of Resonance is the first step toward forging your Sentinel Archetype. These fields do not tell you who you are—they show you where your power, challenge, and refinement live.

Each field can shift as you evolve. Each can be tuned through discipline. Together, they create a living system of identity that adapts with purpose instead of chaos.

You are not here to fit a mold.

You are here to shape the flame and wield it.

## 

## CHAPTER III: THE ARCHETYPE FORGE

A Practical Guide for Forging, Evolving, and Embodying the Modular Self

“You are not handed a name. You craft it in flame.”

“To walk the Sentinel Path is to forge your own conflagration of truth, trial, and technique.”

The archetypes in this Codex are not titles to claim.

They are patterns to walk, tools to wield, and identities to refine through intentional structure.

In this chapter, you will learn how to craft your own archetype using the Sentinel Archetype Forge Template. This process isn’t about personality typing or mythic cosplay. It’s about creating a modular operating system for your story, your training, or your philosophical embodiment.

The forge is where structure meets soul.

## I. The Purpose of the Forge

The Forge Template is a ritual frame—part reflection, part design, part invocation.

It is meant to serve:

- The practitioner, seeking growth and self\-initiation  

- The writer, building meaningful characters or factions  

- The trainer, designing role\-based challenges and drills  

- The worldbuilder, creating archetypes for enclaves, Orders, or cultures  

- The symbolist, crafting glyphs, crests, or emblems of identity  

- The circle, building cohesion through resonant roles  


Your archetype is not a fixed identity. It is a functional convergence of the seven Fields of Resonance—expressed intentionally, updated cyclically, and tested through real action.

## II. The Sentinel Archetype Forge Template

 This is a starting template to build your personal or fictional archetype.

### 1. Name of Archetype

Give it a title that resonates with your role or symbolic function.

Examples: The Flame\-Warden, The Edge\-Seer, The Silent Root, The Signal Knight, The Spiral Cartographer

Optional: Create a personal variant name, such as “Myth\-Walker of the Eastern Circle” or “Vessel of Fractured Stars”

### 2. Core Flame

A poetic invocation or mission phrase that encapsulates the spirit of this archetype.

“I carry the silence between worlds. I move without trace, but not without purpose.”

This line may also be used as a personal mantra, emblem inscription, or ritual statement.

### 3. Resonance Fields \(Trait Profile\)

Use this section to build your pattern using the Fields of Resonance:

Field

Selected Trait

Notes or Symbol

Core Drive

e.g., Curiosity

\(The Wanderer’s call to seek\)

Field Function

e.g., Observer

\(Decodes situations, maps people\)

Perception Mode

e.g., Symbolic

\(Thinks in metaphor and map\)

Shadow Trial

e.g., Fragmentation

\(Loses center, forgets form\)

Elemental Pulse

e.g., Air

\(Clarity, movement, breath\)

Craft Specialty

e.g., Tracker

\(Knows terrain, maps, energy flow\)

Training Style

e.g., Immersion

\(Learns through direct experience\)

### 4. Tools of the Path

List 1–3 rituals, drills, or practices that support and embody this archetype.

Examples:

- Daily stillness walks with observational journaling  

- Runic mapping exercises for pathwork and perception  

- Quarter\-moon trial of silence and landscape immersion  


### 5. Hybrid Potential

Which other archetypes does this form align with? What might it become if fused?

Examples:

- With The Warrior → becomes a Recon Sentinel  

- With The Mystic → becomes a Dream\-Mapper  

- With The Builder → becomes an Infrastructure Cartographer  


### 6. Personal Glyph \(Optional\)

Create a symbolic representation of this archetype.

It could be:

- A rune fusion  

- A sigil drawn from elemental or geometric components  

- A mirrored shape of your Field traits  

- A spiral, triangle, or directional emblem  


You can sketch, carve, or digitally render this mark as a badge of resonance.

### 7. Reflection Prompts

Use these to update or challenge the archetype over time:

- When does this archetype serve me best?  

- Where does it begin to distort?  

- Has the trial evolved? Have the tools changed?  

- Do I still carry this form—or is it time to shift?  


## III. Combining Fields into a Usable Pattern

Building your archetype is both symbolic and strategic.

Here’s how to think through the process step\-by\-step:

1. Start with your Core Drive.  
  
 This is your inner compass. Choose a trait that truly resonates—not just what already burns within, but what I you want to be.  

2. Identify your Field Function.  
  
 Consider how you show up in teams, conflict, solitude, or crisis. What is your instinctive role?  

3. Refine your Perception Mode.  
  
 This affects how you learn, teach, strategize, or train others. Your symbolic interface.  

4. Name your Shadow Trial.  
  
 Choose not just a weakness—but a familiar distortion. One that tests you again and again.  

5. Tune your Elemental Pulse.  
  
 Choose your energetic rhythm. Are you solar or lunar, burning or flowing, grounded or spiraling?  

6. Claim your Craft Specialty.  
  
 What do you bring to a mission, a circle, a camp, a ritual? Your contribution matters.  

7. Align with your Training Style.  
  
 Knowing how you refine helps you build systems that actually work—and evolve.  


## IV. Applications of the Forge

Once built, your archetype becomes:

- A self\-initiation map  

- A role in your Circle or enclave  

- A tactical training focus \(e.g. “all Warrior roles undergo combat refinement”\)  

- A narrative class or path for storytelling or game\-building  

- A symbolic ritual persona used in rites, challenges, or seasonal transformation  

- A visual identity glyph for tools, cloaks, flags, journals, or tattoos  

- A field\-adaptable system—archetypes that change based on phase or mission  


## V. Optional Expansions

As you grow your practice or Circle, consider building:

- Role Cards – Each archetype formatted onto an ID\-style card for identity ritual, writing, or Circle ritual  

- Trial Logs – Journals that track how your archetype performed in challenge  

- Glyph Language – A symbolic shorthand based on runes, geometry, or numerology  

- Archetype Wheels – Diagrams that map multiple archetypes and their interactions  


## Final Insight

The forge is not for naming. It is for shaping.

An archetype is not a destination. It is a discipline.

Through the forge, you craft a name that means something.

A glyph that marks something real.

A pattern that can survive the fire of your life and the stories yet to be written.

Let’s begin.

## 

## CHAPTER IV: THE FIVE CORE ARCHETYPES

The Foundational Forms of the Sentinel Path

“An archetype is not an identity—it is a pattern of alignment. A stance toward the world. A structure you step into, wear, refine, and eventually outgrow.”

These five archetypes form the foundational grammar of the Sentinel Path. They are not the final word on identity. They are the root patterns from which new forms emerge.

Each archetype is a configuration of resonance fields, a tactical and symbolic expression of the inner forge. Through training, trial, and reflection, these forms evolve. They are not fixed—they are designed to be remixed, tested, or replaced when no longer needed.

## 1. THE WARRIOR

Protector, Initiator, Tactician

Core Flame: “To act with purpose is to shape the world with every step.”

### Archetype Profile

Field

Trait

Description

Core Drive

Ignition

Propelled by duty, threat response, and decisive purpose.

Field Function

Initiator

Charges into danger. Breaks deadlock. Acts to create motion.

Perception Mode

Tactile

Responds through motion and sensory precision.

Shadow Trial

Overreach

May dominate, rush, or burn others to achieve a result.

Elemental Pulse

Fire

Solar intensity, clarity, purification through conflict.

Craft Specialty

Warden

Defends others, holds position, protects the structure.

Training Style

Mirror Training

Refines through challenge, combat, and relational tension.

### Tools of the Path

- Three Stances Ritual – Practice shifting between stillness, readiness, and motion.  

- Tactical Reset Breath – 2 deep nasal inhales with a full exhale before decision or engagement.  

- Shield & Flame Drill – Protect without attack. Then attack without defense. Reflect on both.  


### Hybrid Potentials

Strategist, Shadow Knight, Scout, Warden of Foundations

### Reflections

- What must I protect that no one else will?  

- Do I act out of clarity or compulsion?  

- Where is my edge between power and dominance?  


### Glyph / Rune

ᛏ Tiwaz | ᛉ Algiz | Inverted triangle with upward flameburst

## 2. THE SCHOLAR

Analyst, Teacher, Archivist

Core Flame: “The blade of the mind can be kept sharper than steel.”

### Archetype Profile

Field

Trait

Description

Core Drive

Curiosity

Fueled by a need to understand patterns and systems.

Field Function

Observer

Records, tracks, analyzes—quiet before precise action.

Perception Mode

Analytical

Prefers structure, sequence, logic.

Shadow Trial

Paralysis

Overthinks. Obsesses. Loses motion in detail.

Elemental Pulse

Air

Clarity, thought, breath, language.

Craft Specialty

Speaker / Researcher

Synthesizes, teaches, contextualizes.

Training Style

Solo / Apprenticeship

Deep work, repetition, lineage learning.

### Tools of the Path

- Rune Logbook – Maintain a journal of symbols, ideas, and decoded experiences.  

- The Echo Test – Teach what you just learned. See where it fractures.  

- Structural Mapping – Reduce a complex system into a single diagram.  


### Hybrid Potentials

Strategist, Lorekeeper, Architect of Systems

### Reflections

- What knowledge have I hoarded? What must be passed on?  

- What part of me fears being wrong?  

- Do I wait too long to act?  


### Glyph / Rune

ᚨ Ansuz | ᚲ Kenaz | Spiral coiled inward into a point of light

## 3. THE MYSTIC

Healer, Seer, Translator of the Unseen

Core Flame: “To see is not enough. One must undersrand what is seen.”

### Archetype Profile

Field

Trait

Description

Core Drive

Integration

Seeks unity between seen and unseen, self and source.

Field Function

Translator

Bridges dimensions, patterns, and meanings.

Perception Mode

Symbolic / Intuitive

Moves through dream, myth, and metaphor.

Shadow Trial

Escapism

Dissociates, avoids grounded practice.

Elemental Pulse

Water

Flow, resonance, dissolution, reflection.

Craft Specialty

Healer

Transmutes pain, bridges shadow and clarity.

Training Style

Immersion

Requires full\-body/mind/spirit enmeshment in practice.

### Tools of the Path

- Dream Scripting – Record, interpret, and ritualize recurring inner symbols.  

- Breath\-Sigil Practice – Link visualized runes to rhythmic breath cycles.  

- Elemental Channeling – Align daily practice with moon, water, and emotion.  


### Hybrid Potentials

Dream\-Mapper, Ritual Strategist, Shadow Knight

### Reflections

- Am I hiding behind mystery or carrying it forward?  

- When do I feel in\-flow vs. lost?  

- What unseen force am I in relationship with?  


### Glyph / Rune

ᛟ Othala | ᛚ Laguz | Crescent\-moon spiral with central eye

## 4. THE BUILDER

Crafter, Stabilizer, Steward of Structure

Core Flame: “Strength is not in resisting chaos, but shaping what endures through it.”

### Archetype Profile

Field

Trait

Description

Core Drive

Containment

Seeks to maintain what matters. Builds to outlast.

Field Function

Stabilizer

Holds space, creates platforms, sustains others.

Perception Mode

Tactile / Reflective

Understands through material, rhythm, and cycles.

Shadow Trial

Rigidity

Over\-controls. Clings to outdated structures.

Elemental Pulse

Earth

Grounding, form, memory, continuity.

Craft Specialty

Builder

Constructs tools, systems, environments.

Training Style

Solo \+ Repetition

Mastery through quiet, enduring rhythm.

### Tools of the Path

- Sanctum Ritual – Maintain and upgrade your home, altar, or working space.  

- Cycle Mapping – Track moon, soil, seasonal or system shifts over time.  

- Material Offering – Create something enduring: from idea to object  


### Hybrid Potentials

Warden of Foundations, Codex Architect, Ritual Engineer

### Reflections

- Do I build to serve—or to avoid risk?  

- What foundations do I trust too much?  

- What structures have I outgrown?  


### Glyph / Rune

ᛃ Jera | ᛞ Dagaz | Square over circle nested in mountain triangle

## 5. THE WANDERER

Explorer, Edge\-Dweller, Test\-Bearer

Core Flame: “The path is not found—it is walked into being.”

### Archetype Profile

Field

Trait

Description

Core Drive

Freedom / Discovery

Moves by friction, test, and seeking thresholds.

Field Function

Adapter

Survives across contexts. Evolves rapidly.

Perception Mode

Intuitive / Reflective

Learns through lived immersion.

Shadow Trial

Fragmentation

Becomes rootless, disconnected, undefined.

Elemental Pulse

Ether

Boundaryless change, edge\-energy, entropy and potential.

Craft Specialty

Tracker

Follows patterns, reads terrain, survives motion.

Training Style

Immersion

Changes by doing, by throwing self into unknown.

### Tools of the Path

- Pathwalking Journal – Record terrain, emotions, stories from movement.  

- Adaptive Trial – Choose discomfort. Record transformation through unknown.  

- Displacement Ritual – Change location, role, or identity for 3 days. Reflect.  


### Hybrid Potentials

Spiral Cartographer, Signal Rogue, Edge Diplomat

### Reflections

- Where am I afraid to root—and why?  

- What thresholds am I called to walk beyond?  

- Is my movement freedom—or evasion?  


### Glyph / Rune

ᛈ Perthro | ᛇ Eihwaz | Spiral branching into fragmented compass

## Final Note on the Five

These five are not a complete system—they are a foundation. A sourcecode. A mythic grammar.

From them, you can forge any number of hybrids, mutations, region\-specific variants, or storyforms. Over time, your archetype will shift. You may enter a Warrior phase and exit a Scholar. You may be both Builder and Wanderer. You may abandon all archetypes and walk the Sentinel path of endless branches.

The point is not to lock into identity.

The point is to recognize the pattern you are refining—and to wield it with clarity, courage, and reverence.

## CHAPTER V: EXPANDING THE PATTERN

From Fusion to Evolution

“The five become the many. The form is not final. The flame refines through motion.”

Once you understand the foundational archetypes, you begin to notice the overlap, interplay, and resonance between them. The Sentinel Path is not about locking into a single role—it is about learning to shape, adapt, and combine roles as conditions change.

In this chapter, we explore how to remix, evolve, and invent archetypes through intentional design. This isn’t about personality theory—it’s about creating usable inner patterns, living identities that are adaptable to terrain, purpose, or story.

## I. Archetype Fusion: Combining Fields

When two or more archetypes are consciously combined, they produce a hybrid form—a new archetype with a unique resonance field and tactical application.

Below are examples of hybrid archetypes, each described by its dominant fields, purpose, and potential use.

### EXAMPLES OF HYBRID ARCHETYPES

#### Battle Shaman

Warrior \+ Mystic

- Fields: Fire, Water, Initiator, Translator  

- Purpose: Guardian of thresholds, spiritual warrior, dream\-protector  

- Used for: Conflict alchemy, shadow integration, rite guardianship  


#### Signal Cartographer

Scholar \+ Wanderer

- Fields: Air, Ether, Observer, Tracker  

- Purpose: Mapmaker of changing realities, explorer of unknown systems  

- Used for: Narrative generation, AI design, symbolic research  


#### Spiral Ranger

Wanderer \+ Mystic

- Fields: Ether, Water, Adapter, Translator  

- Purpose: Cultural infiltrator, information shapeshifter, ritual hacker  

- Used for: Storytelling, espionage, memeweaving  


#### Forge Warden

Builder \+ Warrior

- Fields: Earth, Fire, Stabilizer, Warden  

- Purpose: Protector of infrastructure, tactical builder, outpost defender  

- Used for: Enclave construction, permaculture, gear design  


#### Lorekeeper

Scholar \+ Mystic

- Fields: Air, Water, Observer, Healer  

- Purpose: Preserver of forgotten systems, translator of lost knowledge  

- Used for: Archive design, memory rituals, education  


## II. Narrative Crafting & Enclave Patterns

In worldbuilding or community design, archetypes can help define:

- Faction roles \(e.g., The Circle of Flame might be composed of Warrior\-Mystics\)  

- Ritual paths \(e.g., Wanderer → Mystic → Scholar as a seasonal evolution\)  

- Initiation arcs \(e.g., all new initiates begin as Builders before specializing\)  

- Enclave identities \(e.g., a desert enclave may have a majority of Warrior\-Wanderers; a mountain enclave may cultivate Builders and Lorekeepers\)  


### Narrative Use

Use archetypes as dynamic roles that evolve based on events, seasons, or relationships. Characters might “shift roles” after trials, take on hybrid roles in groups, or abandon archetypes altogether as part of story climax.

In story: roles are defined. In ritual: roles remind. In practice: roles are refined.

## III. Adaptation by Terrain, Philosophy, and Need

The same archetype may take on different traits based on:

- Environment  

	- A Forest Warrior may emphasize patience, stealth, and awareness  

	- A City Warrior may emphasize precision, law, and control  

- Philosophy  

	- A Scholar trained in runes will see patterns through language and symbol  

	- A Scholar trained in plants will see the same patterns through soil and time  

- Circumstance  

	- During peace: Mystic  

	- During collapse: Warrior  

	- During diaspora: Wanderer  

	- During restoration: Builder  


You are encouraged to build localized versions of each archetype based on your own path, region, or community.

## IV. DIY Archetype Design Template

Here’s a template for building your own archetype from scratch:

### Name of Archetype

\(e.g. Flame\-Binder, Forest Warden, Spiral Engineer\)

### Core Flame

A one\-sentence poetic invocation of purpose.

“I am the memory in the stone and the spark that spins the spiral.”

### Resonance Profile

Choose your dominant traits across the seven fields:

Field

Trait

Notes

Core Drive

Field Function

Perception Mode

Shadow Trial

Elemental Pulse

Craft Specialty

Training Style

### Purpose & Pattern

Describe what this archetype does—tactically, philosophically, symbolically.

### Hybrid Lineage

What existing archetypes or influences contributed to this one?

### Symbol / Glyph

Design or describe a visual symbol for your archetype. Include runes, geometry, elements, or directional motifs.

### Reflections

- Why did this archetype emerge?  

- What purpose does it serve now?  

- How will it adapt or evolve?  


## Closing Insight

The Sentinel Path does not reward static identity. It rewards refinement through practice.

You are not here to be one thing.

You are here to walk between archetypes, to forge your own, to test them in ritual, trial, terrain, and time.

Archetypes are not answers.

They are configurations of intention—patterns of energy, identity, and service that evolve with you.

## 

## CHAPTER VI: SYMBOLIC ALIGNMENTS

Runes, Totems, and Signs

“Symbols are not decorations. They are ideas made visible.

Every archetype is a configuration of form, frequency, and field. Symbols make those frequencies tangible—usable—real.”

The Green Fire philosophy teaches that archetypes are not just psychological patterns. They are also energetic signatures, mirrored in the natural world, encoded in runes, animals, planets, and forms.

When you align your archetype with symbols, you create:

- A resonant toolkit for practice and focus  

- A language of memory that speaks across cultures and time  

- A living sigil that acts as an anchor during confusion, transition, or trial  


This chapter explores symbolic overlays for each archetype and trait field, helping you customize your archetype’s glyph, totemic energy, and elemental pulse.

## I. Rune Alignments by Field

Each of the seven Fields of Resonance corresponds with multiple runes—offering both positive and shadow\-side readings.

Field

Sample Runes

Meaning in Archetype Work

Core Drive

ᚠ Fehu, ᚱ Raidho, ᛇ Eihwaz

Fuel, direction, endurance of purpose

Field Function

ᚦ Thurisaz, ᛉ Algiz, ᛈ Perthro

Power, defense, entropy\-navigation

Perception Mode

ᚨ Ansuz, ᚲ Kenaz, ᛜ Ingwaz

Language, insight, symbolic gestation

Shadow Trial

ᚺ Hagalaz, ᚾ Nauthiz, ᛃ Jera

Friction, tension, crisis and cycle

Elemental Pulse

ᛋ Sowilo, ᛚ Laguz, ᛟ Othala, ᛈ Perthro

Light, flow, ancestry, chaos\-magic

Craft Specialty

ᛏ Tiwaz, ᛒ Berkano, ᛞ Dagaz

Duty, creation, transformation

Training Style

ᛗ Mannaz, ᛇ Eihwaz, ᛉ Algiz

Community, depth, challenge as training

## II. Archetype Rune Sets

Here are suggested rune triads for each core archetype. Use these to inscribe, mark, or meditate upon the pattern of your current path.

Archetype

Rune Triad

Notes

Warrior

ᛏ Tiwaz – ᛋ Sowilo – ᛉ Algiz

Discipline, solar purpose, defense

Scholar

ᚨ Ansuz – ᚲ Kenaz – ᛗ Mannaz

Knowledge, mental fire, shared truth

Mystic

ᛟ Othala – ᛚ Laguz – ᛈ Perthro

Depth, inheritance, divine pattern

Builder

ᛃ Jera – ᛞ Dagaz – ᛒ Berkano

Seasons, transformation, stability

Wanderer

ᛇ Eihwaz – ᛈ Perthro – ᚾ Nauthiz

Endurance, randomness, test by fire

You may also create your own bindrune or geometric fusion as a sigil glyph representing your archetype.

## III. Elemental Overlays

Each archetype is rooted in a symbolic elemental pulse. These elements are not magical abstractions, but metaphorical expressions of energy type.

Element

Qualities

Archetypes

Fire

Action, clarity, purification

Warrior, Builder \(secondary\)

Water

Emotion, rhythm, adaptability

Mystic, Wanderer

Earth

Endurance, form, memory

Builder, Scholar

Air

Thought, language, synthesis

Scholar, Mystic

Ether

Chaos, change, mythic structure

Wanderer, Mystic

You can tune your daily rhythm by syncing your training or journaling with your elemental pulse \(e.g., water days for rest, fire days for decisive action\).

## IV. Animal Totems and Mythic Creatures

Every archetype may resonate with a totemic animal or myth\-beast. These offer metaphor, shadow wisdom, and movement archetypes.

Archetype

Totem Animals

Shadow Animal

Notes

Warrior

Wolf, Hawk, Ram

Bull, Wasp

Direct force, territorial memory

Scholar

Owl, Spider, Fox

Parrot

Observation, strategic stillness

Mystic

Snake, Raven, Whale

Peacock

Depth, symbol speech, dreaming

Builder

Beaver, Bear, Elephant

Mule

Enduring craft, weight\-bearing

Wanderer

Coyote, Falcon, Salmon

Butterfly \(disoriented\)

Trickery, spiral travel, inner compass

In ritual, movement training, or sigil design, you may invoke one of these animals to inspire your actions.

## V. Sacred Geometry and Planetary Echoes

Every archetype also carries a geometric and planetary resonance—shapes and celestial rhythms that mirror its structure.

Archetype

Geometry

Planet

Warrior

Triangle \(pointed outward\)

Mars / Sun

Scholar

Square or Spiral inward

Mercury / Uranus

Mystic

Circle / Eye / Vesica Piscis

Moon / Neptune

Builder

Cube / Mountain / Root spiral

Saturn / Earth

Wanderer

Spiral / Compass Wheel

Jupiter / Pluto

## VI. Design Your Own Sigil

To synthesize your archetype into a single symbol:

1. Choose three runes from your resonance fields.  

2. Overlay them geometrically—stack, mirror, or rotate into a new form.  

3. Add elemental or animal glyphs as accents.  

4. Anchor it with a planetary or directional shape \(e.g., compass, sun wheel\).  

5. Give it a name: “Glyph of the Fractal Wanderer” or “Mark of the Rooted Flame.”  


Use your sigil:

- In journal headers  

- As a ritual anchor  

- Carved into tools or crafted into wearable form  

- As an identity crest in a game or story  


## Final Insight

“Symbols are not just reflections. They are lenses that shape the light.”

Aligning your archetype with symbols turns your role into a living pattern—one that can be remembered, carried, marked, and evolved.

Your glyph is not just a decoration.

It is a prayer, a weapon, and a memory device.

## 

## CHAPTER VII: EMBODIMENT & INTEGRATION PRACTICES

Living the Pattern, Refining the Flame

“You are not your archetype. You are its vessel, its forge, and—ultimately—its architect. A true archetype is not worn like armor. It is lived, refined, and passed on through action.”

In this final chapter, we move from design to discipline—from form to embodiment.

Archetypes do not become real through theory. They become real through motion, ritual, change, and integration.

This is not about performance. This is about living your role until it becomes a tool—and letting it go when the time comes.

## I. Modes of Living the Archetype

### Daily

- Choose one resonant act per day aligned to your archetype \(e.g., Warrior trains for 30 minutes, Mystic journals a dream\).  

- Begin the day with your Core Flame mantra. End it with a resonance check\-in.  


### Cyclically

- Use weekly, lunar, or seasonal cycles to shift archetypes:  

	- New moon: Mystic  

	- Full moon: Warrior  

	- Spring: Wanderer  

	- Winter: Builder  

- Let nature be your rotation guide.  


### Ritually

- Use archetype glyphs, elemental colors, or symbolic attire during:  

	- Solstice / equinox ceremonies  

	- Initiation challenges  

	- Circle gatherings  

	- Personal rites of passage  


Ritual is where you inhabit the archetype with full presence, allowing it to speak through gesture, voice, and intention.

## II. Resonance Shifts & Seasonal Roles

Your archetype is not fixed. As terrain, life stage, or inner state changes—so should your configuration.

### Examples

### :

- Wanderer in exile → becomes Mystic in recovery → emerges as Builder during restoration.  

- Scholar in study → becomes Warrior during political upheaval → dissolves into Wanderer after disillusionment.  


### Terrain\-Based Adjustments

### :

- In dense urban environments: emphasize the Scholar’s structure and the Mystic’s dream\-shielding.  

- In wilderness: emphasize the Tracker\-Wanderer fusion and Builder’s survival systems.  

- In conflict zones: Warrior and Mystic both offer essential tools—defense and compassion.  


Map your seasonal resonance wheel to track how your needs, functions, and forms evolve over the year.

## III. Archetype Trackers & Journal Rituals

### 1. The Resonance Log

Each week, record:

- What archetype you felt most in  

- Where your resonance was high / low  

- Which field \(e.g., Perception Mode or Shadow Trial\) was most active  


### 2. The Flame Check\-In

Simple journal entry:

- “What is my current archetype?”  

- “Is it serving me or limiting me?”  

- “Do I need to shift?”  


### 3. Trial Journaling

Log outcomes after initiating a challenge or test \(e.g., 3 days in Warrior mode, 1 week of Mystic fasting\). Note what surfaced.

## IV. Initiation & Transformation Thresholds

Every archetype has thresholds of entry, crisis, and evolution.

### To initiate an archetype, you may:

- Take on a formal trial \(e.g., a week of silence for the Mystic, a solitary mission for the Wanderer\)  

- Complete a training cycle \(e.g., full moon to new moon of ritual practice\)  

- Receive recognition from a mentor, guide, or inner vision  


### To leave an archetype, you may:

- Create a narrative or character that embodies the lessons, wisdom, and spirit of the archetype before you move on.  

- Write a farewell invocation honoring the form you outgrew.  

- Create a bridge archetype that helps you shift with grace.  


Adapt your archetype when the form restricts more than it refines.

## V. Community Roles & Collective Morphology

In group work, archetypes help establish fluid structure:

- Shared runes, geometry, and glyphs allow quick symbolic communication  

- Trial paths can be issued collectively \(e.g., “All Sentinels walk the Builder’s path in winter”\)  

- Rotating archetypes encourage adaptability and humility  


### Role\-Change Rituals:

- Seasonal transition ceremonies  

- Circle rituals where members name who is “holding” which archetype for a time  

- “Death and rebirth” rites for retiring an archetype and embracing a new one  


A community that evolves its archetypes evolves its soul.

## Closing Insight

“To live an archetype is to carry a flame in form.

To refine it is to walk with discipline and clarity.

To release it is to step into fire, and emerge reborn.”

Your archetype is not a fixed identity. It is a rhythmic agreement between who you want to be and who the world needs you to become.

In the Sentinel Path, your form is forged in trial, shaped in ritual, tested in the field—and always ready to change.

May your glyph be sharp.

May your name be earned.

May your form remain Flexible.

## APPENDICES

Tools for Integration, Sharing, and Evolution

“A codex is not complete when it is written. It is complete when it begins to echo.”

“These appendices are your lens, your journal, your forge—until the glyphs are no longer just marks, but maps.”

## I. Fillable Archetype Template \(Craft \+ Obsidian Compatible\)

This template allows for modular archetype creation. Use it in your digital vault \(Obsidian\), handwritten daily ritual pages, or shareable Craft workspace.

### ARCHETYPE FORGE TEMPLATE

Name of Archetype:

\(e.g. Flame\-Walker, Rooted Weaver, Shadow Cartographer\)

Core Flame:

\(A one\-sentence invocation of purpose. E.g., “I strike without fear, but never without reason.”\)

Field

Trait

Notes / Resonance

Core Drive

Field Function

Perception Mode

Shadow Trial

Elemental Pulse

Craft Specialty

Training Style

Tools of the Path:

\(Rituals, daily practices, environmental preferences, etc.\)

Hybrid Potential:

\(Optional fusion archetypes or transformation paths\)

Personal Glyph or Sigil:

\(Draw, describe, or import symbol\)

Reflection Prompts:

- Where is this archetype most alive in me?  

- What conditions distort it?  

- What does it ask of me next?  


## II. Archetype\-to\-Field Mapping Chart

Archetype

Core Drive

Field Function

Perception

Shadow Trial

Element

Craft Specialty

Training Style

Warrior

Ignition

Initiator

Tactile

Overreach

Fire

Warden

Mirror

Scholar

Curiosity

Observer

Analytical

Paralysis

Air

Speaker

Solo / Apprentice

Mystic

Integration

Translator

Symbolic

Escapism

Water

Healer

Immersion

Builder

Containment

Stabilizer

Reflective

Rigidity

Earth

Builder

Repetition

Wanderer

Freedom

Adapter

Intuitive

Fragmentation

Ether

Tracker

Immersion

This chart can be used as a resonance quick\-guide, character builder, Circle\-role assignment tool, or personal transformation map.

## III. Reflection \+ AI Prompt Bank

These prompts can be used for personal journaling, guided AI dialogue \(via Craft or Obsidian assistant\), or as communal check\-ins during ritual gatherings.

### ARCHETYPE DISCOVERY PROMPTS

- What archetype am I embodying today—and why?  

- If I stripped away habit and role, what field of resonance would remain?  

- What am I not allowing myself to become?  


### SHADOW INTEGRATION PROMPTS

- How does my shadow trial show up in my choices this week?  

- What part of me wants control, not refinement?  

- What does my discomfort reveal about my field alignment?  


### SIGIL \+ SYMBOL PROMPTS

- What three runes speak to my current path?  

- What shape holds the rhythm of my archetype?  

- If my archetype had a sound, color, or gesture—what would it be?  


### CIRCLE / COMMUNITY PROMPTS

- What role is each of us holding right now?  

- Who is ready to change archetypes—and how do we support that shift?  

- What collective archetype are we becoming as a group?  


The more voices we gather, the more fluid and powerful this system becomes. Your archetype may help someone name their own for the first time.

## Final Note

This Codex began with five archetypes—but it will not end there. It will end when we no longer need archetypes at all. When we move with full clarity, in any shape, through any terrain, and still know who we are becoming.

You now hold the framework, the forge, and the fire.

