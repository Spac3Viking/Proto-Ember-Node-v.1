# Loadout / Tool Seeds

*What the Body Carries — and Why*

Symbolic compression. Tools are not flavor. They reveal philosophy. A Loadout Seed includes: weapon or tool, maintenance state, scarcity or abundance, and symbolic meaning. Example logic: A perfectly maintained rifle tells a different story than a powerful weapon with no decoration.

## Seeds

### 1. The Maintained Rifle

Cleaned obsessively, rarely fired. Represents discipline, restraint, and the fear of becoming careless.

### 2. The Improvised Blade

Forged or shaped from scrap. Reliable but imperfect. Carries the mark of necessity over elegance.

### 3. The Inherited Knife

Old steel, passed down. Has outlived its original owner. Memory rides in the grip.

### 4. The Empty Sidearm

Carried without ammunition. Used as deterrent or symbol. A reminder of scarcity—or bluff.

### 5. The Overloaded Pack

Contains tools for every contingency. Weight slows movement. Preparedness competes with endurance.

### 6. The Minimalist Kit

Only the essentials. Fast, quiet, fragile. Survival depends on judgment, not redundancy.

### 7. The Patched Armor

Layered repairs from different eras. Every patch marks a lesson learned the hard way.

### 8. The Heirloom Tool

A hammer, axe, or shovel built to last generations. Carries pride—and expectation.

### 9. The Broken Device

Advanced tech that almost works. Teaches frustration, hope, and dependency in cycles.

### 10. The Analog Compass

Never fails, but never explains. Requires interpretation. Trust replaces certainty.

### 11. The Ritual Weapon

Carried for meaning more than function. Used rarely. Its presence changes behavior.

### 12. The Medical Satchel

Always lighter after use. Each empty space marks a life altered—or saved.

### 13. The Salvaged Optic

Old scopes or binoculars. Clear vision at a distance, blindness up close.

### 14. The Weathered Cloak

Camouflage, warmth, anonymity. Hides the body and sometimes the self.

### 15. The Toolbelt of Many Trades

Versatile but noisy. Signals competence—and makes the bearer indispensable.

### 16. The Firestarter Kit

Reliable flame under bad conditions. Represents foresight and quiet confidence.

### 17. The Silent Weapon

Bow, blade, or suppressed tool. Demands proximity. Forces confrontation with consequence.

### 18. The Scarce Ammunition

Powerful but limited. Every use is a moral decision.

### 19. The Power Cell

Finite energy source. Hoarded, rationed, fought over. Time is measured in charge.

### 20. The Marked Armor

Inscribed with symbols, runes, or tally marks. Identity worn externally.

### 21. The Farming Implements

Tools meant to feed, not fight. Survival through patience and repetition.

### 22. The Multi-Use Rope

Simple, overlooked, essential. Saves lives quietly.

### 23. The Communication Relic

A radio, handset, or signal device. Connects—or reminds of silence.

### 24. The Heavy Weapon

Devastating but conspicuous. Protection that invites escalation.

### 25. The Scavenger Rig

Designed to strip, haul, and repurpose. Turns ruins into opportunity.

### 26. The Load-Bearing Exoshell

Mechanical or improvised assist. Extends strength, shortens lifespan.

### 27. The Water Kit

Filters, containers, tablets. Life carried in measured weight.

### 28. The Worn Gloves

Calloused, patched, irreplaceable. Hands remember work the mind forgets.

### 29. The Symbolic Token

Coin, rune, badge, or charm. Meaning exceeds material value.

### 30. The Night Gear

Goggles, lamps, or trained senses. Reveals what others miss—and what they fear.

### 31. The Incomplete Set

Missing a critical component. Forces improvisation or dependence on others.

### 32. The Child's Item

Toy, book, or drawing carried for grounding. Fragility as anchor.

### 33. The Burdened Relic

Powerful, dangerous, or cursed tool. Survival improves—but alignment erodes.

---

*33 seeds. Derived from `client/src/data/saga-seeds.ts`. Re-run `tsx scripts/build-saga-cache-content.ts` after edits.*
