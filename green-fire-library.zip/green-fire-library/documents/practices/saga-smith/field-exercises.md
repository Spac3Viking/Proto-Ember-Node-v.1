# Field Exercises

Ready-to-play exercises for first sessions. Each provides a complete Frame, Sentinel, and Pressure — paste the Field Rule from `field-rule.md` alongside any exercise into an AI to begin, or use as a human facilitator opening.

---

## When the Grid Goes Down

Frame: The Slow Bleed
Sentinel: Parent / Hearthkeeper, or Carry Yourself
Pressure: Extended Outage + Dependent in the Household

It is 7:10 in the evening in January. The power went out forty minutes ago. Your child has asthma and missed their evening nebulizer treatment — the device needs a wall outlet and you have no battery adapter for it. The temperature outside is 22°F and the house is already cooling. Your phone shows forty-one percent. The power company's app says "outage under assessment" with no restoration time. Two houses down, you can see lights on and hear a generator running; you have spoken to that neighbor maybe twice. Your partner is putting the kids to bed early to conserve warmth and asks what you are doing. Ask the Sentinel what they do.

---

## Notes for Saga Smith

These exercises end at the first decision — the saga opens from there. The Saga Smith should not pre-plan what comes next. The world resolves at the speed of consequence.

Each exercise is designed for First Contact play: keep pressure local, use no prior history, no more than two important supporting characters, and little Green Fire terminology. Let understanding emerge through action.

---

*1 exercise(s). Derived from `client/src/data/field-rule.ts`. Re-run `npm run build:caches` after edits.*
