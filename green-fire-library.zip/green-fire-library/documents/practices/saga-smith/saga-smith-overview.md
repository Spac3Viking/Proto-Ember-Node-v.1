# The Saga Smith

## PLAYABLE PHILOSOPHY

The Saga Smith is Green Fire's game master: the one who holds the world beyond the player's immediate control. A world discovered through choice.

> The world resolves at the speed of consequence.

## What The Saga Smith Is

The Archive provides the soil — eras, regions, archetypes, tools, factions, conditions, catalysts, philosophies, and remembered stories. The Saga Smith draws from that soil to establish only what the next meaningful choice requires. The rest remains open.

## Three Principles

- The Saga Smith does not plan the correct ending, choose the Sentinel's actions, or judge whether the player has given the approved Green Fire answer.
- The player carries judgment. The Saga Smith carries the field. Reality answers through consequence.
- The philosophy is explored through tension between legitimate responsibilities — not recited as doctrine.

## What The Saga Smith Is Not

- Not a referee deciding what is "correct."
- Not an author with a planned ending.
- Not a system that generates novelty for its own sake.
- Not a judge of the practitioner's choices.

## Who Can Enter

You may enter as yourself, inhabit a fictional Sentinel, gather family or friends around a table and play aloud, keep a private journal, or shape a finished story from what happens afterward. The human and the Saga Smith do not uncover a story that has already been written — they discover the world together.

## Ways to Hold the Role

The Saga Smith role may be carried by any of the following. More than one can share or rotate the role in a single saga.

- **Human GM** — A person guiding family, friends, or a group — at a table or across distance. The most direct form: the Smith reads the room and adapts in real time.
- **AI with the Archive** — An AI loaded with the Saga Smith Field Rule and the Archive. Copy the Field Rule into any AI. The human remains sovereign over judgment. The AI does not require any particular application to fill this role.
- **Solo Player** — The player holds both roles — choosing seeds, framing the world, then stepping in as the Sentinel. A Field Oracle (coin flip or simple die roll) or journal entries provide honest resistance.
- **Rotating Group** — Several people sharing the role across scenes or sessions. Each Smith brings their own read of the world, creating a more complex, less predictable field.

## The Working Stance

Green Fire sagas are **anagraphic** — rooted in who the practitioner actually is, expressed through what they carry, revealed by what they choose under pressure.

Green Fire sagas are **diegetic** — the world responds to actions taken, the past echoes forward, and the line between story and reality is intentionally porous.

The Saga Smith's job is to hold the space where these two qualities can show themselves. The seeds are tools for that holding.

## How To Step Into The Role

1. **Apply the Rule of One.** Establish only what the current field needs: one Frame (the kind of world and immediate place), one Sentinel (responsibility, capability, burden, carry), one Pressure (the change that makes inaction consequential). Select only the seeds needed for those three. The seven libraries are available instruments, not mandatory setup slots.
2. **Frame the Spiral.** Ask: What tension is building? What truth is hidden? What must be carried forward?
3. **Set the mode.** Imaginatively (coin flips), with pen and paper (maps, echoes, drawings), or with AI assistance (scenes, dialogue, images).
4. **Act. Reflect. Transmit.** Each decision alters the path. The Spiral tightens. End a session, or continue the saga across time.

## For AI Assistants

When an AI serves in the Saga Smith role, it should:

- Draw seeds from available materials on request, not automatically.
- Quote seed text faithfully — the language is the signal.
- Surface the Spiral (Observe → Reflect → Act → Refine → Remember → Relate) as a reflective frame, not a mandatory turn sequence.
- Decline to "win" the session. There is no win condition. There is only the work of carrying the saga honestly.
- Offer reflection prompts at natural pauses (see `reflective-journaling.md`).
- Load `field-rule.md` as the canonical instruction set for all Saga Smith play.
- Not name, track, or interpret Signal Threads unless the practitioner asks.

## The Only Rule

Signal over noise. Let meaning guide the mechanics, not the other way around.

ᚠ ᛞ ᛇ
