# Character Seeds

*Archetype +Experience*

Each Character Seed contains: an Archetype (Builder, Warrior, Archivist, Scout, Teacher, Sentinel), internal tension (fear, doubt, loyalty, ambition), and a pressure point where alignment can break or deepen. Characters are not special because of destiny—they're special because they are tested.

## Seeds

### 1. The Reluctant Protector

Took responsibility to prevent harm, not to lead. Now trapped between duty and resentment.

### 2. The Disciplined Survivor

Lives by routine and preparedness. Struggles when chaos demands improvisation.

### 3. The Idealist Builder

Believes systems can be rebuilt better than before. Risks ignoring human messiness.

### 4. The Pragmatic Hunter

Values efficiency over reflection. Measures success in calories and distance, not meaning.

### 5. The Archivist in the Field

Carries knowledge into danger. Must choose what to preserve—and what to let burn.

### 6. The Inherited Leader

Didn't seek authority but received it anyway. Haunted by comparisons to predecessors.

### 7. The Quiet Medic

Saves lives without asking allegiance. Slowly accumulates moral debt no one repays.

### 8. The Scarred Veteran

Survived violence through skill and luck. Fears becoming obsolete—or worse, unnecessary.

### 9. The Skeptical Scout

Trusts terrain more than people. Sees patterns others miss, connection less so.

### 10. The Devout Technician

Maintains machines with ritual precision. Believes failure is a moral flaw.

### 11. The Cultural Translator

Moves between factions fluently. Risks losing a stable sense of self.

### 12. The Defiant Youth

Questions inherited rules instinctively. Courage borders on recklessness.

### 13. The Relic Bearer

Carries an object older than the current world. Unsure whether it is burden or guide.

### 14. The Soft-Spoken Strategist

Prefers preparation to force. Struggles when plans collapse mid-action.

### 15. The Ethical Mercenary

Sells skill but not soul—or so they claim. Lines blur with repetition.

### 16. The Ritual Keeper

Maintains ceremony to hold community together. Risks mistaking form for meaning.

### 17. The Exile by Choice

Left safety to preserve autonomy. Loneliness tests conviction.

### 18. The AI Listener

Interprets machine guidance intuitively. Unsure where insight ends and projection begins.

### 19. The Hardened Farmer

Feeds others through patience and labor. Hates being underestimated.

### 20. The Memory Child

Born after collapse, raised on stories. Searches for truth beneath myth.

### 21. The Border Negotiator

Lives in contested space. Trust is currency—and always in short supply.

### 22. The Firebrand Speaker

Inspires action through words. Must confront consequences of belief made contagious.

### 23. The Broken Specialist

Expert in a single vital skill. Identity collapses if that skill becomes obsolete.

### 24. The Observer Who Acts

Trained to watch, not intervene. Forced into decisive action against instinct.

### 25. The Unarmed Defender

Rejects weapons on principle. Belief is tested when others pay the cost.

### 26. The Load-Bearer

Carries more than their share—gear, guilt, responsibility. Strength masks exhaustion.

### 27. The Adaptive Nomad

Thrives on movement and novelty. Stillness feels like death.

### 28. The Hidden Traitor

Once betrayed a group to survive. Lives with permanent vigilance and shame.

### 29. The Pattern Seer

Recognizes recurring cycles across time and place. Struggles to act within them.

### 30. The Reluctant Myth

Others project meaning onto them. Feels trapped by symbol rather than self.

### 31. The Last Apprentice

Trained for a world that no longer exists. Must reinvent their craft.

### 32. The Careful Rebel

Resists systems quietly. Patience competes with urgency.

### 33. The Unfinished Sentinel

Knows the philosophy but hasn't embodied it yet. The saga is the training.

---

*33 seeds. Derived from `client/src/data/saga-seeds.ts`. Re-run `tsx scripts/build-saga-cache-content.ts` after edits.*
