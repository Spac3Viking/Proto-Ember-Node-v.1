# Level 3 — Saga Smith Architecture Map v3

*A Continuity Practice for Participation, Understanding, and Long Transmission*

## Orientation

Saga Smith is the experiential practice layer of Green Fire.

It is designed to help transform:

- Experience into Understanding
- Understanding into Wisdom
- Wisdom into Transmission

The purpose is not storytelling alone. The purpose is not journaling alone. The purpose is not simulation alone.

The purpose is participation.

## The First Principle

> Continuity becomes wisdom when reflection is tested through action and refined through consequence.

Observe → Reflect → Act → Refine → Remember → Relate

This spiral forms the foundation of Saga Smith. Everything else exists to support it.

## The Sentinel

The Sentinel is the human participant.

The Sentinel contributes meaning, imagination, judgment, responsibility, creativity, and lived experience.

The Sentinel remains the source of interpretation. No tool replaces this role.

## The Saga Smith Role

The Saga Smith holds everything beyond the Sentinel's direct control: environment, time, uncertainty, other people, hidden causes, and consequence. The Saga Smith never chooses for the Sentinel.

The role may be carried by: a human game master, an AI loaded with the Field Rule and Archive materials, a solo player holding both roles, or a rotating group sharing the role across scenes.

## Ways to Practice

Saga Smith is portable. It runs on:

- Paper, notebooks, and physical maps
- Conversation with another person
- Family or group play at a table
- Solo journaling with dice or coin flips for uncertain outcomes
- Any capable AI loaded with the Field Rule
- A future Ember Node application

The practice survives the tool. No application, no AI, and no particular format is required.

## Archetypal Lenses (Optional)

Archetypal lenses are optional perspectives — ways of seeing a situation. Examples include Builder, Warrior, Scholar, Mystic, and Scribe. A lens is not a required room, a persistent AI personality, or an automatic mode. The Sentinel chooses when and whether to use one.

## Signal Threads (Optional)

A Signal Thread is a reflective artifact — a short name for a meaning that seems to recur across separate sessions, characters, or situations. Signal Threads are optional. They are named only when the practitioner notices a genuine recurrence and deliberately chooses to preserve it.

Signal Threads are not mandatory session containers. A single session or an entire practice may proceed without naming a thread. The practice does not require them to be useful.

## Compression

Compression preserves usability. Compression asks: What is worth carrying forward?

Compression may become notes, symbols, lessons, prompts, codex fragments, saga fragments, signal threads, or cache documents.

Compression is discernment. Not accumulation.

## Transmission

Transmission carries continuity beyond the individual.

Transmission may become teaching, conversation, stories, codices, caches, artwork, songs, archives, or future threads.

Not everything must be transmitted. The Sentinel decides what survives.

## Caches

Caches are continuity vessels. They carry source materials, summaries, artifacts, signal threads, and continuity documents.

Caches allow understanding to travel. They support both humans and AI systems.

## The Long View

Saga Smith assumes technologies will change, platforms will disappear, archives will fragment, and languages will evolve.

Therefore the practice must remain portable, human-readable, adaptable, and decentralized.

The structure should survive software, hardware, organizations, and generations.

## The Ultimate Output

The goal of Saga Smith is not content. The goal is not stories. The goal is not simulations. The goal is not completion.

The goal is the cultivation of capable stewards — people who:

- observe carefully
- think symbolically
- act practically
- reflect honestly
- adapt under pressure
- transmit useful wisdom

## Final Principle

Saga Smith is a continuity practice. It helps transform experience into understanding, understanding into wisdom, and wisdom into transmission.

The purpose is not accumulation. The purpose is not preservation alone. The purpose is participation.

From participation comes understanding. From understanding comes wisdom. From wisdom comes transmission. And the cycle continues.

---

*Stewarded through the Green Fire Archive. Designed for reflection, continuity, participation, and long transmission.*
