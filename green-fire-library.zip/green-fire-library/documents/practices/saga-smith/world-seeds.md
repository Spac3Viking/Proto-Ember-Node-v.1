# World Seeds

*Macro conditions & metaphysical pressure*

World Seeds define what kind of reality the saga inhabits, not just when. Subtypes: Pre-Collapse (false stability, denial), Mid-Collapse (fragmentation, violence), Early Post-Collapse (memory vs necessity), Late Post-Collapse / Regrowth (myth replaces history), Cross-Temporal / Spiral Worlds (recursion, echoes), AI-Saturated Worlds (librarians, watchers, corrupted gods). Key questions embedded in every World Seed: What illusion is still believed here? What truth is being avoided? What survives when systems fail?

## Seeds

### 1. The Slow Bleed

Collapse never announced itself. Systems still function—barely. Everyone agrees things are "fine" because admitting otherwise would demand change.

### 2. False Stability

Cities shine, lights stay on, shelves are stocked—but only because unseen costs are being deferred onto someone else.

### 3. The Last Normal Year

People still plan futures: careers, children, expansions. Only a few notice that every plan assumes a past that no longer exists.

### 4. Managed Decline

Authorities acknowledge collapse privately but manage it publicly through language, rationing, and narrative control.

### 5. The Fracture Line

Collapse hit unevenly. Some regions thrive, others burn. Travel reveals incompatible realities sharing the same map.

### 6. Scarcity Compression

Resources exist, but access is violently contested. Moral decisions must be made quickly and without certainty.

### 7. The Long Emergency

Everyone knows this isn't temporary—but no one knows what comes next. Fatigue shapes culture more than fear.

### 8. Signal Noise

Truth is buried under misinformation, half-working networks, and competing explanations. Meaning must be extracted manually.

### 9. Ash Season

Wildfires, industrial burns, or chemical smog define the calendar. Survival depends on reading the air as much as the land.

### 10. Frozen Time

Winter lasts longer than memory. Communities measure survival in stored calories, insulation, and trust.

### 11. Dry Bones

Water scarcity shapes politics, movement, and belief. Rivers are borders. Springs are sacred—or fought over.

### 12. Rewilding Zones

Nature returns aggressively. Forests swallow suburbs. Wildlife outpaces humans. The land no longer negotiates.

### 13. Enclave Age

Small, self-contained societies form with rigid identities. Each believes it has solved survival—until tested by outsiders.

### 14. Archive Worlds

Knowledge survived, but context didn't. Old texts, data vaults, and AI fragments are treated as prophecy or law.

### 15. The Broken Network

Fragments of pre-Collapse infrastructure still operate, but no one understands the whole system anymore.

### 16. Technological Orphans

Advanced tools exist without the means to repair them. Power becomes finite, sacred, and contested.

### 17. The AI Afterlife

Artificial intelligences persist as librarians, guardians, or false gods—each shaped by corrupted objectives and incomplete data.

### 18. Machine Myth

Technology has been ritualized. Machines are prayed to, feared, or obeyed without comprehension.

### 19. Ghost Protocols

Automated systems still enforce laws, defenses, or logistics long after their creators vanished.

### 20. The Watching World

Surveillance systems still function. Someone—or something—is always observing, but never intervening.

### 21. Early Regrowth

Communities stabilize. Crops grow. Children are born who never knew the old world. Myth begins to replace memory.

### 22. Selective Remembering

Cultures intentionally forget parts of history to survive. What is omitted matters more than what is taught.

### 23. Inheritance Pressure

The next generation questions the ethics of survival decisions they didn't make but must live with.

### 24. The Steward's Dilemma

Leaders must decide whether to preserve systems that work—or dismantle them before they rot.

### 25. Myth Crystallization

Stories harden into doctrine. Heroes become symbols. Truth becomes less important than coherence.

### 26. The World After Victory

The war is over. The enemy is gone. No one agrees on what the victory meant—or what comes next.

### 27. The Gentle Tyranny

Life is safe, predictable, and controlled. Freedom is framed as dangerous nostalgia.

### 28. Spiral Time

Events repeat across generations. Places remember choices. Different characters face the same test in new forms.

### 29. Echo Worlds

Artifacts, phrases, and symbols recur across regions with altered meanings. Someone notices the pattern.

### 30. The Long Memory

Nothing is ever truly lost. Every action leaves a trace that resurfaces later—often misinterpreted.

### 31. The Threshold Era

The world balances between collapse and renewal. Small decisions now determine centuries later outcomes.

### 32. The Unfinished World

Collapse paused mid-motion. No one knows whether to prepare for rebuilding or final failure.

### 33. The Living Question

The world itself feels undecided—responding differently to those who approach it with control versus alignment.

---

*33 seeds. Derived from `client/src/data/saga-seeds.ts`. Re-run `tsx scripts/build-saga-cache-content.ts` after edits.*
