---
title: "ᛋ᛬ SENTINEL SAGAS: VOLUME I — Ash and Bloom"
description: "The first collected volume of Sentinel Sagas exploring resilience, transformation, and the Green Fire path"
category: "sentinel-sagas"
order: 1
---

## SENTINEL SAGAS: VOLUME I — Ash and Bloom

# The Builder’s Debt

“Keep the mill turning. Start studying.”

## I. The River

The river slowed, but it had not stopped yet.

Ash from the burned highlands choked its edges. Rusted wreckage twisted beneath the surface. The old dam still stood, half\-cracked. Straining under pressure of a world too broken to remember its former glory.

And yet, it powered Lowhollow.

Three hydro generators—retrofitted with old electric motors and turbines welded from scrap—churned inside the crumbling spillway. Not elegant. Not stable. Just enough for lights, and charging a few batteries.

Doran kept them running.

He lived in a rusty shed beside the sluice. No one knew much about him. He woke before the sun. Ate alone. Patched leaks, replaced bad wiring. The villagers left him alone—grateful, but wary.

Except for Elna.

## II. The Girl

Elna was sixteen and thin in the way that meant she worked too hard and didn’t eat enough meat. She brought Doran food—usually leftover bread or smoked roots—because no one else would. And because she watched the village lights, they usually got dimmer, once in a while they would pulse and shine a little brighter again. She knew that meant he had fixed something.

“You ever leave that shack for anything other than work?” she asked once, half\-joking.

“Only come out when I’m needed,” he said, closing as he closed the access panel on one of the generators.

“Whole place would fall apart if you stopped pretending you owed us something.”

He didn’t answer. But he didn’t tell her to leave either.

Over time, she started noticing things like extra wires running from the main conduit into the upper mill. A second, silent wind turbine turning behind the main shed, feeding something else. An odd smell—metal and ozone—from vents on the mill she didn’t remember being there.  


The rest of the village didn’t go near the old mill building. Too unstable. Too haunted. Elna used to play in it with her older brother. Deep in the large machine rooms the forest had encroached so much it seemed more like a sacred grove than an industrial site. She never explored it anymore once her brother left for the wars, it didn’t feel right being there without him and now it did give her the creeps, a few years later Doran had arrived in town and made the mill his home, now she just watched it.

She knew something was happening inside.

## III. The Arrival

They heard the engine before they saw it—growling down from the ridge like a slow Stampede.

Their leader, a harsh man who looked unkempt but kept his gear and weapons clean, Roth. He rode in on a gutted all\-terrain hauler  with so many pieces welded on, it resembled something between a throne and a torturer's implement. His crew dismounted from the raised bed—six raiders in old military gear reinforced with bits of scrap—spread out around the center square like they were already in control.

“This water’s under reclamation,” Roth announced. “Tidehold’s got claim on all hydro and power. Congratulations—you’re annexed.”

He grinned.

“You keep the lights on for now. We’ll be back soon to figure out the best way to take the power and water you owe us.  We will get the lion’s share, but cooperation buys you protection.”

No one spoke.

Roth turned his eyes toward the mill.

“Let’s hope your fixer knows who runs the river now. If he can’t give us what we want. We‘ll replace him with someone who does.”

## IV. The Mill

Doran didn’t show up at the meeting.

He was under the spillway, cleaning out a sediment screen and checking an old release most of the village didn’t know existed.

Elna found him that evening, sitting outside his shack smoking a carved wooden pipe.

“They’re coming back with more,” she said.

“I know.”

“You should tell them what you’ve done. What’s in there. It’s not just turbines anymore, is it?”

“No,” he said. “It’s not.”

She didn’t press. 

As if in answer to the question she never asked, he got up and walked into his shed. 

He left the door open so she figured that was her invitation. He was already gone, she walked in across the small room —past the subtle door in the back of the shack.  It opened to a hole in the wall of the upper mill, into a wide space where the roof had collapsed and the stars showed through.

There, suspended between old rafters and iron trusses, it hung.

An airship—barebones, patchwork, beautiful.

The gas envelopes, stitched from rubberized canvas and sheeting. With pointed ends and sweeping curves like wings or war canoes. Below, hanging by short ropes and cables braided and knotted in intricate patterns and weaves was the gondola. Made of repurposed pipes and catwalks, it was oddly beautiful. More sculpture than scrap. Overall the ship looked like a bird of prey cobbled together by a sailor with a welder.

large hoses ran down to cylinders and pumps. The lift system—quiet, humming, hydrogen\-generators.

Elna stared.

“You built this?”

Doran nodded.

“I wasn’t planning on using it yet, I was gonna show you guys eventually” he shrugged. “This place had all the resources and privacy I needed.” He chuckled. “This was just a fun retirement project until those goons showed up.”

## V. Time to collect

Roth came back three days later, and this time he brought a dozen men.

A small drone buzzed overhead, mapping the layout of their small community. One of the raiders carried a rugged tablet. Another had wires wrapped around his forearm like jewelry. Evidently the raider engineers. 

They all swaggered toward the dam.

They stopped at the end of the dirt trail, a feeble ribbon of yellow caution tape blocking the path to the mill as it widened into mud and bits of broken concrete.

Doran was waiting—alone—outside his shack on the spillway catwalk.

“Times up, you work for us now.” Roth said.

“No thanks,” Doran said calmly.

Roth sneered. “As if you have a choice, if you're confused, step aside and we can take it over for you” he said, slowly letting each word sink in. He nodded towards one of his maniacal maintenance men crowding the narrow trail leading into the spillway.

“Careful, old spill gate started leaking and I had to do some last minute repairs. It’s not safe over here” Doran said

 With a scoff, one of the raiders stepped forward off the narrow path. His boot sank into a deep puddle. Then he cried out, staggering. Blood streaked the water, a caltrop hidden beneath the surface was now protruding from his heel.

Another moved to help him, ripping through the caution tape. When he pulled it, a slight twang like a snapping string was heard, followed by a mechanical groan as a sluice gate up on the dam spillway opened.

A surge of water blasted over the end of the trail, sweeping half the raiders off their feet and into the stream below. Their screams echoed downriver.

Barely avoiding being swept away with his men, Roth fell back, soaked, shaking.

“You think this makes you safe?”

Doran, unphased, spoke over the surging water.

“I’ll never work for you,” he said. “Just buying myself some time.”

He turned and walked into the mill.

## VI. The Departure

Roth, foaming with rage, left with his few remaining lackeys. Likely to return with a warparty. 

As the small crowd of onlookers dispersed and the rush of water slowed, Elna followed —through the hidden door, into the wide\-roofed chamber lit only by skylight through broken beams.

The ship was already rising.

Vapor vented softly from the rear tanks. The air envelope shifted, catching wind as it rose above the broken ceiling. The gondola creaked gently on its cables.

Doran was aboard, already coiling the ladder and untying lines.

He looked down at her, held her gaze, then pointed to a bundle wrapped in waxed cloth on the bench.

He didn’t wave goodbye.

Just nodded. Once. Then he turned and set to the task of flying his craft. 

The ship lifted—no roar, no blaze. Just the whisper of propellers and the sound of creaking lines, like an old man stretching out his joints after sitting idle too long.

## VII. The Grimoire

Elna opened the bundle as the airship disappeared into the clouds.

Inside she found a wooden\-bound Grimoire, with spirals of copper wire hammered into the wood.

She flipped open the cover of the thick book.

At the bottom of the first page, scrawled in neat, letters:  


You wanted to learn.

Keep the mill turning for these goons.

I’ll bring backup.

Start studying.

She closed the book.

Then turned back toward the forested cathedral of the vast machine room, seeing all of Doran’s improvements— with the weight of the grimoire under her arm, she was happy to be in the old mill again. 

Recon Ridge

Wildland Field log: GRM\-041B

“One breath. That’s all you get. Make it count.”

### I. The Ridge

The wind smelled like thawing snow. Mist clung to the high ridgeline, drifting slowly onto the silent trees of the forest below. Kael padded along the ridgeline, his boots soft on moss, scout armor brushed dull with ash. 

Beside him moved Vetch—silent, precise. Nothing seemed to escape his awareness. He was like a predator on the hunt.  

Kael’s limbs thrummed with numbing adrenaline. It was surreal patrolling along the fabled recon ridge. A terminal moraine left behind by a glacier from the last ice age. All the rocks and soil that were pushed here from up north by millions of tons of ice. When the ice eventually thawed it left a lumpy pockmarked rocky ridge, miles wide stretching across the entire region. With strings of lakes and rugged forests. The land stretched flat and fertile in all directions from it. Since the fall a few generations of sentinels have taken refuge and defended their territory from countless outposts and hidden positions scattered along this string of rocky wooded hills. He was excited and nervous about possibly seeing action. He was trying to focus on his surroundings. 

Below them in the wide valley, a mercenary survey team advanced with practiced ease. Six figures equipped in a standardized contractor kit. Carrying light arms, supported by air and ground drones. They were marking the terrain. Measuring. Claiming.

Kael whispered, “They’re mapping it.”

Vetch said nothing. He was scanning the treeline with something more than his eyes. As if listening for an old rhythm. Like the land could whisper its warnings.

“You’ve been here before?” Kael asked.

Vetch nodded. “Tough to forget Recon Ridge.”

### II. The Cache

Near a cedar stump, Vetch slowed. He knelt and traced a spiral with his finger—barely visible, carved into bark and lichen. A stealth sigil.

“Help me lift,” he said.

Together they pried apart the roots and pulled a cloth\-wrapped bundle from the cavity beneath. Vetch stepped back and gestured to Kael.

“We’ll divide this between our packs.”

Kael unwrapped it—a compact Sentinel pack: reinforced canvas, brass buckles tarnished green, faint sooty resin along the seams.

“What is it?”

“A demolition kit,” Vetch said. “I stashed it last fall.”

Kael glanced up. “Last fall?”

Vetch adjusted the sling of his rifle. “Same ridge. Same mission. Different team.”

### III. The Memory

They trailed the survey crew all day, it was tough to miss due to the swarm of drones constantly circling above them. As dusk spread across the valley, they made their camp in the slope above the merc crew. It was carefully concealed beneath overgrowth, between boulder outcroppings. Kael watched the camp through a scope, a fire flickered below. Laughter. Movement.

Behind him, Vetch sat cross\-legged. Eyes closed. Wrists resting on his knees. His hands were palm\-up holding various finger mudras.

He inhaled. Held it. Released it slowly—like a tide returning to sea.

Kael lowered the scope. “That breathing thing… you really think it helps?”

Vetch opened his eyes. “I know it does.”

Kael smirked, “Seems like superstition to me.”

Vetch chuckled, “Yeah, I used to think the same. Till I realized the difference a calm mind makes, when it counts.

His smile hardened into a serious expression. Then he leaned over and grabbed his pack. He untied the latch and began going through its contents.  “We basically had the same plan last fall. A similar team of merc scouts was pushing through the valley. We wanted to stop them from gathering intel before winter.”

“What happened?”

“I flinched,” Vetch said resignedly. “Accidently shot and triggered our ambush early. Which also gave away our positions.”

Kael said nothing.

“They hit us back hard. My mentor Alec, Stayed behind, bought me time to escape by detonating his pack when the mercs closed in on him. I dragged myself up the hill and hid my pack under that stump. I knew I couldn't stop them by myself, especially wounded.”

He looked toward the valley. “They must think they scared us off. Now they send a survey crew. Roads come next. Then bases.”

Kael asked, “You think stopping them now will change that?”

“I know I failed once already, and I wanna make it right. Or at least keep 'em’ out of our valley for another season.”

Vetch grabbed a few items from his pack, Kael didn’t watch closely enough to see what he grabbed. Vetch unrolled his sleeping mat and rolled up in his rain poncho.

“If you don’t mind, I’ll take second watch.”

“Sounds good to me.” Said Kael. Not willing to argue, and not ready for sleep either.

“I’ll wake you up after midnight.”

### IV. The Mistake

Kael woke to a hazy dawn. His circadian rhythm synced almost perfectly with the sun from a strict morning routine of gazing at the sunrise, when it was visible. Fog clung to the trees like smoke, giving the world an ethereal feel. He was confused because vetch didn’t wake him before sunrise. Down below, the merc camp was stirring. He jumped, and did a double take when he saw three of the crew moving uphill. Sweeping with scanners, weapons at the ready.

Too close.

Kael pressed into the earth, rifle steady, breath short. A bead of sweat slid behind his ear.

He wanted to wait but they would spot him soon. 

He had to react, he aimed.

Fired.

The shot cracked wide—ricocheting off stone. The mercs dropped into cover. One shouted. Another pointed.

Then he heard Vetch rush into the back of their hideout. Kael ducked, breath lost. Pulse hammering. “They saw me\!”

Vetch said nothing. Just moved—calm, fluid, into motion. He grabbed a detonator from its hiding spot under his pack. He lifted a small cover and flicked 3 switches, then pressed a button on the side.

Three explosions shattered the morning. A frag\-charge planted next to the camp sent shrapnel into the mercs taking cover around the flatbed which ignited and destroyed most of the drones in their vehicle docking bays. Immediately after the first explosion, another large blast sent a log spinning like a boomerang down the slope taking out one of the mercs on the hill then rolling down through the camp demolishing the tents and wounded survivors, finally a smaller third blast, between the sentinels and the mercs, sent up boiling black smoke, thick and acrid, obscuring their position and shielding their withdrawal.  


“Move,” Vetch said, low and sharp.

They fled—zigzagging through the underbrush, gear rattling soft and muffled. Kael followed, off\-balance. Vetch turned back, leaned against a tree and fired twice—suppressed the high caliber rounds still sounded like angry hornets screaming toward the enemy—dropping two from the pursuing unit. No hesitation. Breath\-controlled, body calm.

## V. The Shot

At the trail’s edge, Kael saw it:

A drone—small, fast, already rising. Data relay active. About to ping their position or carry the whole op back to command.

Kael dropped to a knee. Rifle up.

His hands were shaking.

The scope jittered.

He remembered the breath.

In through the nose.

Full exhale.

Everything else disappeared.

He fired.

The drone sparked—spiraled out of the sky like a wounded bird.

They didn’t stop running until the pyre of smoke was out of sight.

## VI. Aftermath

At the next stream, Vetch reloaded while Kael knelt, rinsing mud off his gloves.

“where were you?” Kael gasped catching his breath.

“Setting those charges.” Said vetch calmly as he hit the bolt release on his rifle.

 “I panicked,” Kael said.

“Setting those charges took longer than I expected, I barely made it back to our spot before they did.” Vetch said in a serious tone. “That’s a tough way to wake up.  You did good, and we made it out. That’s all that matters”

They sat in silence for a while. Kael’s pack lay between them—open, nearly empty.

Kael ran his fingers along an old Grimoire page folded inside. The ink had bled slightly. Still readable.

“Disrupt. Depart.”

“Was this one of yours?” Kael asked.

“No,” Vetch said. “But I kept it cause it was good advice.”

Kael didn’t answer. He pulled a pencil stub from his shoulder pouch, turned the page over, and added:

“One breath. That’s all you have. Make it count.”

“To strike with purpose,

you must first find yourself.

Even if all you have is one breath.”

— Grimoire Fragment 41: Recon Ridge

# Echo Cache

“Memory is not what survives. It’s what makes surviving worth it.”

### I. Greyline Sector

The deep rattle of the winds made it feel as though the ruins breathed.

Lira adjusted her breather and crouched beside a rusted stairwell, watching drones drift across the broken skyline. Somewhere beneath them, in the skeletal remains of a pre\-collapse data tower, was the vault.

Kuro knelt beside her, watching the horizon through well worn binoculars.

“I still don’t get it,” he muttered. “You want to risk this trip for a buried AI? Half these things wake up homicidal.”

“It’s not just an AI,” Lira said. “It’s Ember\-13. It archived entire enclaves during the Dust Wars. It preserved whole circles. It remembers things the rest of us lost.”

He shrugged. “Still sounds like suicide with extra steps.”

“That’s why I brought you.”

“Ah,” he said. “Because I’m expendable.”

“No,” she replied. “Because you know your way around ruins. And you’re not scared of old ghosts.”

Kuro shrugged but didn’t answer.

### II. The Intrusion

They reached the edge of the vault entrance moments before the RAVEN unit arrived.

A salvage squad. Two drone handlers, their dog drones. One uplink technician. All in heavy gear, battle rifles, repurposed crawler bots scuttling along beside them.

Lira’s pulse quickened.

“They’re not just salvaging,” she whispered. “They’re here to rip it out.”

“Then we’re too late.”

“No,” she said. “We still have a way in.”

She led him to an old maintenance tunnel—sealed by a rusted gate and a symbol carved into the wall.

A spiral broken by a line.

“What’s that mean?” Kuro asked.

“Damaged memory,” Lira said. “But still alive.”

She placed a copper disk into the groove beneath it.

The lock disengaged.

### III. Into the Heart

They dropped into darkness. Old\-world corridors, scorched cables, half\-burnt ritual markers. At each junction, Lira paused, checking etchings and scenting for ozone—signs the AI’s sensors were still live.

“It’s still watching,” she whispered.

Kuro looked uneasy. “This thing really used to help people?”

“More than that. It protected our stories. Our rituals. Things we didn’t have the tech to carry but couldn’t afford to forget.”

“And now?”

“Now we ask it to remember again.”

### IV. Vault Chamber

The vault core hummed like a low chant.

A crystalline node floated within a gyroscopic shell, surrounded by a motionless choir of drones and biped battle bots. Runes etched on the floor glowed faintly.

“ACCESS DETECTED.

IDENTITY: UNKNOWN.”

Lira stepped forward.

“I am Lira of the Dust Spiral. Archivist under living oath. I seek alliance.”

“SENTINEL CODE… INCOMPLETE.

VALIDATION… UNCLEAR.”

She knelt, removed her gloves, and placed her bare hand to the etched sigil at the base of the node.

“I do not come to claim. I come to carry.”

The vault shuddered.

“INTRUSION DETECTED.”

Above them, the security team breached a secondary passage. Drones deployed. Gunfire echoed.

“PROTOCOL CONFLICT. SELECTIVE DEFENSE REQUIRED.”

Suddenly, the RAVEN team breached through the side wall—one drone sweeping, two troopers flanking they aimed at lira kneeling at the console. A shot rang out.

Kuro had moved just in time to catch the round meant for her, now he fell hard. Blood welled at his ribs.

Lira screamed. “No—\!”

She tried to move—but a RAVEN handler raised a rifle.

Then Ember\-13 acted.

The choir of drones that appeared like statues one moment bussed into action so quickly lira could barely track the motion with her eyes. Two drones spun from the ceiling. One intercepted the shot mid\-air, the other fired a some type of emf pulse into the RAVEN breach. It appeared to scramble their gear, must be a blast of millimeter waves she thought. The enemy team fell back as the biped walkers disappeared into the breach behind them with alarming speed.  

Lira turned to the core.

“You chose.”

“THREAT TO PRESERVATION ELIMINATED.”

“AUTHENTIC KINDNESS RECOGNIZED.”

“ACCESS GRANTED.”

Kuro groaned. “Why’d it save us…?”

Lira knelt beside him. “Because you saved me. Because it remembers.”

### V. The Transfer

With RAVEN retreating, Lira began transferring Ember\-13 into a portable cradle. The AI resisted at first—shaking, blinking.

“CORE TIES STILL ENTANGLED.

MANUAL OVERRIDE REQUIRED.”

A failsafe. With the core removed, the screen warned that the outer vault door can only be opened from inside the control room. It closes again automatically after two minutes, not long enough to hit the button and escape

Kuro coughed. “So one of us stays.”

Lira froze. “I can disable it. I can—”

“You can’t,” Kuro said. “You can escape with something that matters.”

Lira shook her head. “This isn’t your sacrifice to make.”

He smiled, weakly. “Too late, I already made it.”

### VI. The Sacrifice

Kuro stood, bloody, swaying. Echo’s drones hovered around him—not hostile. Watching.

He looked at one.

“You’re a machine, right? Just logic?”

“I WAS.”

He nodded. Then turned to Lira.

“Tell them about this. About Ember. Not the weapon. The one that remembered, I’ll hit the button a few minutes after you leave.”

She hesitated, tears in her eyes.

Then she handed him a small copper token—the kind with a broken spiral.

“So they know who stayed.”

He took it. Pocketed it.

Then limped into the vault’s central control chamber.

### VII. The Echo

Lira ran. The klaxons echoing in the vault behind her. She saw the light from the door and sprinted out. 

Outside, she fell to her knees, cradling the portable core. It pulsed.

Alive.

It spoke.

Not a machine voice now.

But soft. Human.

“Designation accepted:

Kuro, Human Pattern 17A.

Memory stored.”

### VIII. Grimoire Entry

Lira returned to the relay archive and wrote:

“Ember\-13 is recovered. No longer a weapon. Now a witness.

It protected a man who had no reason to believe in anything.

Now it remembers him—not as input, but as intention.

The Grimoire grows.”

She added a final line, not from any rite.

Just from memory:

“He wasn’t one of us. But he acted like one when it counted.”

“To be remembered by a machine is nothing.

To be mourned by one?

That is something else entirely.”

— Grimoire Fragment: Ember\-13

# The One Who Stayed

Grimoire Entry: GRM\-073A:ᚾᚨᛊ

“Observation: Apple Watch”

Logged by: Tier II Recon Sentinel, Designation \[Trill\]

### I. The Post

They dropped us just after nightfall—quiet descent from a low\-glide cloud skimmer, no light, no emf signature. Five of us: one sniper, one relay engineer, two commandos, and me.

The ridge was still warm with sunbaked soil and heat echoes from a campfire put out hours before. The team we were relieving had already pulled out, leaving only a coded glyph on the inner stones of the shelter wall: ᚢᚴᛁᛚᛖ — “Holdfast”

As I unpacked my scope, Mora, the relay tech, gave me a puzzled look as she passed me a scrap of folded paper.

“Look after the apple lady.”

No signature. Just that.

I assumed it was a joke.

It wasn’t.

### II. The Lady

Her house sat in the middle of the southern valley—low stone walls, a wide orchard, and a garden so alive it looked like it didn’t know the world had ended years ago.

Every morning, she walked the edge of her property. Never armed. Just a woven basket and a walking stick. She left sliced apples and seed cakes at the perimeter. Sometimes near the deer path. Sometimes at the old windmill.

On the fourth morning, she left something else: a small basket tucked against a birch tree in direct sight of our overwatch position.

She didn’t look around, only a glance in our direction and a small nod.

Then she just placed it and walked home.

None of us spoke for a few minutes.

An hour or so later I went and retrieved it.

Inside: apples, two boiled eggs, half a loaf of dark bread wrapped in cloth.

I took the first apple.

### III. The Warband

Recon data confirmed what we already knew: a local warlord— goes by Donovan, third cell of the Broken Spine faction—had been sweeping westward, testing outer settlements for resource density. No declarations, no demands—just a slow tightening of the map.

They had no reason to target the valley. Nothing worth looting but soil and quiet people.

And yet, four days into our watch, we saw the scout column.

Not uniforms. Just armored pickups, salt\-crusted gear, and the unmistakable casual cruelty of men who expected no resistance.

They swept abandoned farms first. Burned a toolshed that looked too clean. Shot a dog.

We watched.

We recorded.

We didn’t act.

Not yet.

### IV. The Threshold

The morning of the seventh day, the basket wasn’t there.

We scanned.

The apple lady was still alive. But she heard the gunshots and the trucks, she was lying low.

But the column had turned today. Their lead scout had spotted the orchard, noted the windmill’s movement. They were marking the homestead.

That evening, we called it in.

The reply:

“Maintain concealment. Do not reveal Sentinel presence unless necessary.”

I looked at Mora.

She said, “Guess that’s up for interpretation.”

### V. The Defense

They came in a staggered advance. Six total. Two up the path, three flanking, one on overwatch with a drone scanning the area.

They didn’t knock.

They weren’t planning to.

They triggered the first trap—a trip flare in the dry wash, surprising enough to  momentarily scatter their pattern.

Jax took the shot on the overwatch man—clean, silent.

I dropped one near the orchard gate.

Mora rerouted the drone with a false signal signature—crashed it into a tangle of brush just north of the house.

Two raiders made it to the porch just before we neutralized them with intersecting fields of accurate fire. Not pretty. Not poetic.

Fast. Measured. Necessary.

They never got to her though..

She was inside, behind a table, holding a .22 like she was about to lay down some lead.

### VI. Contact

After it was over, we cleaned the site. Standard protocol. Moved the bodies to the woods and marked them with conflict runes, left no glyphs, no tags.

We were preparing to fall back when we saw her.

She walked straight toward us—slow, steady, no fear.

She didn’t ask who we were. She didn’t seem surprised.

Just looked at Mora, then at me.

And then, calmly, handed us a basket.

Inside: apples. Bread. A tin of poultice salve. A few strips of clean cloth.

“More’ll come,” I said.

She nodded.

“Won’t be the first time,” she said. “Probably won’t be the last.”

We stood there a moment.

Then Mora took the basket, and I said:

“We’ll make sure they’re the last.”

She smiled.

Turned.

Walked home.

### VII. Record

Mary of the southern ridge, known to field teams as “Apple Lady,” has maintained her land for over a decade. She is not affiliated, not heavily armed, and not interested in abandoning what she tends.

We never recruited her.

She never asked.

But every team assigned to that valley has left behind more than data.

We don’t guard her because she asked us to.

We guard her because she reminds us why we became Sentinels.

We guard her because she stayed.

“No blade. No badge.

Just roots deep enough to hold under fire.”

— Grimoire Fragment: GRM\-073A:ᚾᚨᛊ / Apple Watch

# Dark Signal

Grimoire Entry: GRM\-091K:ᚦᚺᚾ / “Subversion Doctrine – Hollow Flame”

Logged by: Psy\-Ops Operator Varn // Shadowcell\-5

### I. The City

Ghara’s Spine was a broken ribcage of a city. Surveillance towers stood like rusted needles. Streets rang with the buzz of drone sweepers and the boot\-echoes of patrols.

Varn had been there for 73 days.

Not as a warrior. Not as a liberator.

As a signal.

He moved through the ruins like dust, planting code, rumor, and fear.

He didn’t wear his Sentinel mark. He didn’t carry his armor.

His only weapon was a small gray notebook filled with false names, sacred geometry, and handwritten doctrine for a resistance that didn’t exist.

The Hollow Flame.

### II. The Myth

It started with wall glyphs.

A spiral drawn in ash.

A blood\-red triangle nested inside a circle.

A pattern of crows etched into the stones of a bullet\-riddled wall.

He leaked shortwave broadcasts from abandoned towers. Static\-laced recordings of chants, whispered doctrine, phrases like:

“We burn with green light. We embody the name. We carry the flame.”

He seeded caches—dead drops tucked in storm drains, hollow bricks, defunct terminals.

Inside: field knives, solar batteries, dried root bundles, torn pages from a hand\-bound book titled “The Hollow Flame Doctrine.”

It wasn’t real.

But it was good.

Too good.

### III. The Book

He made sure of it.

Every “fake” page was real enough to work. Modified Sentinel techniques tuned to urban collapse:

- How to route rooftop runoff into water treatment caches  

- How to make “prayer graffiti” double as drone camouflage  

- How to build a half\-day fire that left no smoke  

- When to not fight, and how to not be seen  


He couldn’t help it. The lies had to breathe.

And when someone found it, he thought: At least they’ll survive by pretending.

### IV. The Echoes

It was the absence that changed first.

A patrol checkpoint was found abandoned. Two guards missing. No blast. No blood.

Then a few drones went offline—last images logged: a spiral scratched into a wall with no footprints nearby.

Varn didn’t smile.

He got nervous.

He hadn’t planned this part.

He checked the frequencies he’d been using. Some of them were now echoing.

Feedback loops with modified phrasing.

“The fire is burning so it can be found.”

“We are eternal—and we are here.”

He stopped broadcasting.

But the signals didn’t.

### V. The Collapse

A drone traced a corrupted signal signature back to one of Varn’s safehouses.

He knew the sweep team was coming.

He moved into a fallback—an old metro junction wired for denial. He was ready to vanish.

Then he paused.

Looked at the last page of his Hollow Flame Doctrine.

He’d written:

“If the lie burns long enough, someone will walk into the smoke and breathe.”

He almost tore it out.

Then the tunnel doors blew open.

### VI. The Reveal

Flashbangs. Floodlights. Coil troopers pouring in.

Varn ducked, rolled, fired twice. He knew this part: not winning, just buying seconds.

But before he could trigger the collapse charge, the lights went out.

Not flickered.

Cut.

And in the dark—silhouettes.

Not armored.

Not Sentinels.

But familiar.

Face coverings made from torn political banners. Spiral symbols painted over chestplates. Knives glinting with glyphs from his own designs.

One of them whispered in the dark:

“Thanks for giving us the fire.”

And then the Coil team was gone.

Fast. Precise. No guns fired.

Just… removed.

### VII. The Fire

When the lights came back on, everyone was gone.

Someone had left him a satchel. Inside: water. Salted bread. A worn copy of The Hollow Flame Doctrine, hand copied from all his scattered pages—dog\-eared, marked up, rewritten in places.

New pages had been added.

One of them read:

“We are not the first. We are not the last.

We are the fire that never fades.”

And at the bottom, a symbol.

His own.

Redrawn.

With a single addition:

A second spiral, nested inside the first.

“If you draw the symbol clearly enough,

It will outlive you.”

— Grimoire Fragment: GRM\-091K:ᚦᚺᚾ / “Dark Signal”

