# Saga Fragments

## What A Saga Fragment Is

A Saga Fragment is partial narrative material — a scene, a character note, a single decision and its aftermath, a faction encounter — that exists outside any completed saga.

Fragments are how sagas actually accumulate. A finished saga is rare. A long-running practice produces many fragments, each of which may eventually fold into something larger or stand on its own.

## Why Fragments Matter

The Saga Smith and the Ember Node should treat fragments with the same care as completed sagas. A fragment captured well is more useful than a finished saga forced to closure.

Fragments carry:

- The shape of a Signal Thread before the thread is named.
- The texture of a faction or region before the world is fully built.
- The voice of a character before the character has an arc.
- The first surfacing of a continuity pressure that will mature later.

## How Ember Node Handles Fragments

The Ember Node stores fragments lightly:

- A short title (5–8 words).
- The session or date.
- The seeds in play at the time.
- The fragment text itself.
- Any Signal Thread the fragment connects to (optional).

Fragments are **not** assembled into sagas automatically. They are surfaced when the practitioner returns to a related world, character, or thread, and the Ember Node says:

> "There is a fragment from an earlier session that may be relevant here. Would you like to see it?"

The practitioner decides whether to incorporate it.

## What Counts As A Fragment

- A single scene that stayed with the practitioner.
- A line of dialogue that has weight.
- A faction encounter that surfaced an unexpected tension.
- A reflection note that was too long for the journal but too short for a saga.
- A character sketch with no story attached yet.

What does **not** count as a fragment:

- Notes-to-self about session logistics.
- Mechanical state (dice results, coin flips) without narrative weight.
- Drafts the practitioner has already discarded.

## Promoting A Fragment

When several fragments accumulate around the same character, faction, or world, the practitioner may choose to:

- **Compose** them into a single saga.
- **Seed** them into a new session that revisits the same material.
- **Archive** them as standalone material.
- **Release** them — acknowledge they have done their work and need not be carried further.

The Ember Node may notice a cluster of related fragments and offer the choice. It does not promote fragments on its own.

## Fragments And The Published Sagas

The two published Sentinel Sagas (Volume I — Ash and Bloom; Brothers Saga) are not fragments — they are completed narrative works distributed in the legacy `green-fire-sagas-cache.zip`. Practitioners may produce fragments that engage with the same world or characters; those fragments belong to the practitioner's own saga record, not to the canonical published works.

## Closing Note

Most of what gets made in Saga Smith practice is fragment. That is correct. The Archive is not asking for finished masterpieces. It is asking for honest engagement, carried forward in whatever shape it actually takes.

ᛒ
