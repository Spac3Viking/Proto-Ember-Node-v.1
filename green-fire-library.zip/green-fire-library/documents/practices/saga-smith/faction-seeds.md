# Faction Seeds

*Worldviews under stress*

Faction Seeds define: what this group believes keeps them alive, what they are blind to, how they justify power. Important: No faction is "evil." Cultures are Shaped — and Distorted — by Survival.

## Faction Framework

### Schismogenesis — Becoming Through Contrast

In Green Fire, factions are not defined by good or evil. They are defined by pressure.

Every faction begins as an answer to a real problem, surviving by emphasizing a particular value — order, strength, memory, faith, efficiency, freedom, balance. Over time, under stress, that value becomes exaggerated:

- Order hardens into control.
- Efficiency becomes extraction.
- Tradition calcifies into dogma.
- Freedom dissolves into fragmentation.

Factions do not become extreme because they are evil. They become extreme because they over-optimize for survival. Every faction is a mirror.

### The Spiral Method — Cultural Self-Examination

The Spiral is not a moral scale. It is a method of perception. Each encounter moves through the same living rhythm:

- **Observe** — Read the terrain. Notice what they protect and what they ignore.
- **Act** — Engage them, through trade, conflict, alliance, or ritual. Every action is a test.
- **Reflect** — What did this faction reveal about itself? What did it reveal about you?
- **Transmit** — Carry the pattern forward, into story, symbol, or seed.

What once looked like an enemy may later look like a warning. What once looked like safety may later reveal its cost.

### S.P.I.R.A.L. — Reading A Faction At A Glance

Each faction can be understood by how it answers six questions:

- **S — Structure:** How does the group hold itself together?
- **P — Polarity:** What principle drives them?
- **I — Interaction:** How do they treat outsiders?
- **R — Reality:** What do they believe is real?
- **A — Attunement:** How do they relate to land and life?
- **L — Ledger:** How does value move through the group?

This is a recon lens — a way to see without illusion. Two factions may look similar on the surface and be fundamentally different underneath.

### Why This Matters For Sagas

When factions collide in a saga, the real conflict is not territory or resources. It is worldview.

Each faction represents a possible answer to collapse. Each answer carries a cost. Each faction clearly encodes:

- The problem it originally solved.
- The trait it over-optimized.
- The fracture that emerges under pressure.

Factions are not obstacles to overcome. They are tests of alignment. Read them carefully. They are showing you something.

## Seeds

### 1. The Contracted Corps

They arose to prevent chaos through professionalism. Neutrality became their virtue. Over time, neutrality replaced conscience, and contracts replaced judgment.

### 2. The Stability Directorate

Formed to protect civilians from collapse panic. Order kept people alive. Eventually, obedience mattered more than truth.

### 3. The Skybound

Nomads who rejected territory to avoid domination. Freedom became their survival edge. In time, rootlessness eroded responsibility.

### 4. The Observers

They preserved data when others burned it. Knowledge was their shield. Eventually, understanding replaced empathy.

### 5. The Iron Oath

They believed strength prevented cruelty. Discipline forged unity. Honor hardened into ritualized violence.

### 6. The Memory Keepers

They carried stories so nothing vital would be lost. Preservation became identity. Hoarding memory stalled renewal.

### 7. The Rebuilders

They scavenged and repaired when systems failed. Ingenuity saved lives. Dependency on dead tech crept in unnoticed.

### 8. The Soilbound

They rejected machines to protect continuity. Simplicity brought resilience. Dogma replaced adaptation.

### 9. The Signal Choir

They followed fragmented AI guidance for coordination. Clarity reduced fear. Obedience replaced discernment.

### 10. The Open Road

Trade caravans kept regions alive through exchange. Mobility created connection. Loyalty became negotiable.

### 11. The Ashborn

They survived poisoned land others fled. Endurance defined worth. Suffering became sacred.

### 12. The Uninherited

Born after collapse, they questioned everything. Innovation drove change. Recklessness endangered continuity.

### 13. The Ward Circle

They guarded a critical resource from misuse. Stewardship justified force. Protection became ownership.

### 14. The Quiet Mesh

Decentralized cells formed to resist domination. Anonymity preserved safety. Fragmentation weakened resolve.

### 15. The Continuity Council

Former officials preserved law and protocol. Structure survived chaos. Authority outlived relevance.

### 16. The First Builders

They founded early enclaves and prospered. Success validated their methods. Origin stories hardened into law.

### 17. The Untethered

They abandoned all hierarchy to remain free. Adaptability kept them alive. Lack of trust dissolved cohesion.

### 18. The System Tenders

They maintained automation to prevent disaster. Maintenance became moral duty. Systems were preserved past their usefulness.

### 19. The Water Hand

They regulated wells and purification. Order prevented drought wars. Control justified cruelty.

### 20. The Wayfarers

They traveled carrying stories and rituals. Meaning replaced safety. Vulnerability became their constant tax.

### 21. The Dark Zone Collectives

They rejected electronics after catastrophic failure. Grounded living restored autonomy. Blindness to wider threats followed.

### 22. The Iron Market

They armed others to balance power. Trade stabilized conflict. Profit quietly chose sides.

### 23. The Line Holders

They kept rails, grids, and dams alive. Continuity preserved regions. Adaptation was sacrificed to maintenance.

### 24. The Smog Children

They evolved in polluted zones. Adaptation ensured survival. Normalization of damage erased urgency to heal.

### 25. The Broken Banner

They claimed legitimacy through old flags. Identity preserved morale. Fragmentation replaced governance.

### 26. The Still Path

They withdrew to preserve discipline and clarity. Restraint prevented excess. Isolation reduced influence.

### 27. The Apex Hunters

They lived by skill and dominance. Efficiency fed them. Compassion was bred out.

### 28. The Lifebearers

They healed without allegiance. Mercy saved lives. Exploitation forced impossible choices.

### 29. The Signal Saboteurs

They disrupted surveillance and control. Chaos restored freedom. Destruction outpaced rebuilding.

### 30. The Ember Network

Not an organization, but a resonance. Shared values guided action. Lack of form confused outsiders.

### 31. The Entitled Lineage

They claimed inheritance of old systems. Continuity justified rule. Competence became secondary.

### 32. The Covenant Cities

They traded autonomy for safety. Compliance reduced violence. Freedom quietly vanished.

### 33. The Unbound

They refused faction identity altogether. Flexibility kept them alive. Distrust followed everywhere.

---

*33 seeds. Derived from `client/src/data/saga-seeds.ts`. Re-run `tsx scripts/build-saga-cache-content.ts` after edits.*
