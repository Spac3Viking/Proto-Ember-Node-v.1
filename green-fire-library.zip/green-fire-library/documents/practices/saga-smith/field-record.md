# Field Record: The Lock at Crow's Bend

*An example of play — a complete field session run with the Saga Smith Field Rule.*

---

## What a Field Record Is

A field record is the written trace of a real session. It shows what the Field Rule looks like in motion — not a script, but an account of what players chose, what the field cost them, and what remained unresolved when the session closed.

Read it before running your own session to understand how the system breathes. The decisions were real. The outcomes were not planned.

---

## The Session

**Three Sentinels entered an old lockhouse with different priorities. When the river began to break it apart, they had to decide what mattered first.**

A river pirate (Jack) found a blue emergency battery in the drowned lockhouse at Crow's Bend. An emergency robot (ANNE) said it belonged to protocol. A survivalist (Skeeter) said they should leave before the flood took them all.

Then the lockhouse began to drown.

The river pirate (Jack) spent the battery's charge to free a trapped boat. The emergency robot (ANNE) chose rescue over orders and turned an abandoned crane into a lifeline. The survivalist (Skeeter) held a failing floodgate long enough for everyone else to act.

Together, they saved two strangers, recovered Sparky Jacob — the little salvage robot, damaged but not lost — and escaped in an old maintenance truck as Crow's Bend broke apart behind them.

At a fork in the road, the team chose the longer wooded route toward home instead of Beacon Hill, where a beacon suggested more people might be waiting. They did not solve every problem. They brought the people already in their care safely through the storm.

---

## Outcome Record

| Signal | What the Field Left |
|--------|-------------------|
| **Protected** | Two survivors, Sparky Jacob, the team |
| **Spent** | The battery charge, a winch cable, certainty |
| **Changed** | Rivals became a working crew |
| **Unresolved** | Three lights at Beacon Hill |

---

## Reflection

*The players chose the way forward. The field made every choice matter.*

The session did not pre-plan what came next. The Saga Smith let each Sentinel's choice create the next pressure. The unresolved signal — three lights at Beacon Hill — exists because the players chose the wooded route. That signal can become the opening pressure of a future session, or close with the end of the night.

---

## Notes for the Saga Smith

This record illustrates First Contact play:

- Pressure was local — a single location, an immediate threat, no world history required.
- Division was real — protocol vs. compassion (ANNE), resource vs. escape (Jack vs. Skeeter), rescue vs. safety.
- No Sentinel needed a score sheet. Role names (river pirate, emergency robot, survivalist) carried all the mechanical weight.
- The session ended when the immediate danger changed shape — not when everything was resolved.

A session that leaves one unresolved signal has done its job. That signal carries the field forward.

---

*This record reflects a real session run with the Saga Smith Field Rule. For the Field Rule itself, see `field-rule.md`. For a ready-to-run exercise, see `field-exercises.md`.*
