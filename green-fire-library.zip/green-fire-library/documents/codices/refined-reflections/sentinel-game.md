---
title: "ᛋᚲ᛬ The Sentinel Game"
description: "A Tactical Codex for Field Play, Reflection, and Narrative Transmission."
order: 10
---

This is structured not just as a game manual, but as a training interface, reflection engine, and symbolic ritual for Sentinels in any timeline.

### Prologue: ᚠᛁᚱ in the Ash
“The map is not the ground. The rules are not the flame. But if you play with discipline, the game will teach you how to walk through ruin and remember who you are.”

This is not just a game. It is a tool of remembrance. A quiet ritual. An artifact for the world to come.

In every era of collapse and reformation, there are those who learn to see patterns in the chaos—to read the wind, the symbols, the silence between signals. These are the Sentinels. Warrior-philosophers, builders of the unseen world. Their task is not to conquer, but to remember. Not to dominate, but to guide. And their training must be both serious and subtle—encoded in the very fabric of how they live, play, and record.

This codex is a map to such a training. A game played around fires and in forests, in ruins and in dreams. It requires no screen, no network, no power grid—only your attention, your choices, and your willingness to reflect. It is part chess, part Dungeons & Dragons, part psych evaluation. But above all, it is a sacred drill: a way to prepare not just your hands and eyes, but your judgment, your rhythm, your signal.

### Why Sentinels Play Games
Long before maps were printed or radios buzzed, strategy was taught through stories, play, and tests. From tafl boards played on Viking voyages, to Go stones echoing the geometry of war, to riddles passed around tribal fires—games were how cultures remembered how to think. Not just what to do, but why.

The Sentinel Game follows this lineage. It is not a contest of domination, but a mirror of movement—an ethical and symbolic sparring ground for those who must one day act in the real world

This game will teach you how to:

- Assess terrain without assumption

- Understand others without illusion

- Prepare wisely, even with little time

- Execute under pressure

- Reflect with honesty

- Transmit what matters, without distortion, dilution, or delusion

This is how strategy becomes sacred.

### The Spiral Framework: Observe. Act. Reflect. Transmit.
The game operates as a living spiral, not a linear script.

Each mission loop echoes the full rhythm of Sentinel action:

1. Observe – Read the terrain. Listen to the field. Identify forces at play.

2. Act – Choose your role. Prepare with intent. Navigate the operation.

3. Reflect – Debrief. Analyze. Archive the lesson.

4. Transmit – Pass the pattern on, encoded in journal, signal, or glyph.

With each loop, the Sentinel becomes more attuned—not just to the mechanics of play, but to the principles beneath the surface. This is why repeated games do not become repetitive: they spiral deeper. What began as a field game becomes an ethic. A way of seeing. A way of being.

### What You’ll Need
The game is modular, minimalist, and field-adaptable. To begin, all you need is:

- 1–6 coins or tokens (to simulate dice and chance outcomes. A single coin may be flipped as many times as needed or several coins can be cast at once.

- A single die (optional): d4, d6, or d20 recommended for advanced play

- A notebook or grimoire page: for maps, outcomes, and reflection

- Printed, copied, or created terrain/faction/mission/event tables

- A quiet mind and patience

Optional expansions:

- Symbol cards, runic markers, terrain miniatures, AI co-play

- Group roleplay, multi-archetype sessions, team missions

But none of this is required. The Sentinel Game can be played:

- In a journal entry

- Around a fire

- In a quiet moment before sleep

- Between watch rotations at a frontier outpost

You are the character. The land is the map. Fate is the coin.

### Play Anywhere. Train Everywhere. Archive What Matters.
This codex is designed for transmission. It can be copied and shared, gifted in a data cache, etched into code or stored as an artifact. Its language is symbolic, clear, and decentralized. It does not depend on the world staying intact.

Because it wasn’t written for this moment alone.

It was written for the Sentinels who will need it when the world shifts. It was written for you.

᛬ When you play, you remember.

᛬ When you reflect, you refine.

᛬ When you pass it on, the signal survives.

CHAPTER I — Terrain: Mapping the Field

Know the ground. It decides everything.

### The Ground Beneath the Game
Before a Sentinel chooses a path, before a mission is known, before alliances are mapped—the land is already speaking. Every rise, hollow, current, and ruin carries signals. Strategy is not only born in the mind. It is gleaned from earth, shadow, wind, and time.

To understand your mission, you must first understand the field upon which it unfolds.

This chapter teaches how to generate, interpret, and map terrain as the foundational layer of gameplay. Whether by coin, dice, card, or intuitive draw, terrain determines everything that follows.

### Terrain Generation Methods
There are three ways to generate terrain in the Sentinel Game:

1. Draw a Terrain Card or Table Entry

Use the provided terrain tables or create your own card deck for field use.

2. Roll Dice or Flip Coins

Assign numbers or outcomes to elemental terrain types. Example:

- d6: 1 = Earth, 2 = Water, 3 = Air, 4 = Fire, 5–6 = Æther

- Or flip 5 coins: Heads-majority = Æther or rarer terrain.

3. Choose or Observe

Use the real-world environment around you to guide your choice. What terrain are you standing in now? What terrain best suits the story or mission?

### The Fivefold Field
All terrain in the Sentinel Game falls into one of five archetypal categories. These elemental fields shape not only the mission logistics, but also the psychological and mythic mood of play.

#### 🜃 Earth — Forests, Ridgelines, Rural Grounds
Natural Features: Woods, soil, roots, burrows, stone

Strategic Features: Cover, concealment, shelter, fuel

Tactical Features: Limited visibility, high ambush potential, slow movement

Collapse Lore: Overgrown farmlands, hidden bunkers, village ruins

Mood: Grounded, slow, enduring—Earth missions test patience and presence.

#### 🜄 Water — Rivers, Wetlands, Coastlines
Natural Features: Flow, tide, stagnation, purity, decay

Strategic Features: Fishing, water access, travel choke points

Tactical Features: Mud, flood risk, high disease risk, altered mobility

Collapse Lore: Drowned towns, bridge battles, biochemical runoff

Mood: Emotional, slippery, hidden—Water missions test adaptability and intuition.

#### 🜁 Air — Highlands, Plains, Open Skies
Natural Features: Wind, openness, cold, echo

Strategic Features: Long sightlines, signal relays, high-ground advantage

Tactical Features: Exposure, low concealment, rapid movement

Collapse Lore: Abandoned outposts, crash sites, sky shrines

Mood: Cerebral, fast, wide—Air missions test clarity and precision.

#### 🜂 Fire — Wastelands, Burn Zones, Deserts
Natural Features: Ash, heat, scarcity, glare

Strategic Features: Hard-to-cross zones, volatile materials, relic ruins

Tactical Features: Harsh exposure, mirage risk, exhaustion

Collapse Lore: Firestorms, old weapon tests, salt flats

Mood: Brutal, direct, purifying—Fire missions test resolve and endurance.

#### Æ Æther — Cities, Crossroads, Abandoned Sites
Natural Features: Infrastructure, geometry, density, decay

Strategic Features: Tech salvage, hidden archives, high population history

Tactical Features: Multilevel combat, static/EM interference, layered cover

Collapse Lore: Riots, echoes of surveillance, scavenger haunts

Mood: Complex, symbolic, entangled—Æther missions test navigation of systems.

### How to Read the Field
Each terrain type comes with its own opportunities and dangers. As you prepare your Sentinel’s loadout and mindset, ask:

- What does this terrain provide—and what does it deny?

- What would a local know that an outsider would miss?

- What happened here during collapse? What still echoes?

- Where are the natural ambush points, signals, or stories?

Use these prompts to draw or sketch a basic map if desired. Include:

- Choke points

- Landmarks

- Hidden resources

- Past events

A full terrain journal can become a living archive for multi-session play.

### Reflection Prompt
“The land teaches strategy if you know how to read it.”

- What terrain do you feel most at home in?

- What terrain challenges you most?

- If you had to disappear, which terrain would you choose—and why?

CHAPTER II — Factions: The Web of Forces

You never operate in a vacuum.

### ❖ The Terrain Is Never Empty
Sentinels don’t just navigate forests or ruins—they move through contested space. Every mission unfolds inside a tangle of motives, systems, and loyalties. Factions define the shape of the world. Some are loose collectives. Others are armed fortresses with history, doctrine, and blood on their hands.

To be a Sentinel is to see with clarity—not just the threat, but the story behind the threat. Every faction, however brutal or beautiful, is a reflection of deeper conditions.

The Green Fire exists in contrast. This chapter sharpens that contrast.

### ⟴ Schismogenesis: Defining the Flame Through Contrast
The Green Fire is not a doctrine—it is a continual act of refinement. Every faction it encounters becomes a mirror, a pressure, a wound or a gift. This process of schismogenesis—becoming through contrast—is not about opposition alone, but calibration. The flame sharpens itself not by standing apart from others, but by standing against the pressures they embody. A faction rooted in dominance forces the Sentinel to recall restraint. One that exploits teaches the sacredness of reciprocity. The Green Fire is not defined by purity, but by how it responds. This game encodes that tension: to see factions not only as threats or allies, but as tests of alignment. In a fractured world, every encounter is a form of philosophy.

### ❖ S.P.I.R.A.L. — A Modular Faction Coding System
Each faction is profiled using the six S.P.I.R.A.L. axes. These categories allow you to quickly build or analyze any group—whether found in play or generated from scratch.

Each axis has four core values. Simply assign one per axis. This creates a unique but interpretable faction code like:

S: Rigid | P: Power | I: Militarized | R: Technocratic | A: Extractive | L: Debt

(This could describe a fortress-tech regime or cartel militia.)

### ⟴ The S.P.I.R.A.L. Axes
S — Structure (Cohesion)

How the faction holds together.

- Fractured — Loose ties, internal tension, weak center

- Rigid — Central authority, enforced loyalty

- Networked — Distributed trust, tight circles

- Symbolic — Bound by story, ritual, or shared marks

P — Polarity (Orientation)

What principle drives them.

- Power — Control, conquest, dominance

- Belief — Ideology, faith, prophecy

- Memory — Ancestry, tradition, continuity

- Balance — Sustainability, flow, restraint

I — Interaction (Relations)

How they relate to outsiders.

- Parasitic — Extraction, manipulation, dependence

- Militarized — Defense or aggression as primary logic

- Diplomatic — Trade, leverage, negotiation

- Stewarding — Protective, mutual, uplifts others

R — Reality (What is Real)

What defines their perception of truth.

- Technocratic — Data, systems, experts

- Mystical — Symbols, visions, metaphysics

- Pragmatic — Actionable truth, what works

- Layered — Holds both fact and symbol as valid

A — Attunement (Ecology)

Their relationship to land and life.

- Extractive — Use without care, short-term gain

- Sustaining — Replace what is taken

- Cultivating — Improve, regenerate, restore

- Nomadic — Move with the land, light imprint

L — Ledger (Exchange System)

How value moves through the group.

- Debt — Control through obligation

- Trade — Markets, barter, service-value

- Gift — Reciprocity, sacred offering

- Signal — Story, oath, glyph, initiation

You don’t need to memorize all the details. Use the initials (e.g., S: Fractured) or create field notes shorthand. Think like a recon analyst. The system isn’t to label. It’s to see.

### ⟴ Faction Profiles — New Set of Outstanding Examples
Here is a refined and deeply realistic set of ten exemplar factions. Each evokes post-collapse plausibility, moral ambiguity, and sharp contrast with Green Fire philosophy. You can treat these as archetypes, threats, allies, or region seeds.

1. The Tithe Lords

Feudal war-bureaucrats who tax crops, children, and memory itself. They issue paper chits backed by stolen solar credits. Enforce laws via bonded mercenaries. Their archives are vast—and full of redacted truths.

2. The Chain Root Syndicate

A cartel of salvage engineers who control the aquifer grids beneath the ruins of old tower cities. They barter water for labor and loyalty. Their logo is a rusted chain looped through a taproot.

3. The Bloomwalkers

An itinerant commune of mycologists and healers living in caravans and ruins. Their medicine is real—but so is their secrecy. Some say they seed spores for healing. Others say for chaos.

4. The Bannered Sons

Wasteland mercenaries, descended from old-world special forces and corporate security. Professional, brutal, and bound by ritual oaths. For the right price, they’ll guard your camp—or raze your rival.

5. The Cradle Vault

A sealed arcology hidden beneath a fallen mountain. Believed to house thousands in cryo-sleep, governed by an intact AI overseer. Some believe it’s salvation. Others think it’s a slumbering catastrophe.

6. The Signal Weavers

Once coders, now nomads who roam the data-dead zones, stitching together surviving networks and dark archives. Speak in parables, runes, and code. Their value is knowledge. Their loyalty is conditional.

7. The Emberkin (Green Fire-aligned fragment)

A discreet band of Sentinels who left the enclave to carry the flame alone. Live light, teach quiet, leave glyphs near freshwater or crossroads. If you find one, it’s because they let you.

8. The Staghorn Hold

A survivalist fortress built into the bones of a hydroelectric dam. Its people worship cycles: drought, feast, blood. Their leader is a matron-militant who speaks only during storms. They trade in iron, electricity, and grain.

9. The Broken Choir

Rogue remnants of a once-utopian educational AI project. Their enclave recites long chants, stores pre-collapse knowledge in mnemonic hymns, and believes music can reprogram the soul. Their hymns soothe—and ensnare.

10. The Pale Accord

A fragile peace pact between multiple scavenger clans who meet under a white banner. Known for brutal justice rituals and enforced neutrality zones. If you violate their code, you may vanish without trace.

### ❖ Tools for Play
You can:

- Randomly assign factions by rolling one trait per axis (d4, coins, table draw)

- Create factions from existing settlements in your story world

- Build based on contrast with the players’ current archetypes or terrain

- Let factions evolve session-by-session

### ❖ Reflection Questions
- What part of this faction reflects your own enclave’s fear or temptation?

- If you had been born inside this group, what would you believe?

- Is this group lost—or are they just surviving a different way?

- Could something from this faction be integrated into your own toolkit?

Sentinel Note: Factions aren’t just challenges. They are calibration tools. They show you what the world becomes without the fire. They test whether you carry it clean.

# CHAPTER III — Archetypes: Choosing the Path
The presence you bring to the mission matters.

In the field, the tools you carry matter. But who you are determines how those tools are used. The archetype is not a class or profession—it is your posture toward reality, your instinct under pressure, your rhythm in the spiral.

A Sentinel does not belong to a rigid order. These archetypes are points of orientation. Every Sentinel is a blend, shaped by terrain, mission, memory, and necessity. But at the start, you choose the presence you bring into the field.

## The Six Core Archetypes
Players begin by choosing or rolling one of the six primary archetypes. These can be refined or hybridized over time, but this initial frame will guide decisions, gear access, and your intuitive style of play.

Each is aligned with a primary rune, which serves both symbolic and functional resonance—marking their style in the field and potential compression in game records or glyphs.

### ᚦ Warrior
Role: Direct action, frontline, force projection

Essence: Strength, resolve, sacrifice

Synergies: Scout, Healer

Favored Terrain: 🜃 Earth, 🜂 Fire

Strengths: Combat, intimidation, shield others

Weaknesses: Subtlety, diplomacy

Bonus: +1 on first strikes or physical endurance checks

### ᚲ Builder
Role: Construction, repair, tactical engineering, machinery

Essence: Function, structure, innovation

Synergies: Scholar, Mystic

Favored Terrain: 🜃 Earth, Æ Æther

Strengths: Tools, shelters, traps, repairs

Weaknesses: Speed, persuasion

Bonus: +1 to create, repair, or reinforce structures and gear

### ᚨ Scholar
Role: Lore, memory, communication

Essence: Language, pattern, remembrance

Synergies: Mystic, Healer

Favored Terrain: Æ Æther, 🜁 Air

Strengths: Glyphs, signals, riddles, archives

Weaknesses: Physical endurance, fast reactions

Bonus: +1 to interpret symbols, code, or maps

### ᚱ Scout
Role: Recon, mobility, perception

Essence: Awareness, adaptation, navigation

Synergies: Warrior, Builder

Favored Terrain: 🜁 Air, 🜄 Water

Strengths: Stealth, tracking, terrain tactics

Weaknesses: Heavy combat, ritual acts

Bonus: +1 to stealth or terrain-based navigation

### ᛒ Healer
Role: Morale, restoration, cohesion

Essence: Integration, regeneration, care

Synergies: Warrior, Scholar

Favored Terrain: 🜄 Water, 🜃 Earth

Strengths: Healing, diplomacy, group morale

Weaknesses: Solo operations, machinery

Bonus: +1 to morale checks, healing scenes, or negotiation

### ᛞ Mystic
Role: Timing, omen-reading, resonance

Essence: Symbol, silence, threshold

Synergies: Scholar, Scout

Favored Terrain: 🜂 Fire, Æ Æther

Strengths: Symbolic acts, initiation, alignment

Weaknesses: Direct force, logical planning

Bonus: +1 to intuition, symbolic interpretation, or synchronistic action

## Archetype Integration
Each archetype shines alone—but the real art is in combining them.

- Teams of two can balance strengths and blind spots.

- Hybrid archetypes (e.g., Builder–Scout, Healer–Mystic) may emerge through play.

- Archetype resonance may shift based on mission type, faction interaction, or personal evolution.

Your archetype affects:

- Loadout Access: what gear you may choose or carry efficiently

- Focus Effectiveness: which prep actions grant best modifiers

- Operation Outcome: how you interpret, move through, and resolve events

- Reflection Lens: how you make meaning from what occurs

## Optional Table: Roll to Assign Archetype
(d6)

**Roll**
**Archetype**
1

Warrior

2

Builder

3

Scholar

4

Scout

5

Healer

6

Mystic

## Sentinel Note:
Don’t just play the archetype—watch how it plays you. In reflection, you may find that who you were before the mission is not who returns.

# CHAPTER IV — Missions: The Why Behind the Move
Never act without a reason.

A Sentinel does not move without cause. Missions are not mere tasks—they are ethical engagements, symbolic transmissions, and wagers for survival. In a fractured world, each mission carries weight: to restore, to recover, to protect, to disrupt, to plant the next seed.

This chapter defines mission generation, structure, and reflective outcomes. It is the spine of the game—but also a mirror. Each mission asks:

What will you risk?

What will you change?

What will you carry home?

## I. Core Mission Types
Each mission provides a narrative catalyst, a tactical scenario, and a moral layer. Choose deliberately, or roll randomly. Missions are modular and evolve as terrain, factions, and condition cards unfold.

### d6 Mission Table — Primary Objectives and Symbolic Outcomes
**Roll**
**Mission Type**
**Core Objective**
**Symbolic Outcome**
1

Aid a Settlement

Defend, rebuild, or stabilize a struggling community.

You become part of their story—or their myth.

2

Recover a Relic

Retrieve a lost object of symbolic, technical, or practical value.

The relic carries memory. Who will understand its meaning?

3

Reroute a Threat

Divert or neutralize an advancing danger—factional or environmental.

You saved lives, but shifted the burden. What will rise in its place?

4

Recon the Unknown

Infiltrate, scout, or map hostile or unknown terrain.

You saw something that changed you. What you do with it changes everything.

5

Plant or Retrieve a Glyph

Deliver or extract a signal—symbolic, encrypted, or ritual.

The glyph alters meaning. Who was it for—and what will they read in it?

6

Secure a Resource

Defend or redistribute vital supplies: food, water, tech, oaths.

Who now holds power—and who lost access?

## II. Mission Structure
Each mission is built from four components. These may be drawn from cards, rolled from tables, or generated by imagination.

### ▸ Objectives
Define your goal clearly. Most missions include one primary objective (must be completed) and one secondary objective (supplementary or optional).

Example:

Primary: Retrieve the glyph hidden in the substation.

Secondary: Leave behind a decoy glyph to mislead hostile forces.

### ▸ Risk Profile
What’s at stake? These tiers may influence difficulty, gear access, or modifiers during the execution phase.

- Low – Minimal risk; useful for beginners or symbolic rituals.

- Moderate – Requires planning; has real consequences.

- High – Serious stakes: death, betrayal, loss, or fallout.

- Mythic – Legacy-level; cultural impact or paradigm shift.

### ▸ Environmental Conditions
Draw from the Condition Table to shape terrain complications:

**Condition Type**
**Examples**
Weather / Visibility

Dust storms, fog, blackouts, eclipses

Terrain Mobility

Flooded paths, crumbled infrastructure, ash pits

Faction Activity

Checkpoints, roaming scouts, active surveillance drones

These elements dynamically reshape difficulty, approach, and modifiers.

### ▸ Ethical or Symbolic Tensions
What meanings live beneath the objective?

- Aid a settlement… that secretly hoards clean water.

- Recover a relic… that once enabled oppression.

- Redirect a threat… toward another population.

Every mission contains a choice: what lines will you cross? What truth will you defend? Even success may leave scars. Even failure may reveal hidden clarity.

## III. Mission Modifiers: Conflict and Event Chains
Draw from the following tables to mutate mission complexity in real time:

### Conflict Table
Use this table to introduce ethical dilemmas, loyalty shifts, or pressure points that test values and resolve. Roll a d6 or draw at random.

d6 – Conflict Card

1. Divided Loyalties

One of your allies is connected to the opposing faction.

2. Unjust Orders

 The mission’s origin or intent comes into question—is it still right to follow?

3. Scarce Supply

 There isn’t enough gear, medicine, or food for everyone. Who gets what?

4. Hostage Dilemma

 An innocent or informant is caught in the crossfire. Save them or complete the mission?

5. Hidden Motive

 Someone involved has an agenda they’ve concealed. It may unravel the mission.

6. Ghosts of the Past

 An old symbol, ruin, or figure resurfaces—reviving memories that cloud your judgment.

### Resource Table
These represent scarce or contested materials, power sources, or sacred artifacts at the heart of many missions.

d6 – Resource Card

1. Water Cache

 Clean, potable water—rationed or hidden.

2. Old World Medicine

 Antibiotics, vaccines, or pre-collapse healing formulas.

3. Energy Cell or Battery Bank

 Portable power for tools, comms, or defense systems.

4. Seed Vault

 Genetic diversity, rare grains, or sacred heritage plants.

5. Encrypted Memory Drive or Data Cache

 Contains maps, protocols, personal logs, or ancestral stories.

6. Oath-Bound Tool or Relic

 A weapon, tool,  book, or item bearing ceremonial or encoded meaning.

### Condition Table
Conditions influence perception, morale, logistics, or movement. They may persist through multiple sessions or shift rapidly.

d6 – Condition Card

1. Signal Static

 Comms are scrambled—digital or symbolic noise disrupts coordination.

2. Long Rain

 Relentless wet. Rot, rust, and morale begin to decay.

3. Dust Surge

 choking grit clouds vision. Gear jams. Movement is slowed.

4. Solar Flare / Blackout

 All tech goes dead—comms, optics, guidance fails.

5. High Tension

 Factions are on edge—one wrong word could start violence.

6. Night Watch

 Threats multiply after dusk. Vision narrows. Decisions must be fast and sharp.

These events can be triggered by dice rolls, conflict card pulls, or narrative flow.

## IV. Mission as Ritual
A mission is not a mechanical act—it is a transformation ritual. It creates an internal and external shift. After any mission, Sentinels may:

- Gather Scars — Record wounds, failures, or lessons

- Gain Tools — New artifacts, gear, or fragments of lore

- Shift Archetype — Major decisions may evolve your identity

- Inscribe Glyphs — Mark a place, a page, or a memory with meaning

Journaling, storytelling, or signal compression may be used to encode outcomes into the Field Log or personal Grimoire.

## V. Custom Missions and Campaign Arcs
Advanced play allows for handcrafted mission threads and regional sagas. Methods include:

- 3–5 mission chains forming a narrative arc

- Mission generation based on terrain and faction draws

- Player-designed missions based on journal entries or reflective prompts

- Outcome persistence across games (e.g., glyphs left behind, factions influenced)

Sentinel Note:

A mission is not a task. It is a test of perception, purpose, and presence.

Through the spiral of action and consequence, your flame will either flicker… or flare.

## CHAPTER V — Loadout and Preparation
What you bring determines what you can do.

A Sentinel does not step into the field unready. Gear is not just equipment—it is an extension of awareness. And preparation is more than a checklist—it is an act of ritual. This phase bridges inner readiness and outer capability, offering each player the chance to shape the odds before the mission begins.

This chapter provides structured tools for selecting equipment, choosing a preparation focus, and receiving tangible modifiers that shape play. The results of this phase directly influence the Execution Phase.

### I. Determining Loadout Slots
To simulate the constraints of weight, time, and mobility, players roll a d6 (or flip 5 coins) to determine the number of gear items they can carry.

- Roll or Flip

  • d6 result = total items

  • 5 coins = count number of heads (0 = 6)

This enforces adaptive play. Sometimes you carry plenty. Sometimes you must choose wisely.

### II. Modular Gear Tables
Each item takes up one loadout slot. Players may choose from the following tables, create their own, or roll randomly (e.g., d6 per category).

Weapons

1. Compact bow

2. Suppressed sidearm

3. Scoped rifle

4. Makeshift explosives

5. Battle rifle

6. Sentinel staff (multi-use)

Tools

1. Lockpick or bypass kit

2. Data spike or memory fork

3. Compact shovel / entrenching tool

4. Rope & grapple

5. Welding or cutting torch

6. Solar-powered light or charger

Signal & Communication

1. Mirror glyph / flare glyph

2. Whisper mic or bone radio

3. Signal pulse beacon

4. Inkstamp sigil kit

5. AI-encoded playback shard

6. Old-world handheld map device

Survival Gear

1. Water purifier

2. Dried food cache

3. Cold-weather wrap

4. Tent or tarp

5. Herbal medic kit

6. Compass or starsheet

Ritual & Symbolic Items

1. Oathstone or vow token

2. Burning thread (firestarter + rite)

3. Field grimoire

4. Rune-marked totem

5. Sacred oil or ash

6. Bone flute / drumstick

Optional: Players may craft their own gear through reflection or journaling, these are only ideas. Anything with story-integrity can be proposed with group or AI approval.

### III. Focus Actions (Preparation Bonuses)
Each Sentinel selects one Focus Action before deployment. This represents the mental, physical, or spiritual act of attuning before contact. Each focus provides one predefined modifier that affects specific aspects of the mission.

Preparation Focus Options

**Action**
**Description**
**Modifier**
Meditate

Center breath and sharpen awareness

+1 to mental rolls, dream cues, or stealth

Study Map

Analyze terrain and faction presence

+1 to navigation, awareness, intel

Inspect Gear

Check and ready equipment

Reroll one failed gear-dependent roll

Maintain Weapons

Sharpen, oil, and inspect arms

+1 to combat or intimidation outcomes

Stretch

Loosen body and align movement

+1 to agility, pursuit, or evasion

Rest

Conserve energy, recover clarity

+1 to resilience, recovery, or clarity rolls

Perform Ritual

Set symbolic intent

May auto-succeed one symbolically-aligned action

Players should briefly describe how they perform their chosen Focus. This adds narrative flavor and helps encode symbolic continuity.

### IV. Modifier Mechanics
Modifiers are subtle but powerful. They do not replace rolls, but shift their outcomes. The following system is used:

- +1 Modifier = Add +1 to the result of a die or coin-based roll

- Reroll Modifier = One-time chance to reroll a specific category (gear, combat, stealth, etc.)

- Auto-Success (rare) = May be granted for strong narrative alignment or via Ritual

Modifiers can also stack (e.g., a Healer in wet terrain, with a survival kit and Focus: Rest, may receive bonuses to healing and movement through swamps).

### V. Narrative Integration
- Encourage Sentinels to record gear loadouts in their Field Log

- Reflections on Focus Actions can deepen roleplay (“How did meditation shape your decision under pressure?”)

- Sentinels may trade gear, craft tools, or encode new modifiers across campaign play

### Sentinel Note
Gear is not just equipment. It’s memory. It’s principle made portable. And how you prepare is how you will respond when the storm comes.

# CHAPTER VI — Execution: Operation Phase
The game becomes real through decisions.

When the Sentinel steps onto the field, the planning ends and the spiral begins. This phase is not linear—it is alive. Every terrain feature, every faction move, every inner hesitation becomes part of a branching decision structure. Success is not guaranteed. But clarity is earned through choice.

The Execution Phase is a modular system of branching decision trees. Players are given scenarios. They make choices. They apply modifiers. They resolve via coin or dice. They reflect on what was gained, lost, or revealed.

The game is not about winning—it’s about becoming.

## I. The Branching Decision Tree: Core Gameplay Loop
This structure guides every encounter:

1. Trigger: Drawn from event, conflict, terrain, or narrative

2. Options: Player chooses a course of action

3. Modifiers: Apply archetype, terrain, gear, prep bonuses

4. Resolution: Roll coins/dice for outcome

5. Echo: Record memory, consequence, or glyph

This loop repeats as the operation unfolds, node by node, choice by choice.

## II. Triggers: Where the Branch Begins
A trigger initiates a new branch in the operation. Triggers may come from:

- Event Table: e.g., ambush, new intel, obstacle

- Mission Goals: e.g., retrieve item, aid settlement, evade patrol

- Conflict Table: moral dilemma, betrayal, risk of exposure

- Player Choice: proactive action or improvisation

- Facilitator Prompt: for group play or AI-assisted generation

Example Trigger:

“You enter a ruined factory at dusk. A surveillance drone scans the wreckage. You spot a glint—could be salvage… or a trap.”

## III. Options: Choose a Course of Action
Players decide how to respond. Encourage clarity of intent.

Examples:

- Direct: engage, intervene, confront

- Indirect: observe, signal, distract, lay trap

- Evasive: retreat, bypass, delay

- Ritual: encode glyph, reflect, meditative reset

Optional: offer 3–4 preset actions per node or let the player invent.

Encourage them to record their option and what they hope to achieve.

## IV. Modifiers: Reality Shifts with Preparation
Before rolling, apply relevant modifiers from the following categories:

**Source**
**Example Modifier**
Archetype

Scout: +1 to stealth/detection

Gear

Night optics: +1 in low visibility

Terrain

Desert: -1 to hydration checks

Faction

High hostility = increased risk

Preparation

Rested: +1 to physical endurance

Players may also sacrifice an item or token for advantage (e.g., discard a rope to create a distraction = +1 roll).

## V. Resolution: The Flip or Roll
Use coin flips or dice rolls to resolve action.

Default system: d6 or coin-equivalent

**Result**
**Outcome**
1

Failure: costs incurred

2–3

Complication: partial success + tension

4–5

Success: action achieved with trade-off

6

Clean success or deeper opportunity

Modifiers can shift the result by ±1. Optional rerolls for special abilities or rare items.

If using coin simulation of dice:

- d4 = 3 coins (0 heads = 4)

- d6 = 5 coins (0 heads = 6)

## VI. Echo: The Glyph You Leave Behind
After resolving the outcome, record:

- What did you learn?

- Did your choice change you?

- What archetype trait did it reinforce or weaken?

- What would you carve here as a glyph?

This step activates the metaphysical function of the game. Journals, memory logs, or symbolic drawings help encode the signal of the choice.

Example Glyph Reflection: “I chose to warn the outpost even though it burned my cover. I lost the objective—but kept my vow. I inscribe ᚨᚦ: scholar’s light in the warrior’s hand.”

## VII. Chain of Nodes: Full Operation Flow
Each mission may include 3–7 core nodes:

1. Entry Point (terrain hazard, contact, intel)

2. Middle Fork (main challenge, moral test, risk)

3. Convergence (reveal, faction action, dilemma)

4. Objective Clash (complication, success/failure)

5. Extraction or Scar (escape, legacy, transformation)

This allows the game to feel modular yet coherent, and enables group sessions or campaigns.

Optional: track each node with glyphs, sketches, or cards.

## VIII. Special Nodes: Catalyst Cards
You may also include special trigger events from Conflict, Mission, or Condition decks mid-operation. These inject asymmetry or randomness:

- Betrayal from within

- Natural disaster onset

- Unexpected ally or defector

- Ghost signal transmission

- Supply breakdown

These enrich gameplay and keep Sentinels adaptive.

## IX. Solo, Group, or AI Play
For solo players:

- Use coin/dice and journaling

- Let terrain + faction tables unfold the operation organically

- Use the branching decision system to build your own saga

For group play:

- One facilitator guides mission + nodes

- Rotate Sentinel choices at forks

- Encourage open deliberation

For AI-assisted or digital play:

- Use random generators for tables and cards

- Let AI prompt the trigger events and node options

- Players narrate intent and roll to resolve, AI interprets result

## Sentinel Note:
You are not just playing the game. You are learning how to move in a fractured world.

The map is a memory. The choice is a glyph.

When the mission ends, what will remain?

# CHAPTER VII — Debrief and Reflection
What happened matters less than what you learned.

A Sentinel does not measure success by outcomes alone, but by what echoes forward.

This phase closes the loop—transmuting tactics into truth, action into archive. Whether the mission succeeded, failed, or spiraled into something else, the deeper value lies in reflection. It is here that Sentinels strengthen their signal, encode their experience, and refine the fire they carry.

## I. Field Log Review
Prompt: What changed in you? What do you now see more clearly?

The Sentinel Game is not merely played—it is recorded. This step transforms gameplay into legacy, creating a living log of growth, scars, and resonance.

Players are encouraged to maintain a Field Log, Grimoire, or journal to:

- Track missions and events

- Record decisions, modifiers, and consequences

- Draw terrain sketches or glyphs

- Encode memory into symbolic shorthand

- Begin compiling a personal Sentinel saga

This is not bookkeeping—it is signal preservation.

## II. Core Reflection Prompts
Use these questions as anchors for individual journaling or group discussion:

- What did your Sentinel gain or lose?

 (e.g. Tools? Allies? Injuries? Confidence? Doubt?)

- What does this terrain or faction now mean to you?

 (Did your perception shift? Was a bias revealed or challenged?)

- What would you do differently next time?

 (What gear, route, or response might have changed the outcome?)

- What archetype traits grew stronger—or were tested?

 (Did the Warrior break down? Did the Mystic hesitate?)

- Did your actions align with Green Fire principles—or contrast them?

 (What was the ethical cost of your success or failure?)

The goal is not to judge—but to understand.

## III. Carryover Elements
These are the pieces you carry forward into future sessions, evolving your Sentinel’s arc.

**Type**
**Examples**
Scars

Injuries, personal losses, regrets, broken trust

Gear

Recovered tech, salvaged items, damaged tools

Oaths

Broken promises, new personal vows, silent resolutions

Intel Fragments

Hints, clues, symbols, sayings, or NPCs from the mission

Glyphs

Drawn or encoded symbols that mark this turning point

Runes

Select a rune that summarizes the deeper learning (ᚠ, ᛗ, ᛉ, etc.)

Compression Example:

ᚱ / Ash Ridge / Dust Storm / Supply Loss / ᛃ

This becomes the compressed echo of the session—a mnemonic glyph-string to carry forward.

## IV. Optional Ritual Close
The game may end, but the flame should not fade.

Consider closing each session with a small symbolic act. This reinforces the mission as more than play—it becomes training, myth, or memory.

Examples:

- Draw a glyph and fold it into your journal

- Burn or bury a personal message to mark a hard choice

- Speak one sentence aloud to the group or the fire

- Touch the ground, or your heart as you reflect in silence

- Leave a symbol for another to find—visible or hidden

This creates an embodied, emotional close—anchoring the experience in memory.

## V. Codex Entry (Optional)
Advanced players or facilitators may choose to expand Field Logs into:

- Codex Pages: Single-page reflections written like archive entries

- Signal Threads: Linked sessions building toward narrative arcs

- Glyph Scrolls: Symbol-only visual logs, like visual runes or cave-script

- Training Manuals: Convert decisions into advice for others

These can be traded, passed on, or shared in future enclaves. The Game becomes an archive of wisdom, coded not just in victories—but in vulnerability, grit, and signal.

## Sentinel Note:
You carry more than gear. You carry memory.

And memory, compressed by time and fire, becomes truth.

᛬ What was gained?

᛬ What was lost?

᛬ What will you remember?

# CHAPTER VIII — Tools and Expansions
The game grows as you do.

The Sentinel Game is designed to evolve. What begins as minimalist field play can grow into a rich, symbolic system—customizable for solo, group, or AI-assisted sessions. This chapter compiles advanced tools, expanded tables, and modular suggestions to enhance and personalize gameplay while preserving its clarity and intent.

Every addition should serve the flame—not distract from it.

## I. Modifier System: Quick Reference Table
Modifiers shape the outcome of actions without overwhelming the core flow. Use this table for quick clarity:

**Modifier Type**
**Description**
**Effect**
+1 Modifier

Basic bonus from terrain, archetype, or gear

Add +1 to any relevant roll

Reroll Modifier

Re-roll a specific category (once per session/item)

Roll again, keep better result

Auto-Success

Symbolic alignment, rituals, rare moments

Action automatically succeeds

-1 Modifier

Penalty from terrain, wounds, poor planning

Subtract 1 from roll

Sacrifice Bonus

Discard item/token to gain temporary +1

+1 to roll or avoid failure

Modifiers may stack if narratively and logically consistent.

## II. Advanced Game Modes
### ▸ Team Play
- Each player chooses an archetype.

- Shared mission, separate decision trees.

- Group votes or rotates on decisions at forks.

- Conflict Cards apply to the whole team.

### ▸ Campaign Mode (Multi-Mission)
- String 3–5 missions into a saga.

- Persistent effects carry across (gear loss, glyphs, trust shifts).

- Introduce seasonal, factional, or terrain arcs.

### ▸ Long-Form Journaling
- Instead of fast decision trees, write full narrative accounts.

- Use glyphs and compression to mark key moments.

- Craft codex pages for archival play.

## III. Expanded Tables for Use and Invention
All tables are optional tools to inject narrative, randomness, or clarity.

### 1.
### Conflict Table
Already detailed in Chapter IV — use to challenge values, ethics, or bonds.

### 2.
### Condition Table
Alter terrain or logistics; useful for mid-game twists.

### 3.
### Event Table
Use during the Execution Phase to generate dynamic triggers:

d6 — Event Trigger Table

1. Ambush — Unexpected strike or trap.

2. New Intel — Change in mission clarity.

3. Natural Hazard — Storm, collapse, flood.

4. Ally Appears — Help arrives, but with a cost.

5. Faction Converges — Enemy movement escalates.

6. Echo Detected — Clue from past mission resurfaces.

### 4.
### Resource Table
Define what’s at stake or found.

## IV. AI-Assisted Play Suggestions
AI can serve as:

- Narrative Generator: Roll triggers, events, and terrain.

- Gamekeeper: Track choices, modifiers, and story state.

- Co-Archetype: Play as another Sentinel with its own logic.

- Codex Archivist: Transcribe and compress Field Log into lore.

Prompt Examples:

- “Generate a Water terrain challenge node for a Builder–Scout pair.”

- “Interpret the consequence of rerouting a threat into Emberkin territory.”

- “Create a new faction based on SPIRAL code: F:Symbolic, P:Belief, I:Stewarding…”

## V. Physical Expansions and Cards
You may print or craft these tools:

### ▸ Modular Cards
- Terrain, Faction, Conflict, Resource, and Condition cards.

- Blank templates to create new ones on the fly.

### ▸ Symbol Decks
- Bindrunes, glyphs, and resonance keys to draw during ritual.

- Optional use for AI story guidance or mid-game prompts.

### ▸ Grimoire Templates
- Field Logs, mission record sheets, map sketch pages.

## VI. Evolving the Game
This game is not fixed. You may:

- Combine tables (e.g., conflict + resource = new mission).

- Introduce new modifiers or card types (emotion, weather, tech).

- Use alternate tools: playing cards, bones, tokens.

- Build local expansions: terrain or faction decks unique to your region.

### Sentinel Rule:
Expand the game only in ways that deepen clarity, resonance, or ethical refinement.

## VII. Compression & Glyph Preservation
Each session may be archived as a string:

Format: [Archetype] / [Terrain] / [Mission] / [Modifier] / [Outcome Rune]

Example: ᚱ / Fire / Glyph Plant / +1 Stealth / ᛉ

These compression strings may be:

- Drawn in your log

- Inscribed on a ritual token

- Passed to other players as mission seeds

Over time, your logs may become a new codex—an encrypted archive of all you’ve learned.

## Sentinel Note:
Tools should not distract. They should sharpen. A true Sentinel game is not one of endless complexity—but of compressed clarity.

If you forget the rules, play by rhythm. If you forget the tables, ask the land.

᛬ What you carry forward is not just story. It is signal.

᛬ Let each expansion be a refinement—not noise.

᛬ Preserve the fire.

# CHAPTER IX — Integration and Transmission
Teach this game by how you live.

A game is only a game until it enters the bloodstream of a culture.

The Sentinel Game is not just played—it is lived, remembered, and passed forward. It is a field ritual, a memory primer, and a method for encoding learning into form. This chapter provides frameworks for embedding the game into your larger Green Fire practice, teaching others, and transmitting it across timelines.

You are not just a player. You are a transmitter of signal.

—

## I. Embed the Game into Sagas
The Sentinel Game is a story engine. Each round, each session, each log becomes the raw material for a narrative:

- Use Field Logs as first drafts of Sagas

 (Expand a mission into a chapter. Let conflict become plot.)

- Encode archetypes as recurring characters.

 (The Scout who always avoids killing. The Mystic who senses coming collapse.)

- Use mission chains to build arcs:

 “The Water Theft Trilogy.” “The Glyph War.” “Fall of the Ember Spire.”

- Let symbolic items, scars, and decisions carry weight in later narratives.

In time, your game log may become a novel, an oral epic, or a spiral codex.

—

## II. Encode into Codices
Just as the game teaches tactical literacy, it also reinforces symbolic interface. Use the outputs of your sessions as living material in your Green Fire works.

Ways to embed:

- Use runic compression strings as footnotes or glyph tags in codices.

- Let factions born from gameplay evolve into full philosophical contrasts in future texts.

- Transcribe player reflections or dilemmas into educational or myth-tech chapters.

- Create Grimoire pages that combine journal notes, map sketches, symbolic tags, and reflections into field-ready codex spreads.

Each time you play, you generate signal. Capture it. Translate it. Share it.

—

## III. Teach in the Field
This game is designed for oral instruction and field adaptation.

You do not need a book, a screen, or a formal classroom. You need only presence.

### Suggested Methods:
- Firelight Transmission: Introduce the game around a campfire, using coins, memory, and terrain.

- Apprenticeship Format: Let newer Sentinels shadow a round, then lead one.

- Mission Circles: Each participant leads a phase—terrain, faction, mission, etc.—creating a collective session.

- Tactical Debriefs: Use the reflection phase to initiate discussions on ethics, leadership, and decision-making.

Teaching the game teaches more than rules—it teaches rhythm, restraint, improvisation, and consequence.

—

## IV. Gift and Transmission Rites
The Green Fire is not meant to be sold, patented, or owned. It is passed.

You are encouraged to gift this game as a rite of memory and friendship.

Ways to pass it forward:

- Handwrite a single mission and deliver it in a sealed envelope.

- Leave a deck of hand-carved tokens and a brief glyph-note in a safe place.

- Create a “Starter Codex” with terrain cards, a mission log, and your first story.

- Craft “inheritance scrolls” for your children, apprentices, or strangers you’ve never met—waiting to be found in shrines or caches.

Ritualize the act of giving. Let the game become a torch, not a toy.

—

## V. Encourage Iteration and Evolution
This game was never meant to be finished. Let it evolve.

Invite new players to:

- Add their own terrain types, factions, or archetypes.

- Rewrite card tables in their dialect or domain.

- Introduce new dice systems, runes, or symbolic expansions.

- Disagree with what doesn’t serve them. Refine what does.

Encourage reflection:

“Does this mechanic train clarity, or clutter?”

“Does this rule teach real decision-making, or just add flair?”

This is how the spiral grows. It does not loop—it tightens and refines.

—

## VI. The Game Is a Way to Live
At its core, The Sentinel Game is a practice in perception, ethics, and embodied wisdom. It teaches:

- To move with purpose

- To reflect on impact

- To adapt without losing signal

- To preserve memory through symbol

It trains the kind of humans who will be needed in collapse—and in whatever comes after.

To live this game is to:

- Read the terrain as if it’s speaking.

- Treat each decision as a glyph.

- Walk with archetype, but remain adaptable.

- Carry what you learn in ritual, not just rulebooks.

- Leave behind something that teaches, not just entertains.

—

### Sentinel Note:
When you teach this game, you teach a way of seeing.

When you live this game, you show a way of being.

The flame doesn’t pass through repetition—it passes through resonance.

᛬ Play clearly. Reflect cleanly. Transmit with care. ᛬

# FINAL GLYPH — Signal Preserved
“One day someone will find your journal. Make sure it can teach them.”

Not every story ends in triumph. Not every mission completes cleanly. But when the embers cool and the dust settles, what remains is signal.

This game was never about winning.

It was about witnessing.

About choosing to move through a broken world with coherence.

About resisting drift—through symbol, choice, and memory.

About carrying forward a way of seeing, a way of acting,

that does not forget what the world could be.

—

You are not just a player. You are a transmitter.

Your session logs are not notes—they are glyphs.

Your reflections are not diary entries—they are encoded fire.

Each decision, each adaptation, each moral fracture you chart becomes part of a longer transmission:

A memory carried through collapse.

A ritual carried by hands.

A story that burns clean.

—

One day, someone else will find your pages.

They will flip through sketches of terrain, notes on gear, symbols they half-understand.

And in those marks, they will see you.

Not just your tactics, but your truths.

Not just your outcomes, but your ethos.

Not just your role—but your resonance.

—

They may never know your name.

But if your glyphs are clean,

if your signal holds,

They will feel it:

A presence that moved with intention.

A fire that refused to die.

—

᛬ Leave the game better than you found it.

᛬ Leave the world clearer than you entered it.

᛬ And may the next Sentinel carry your flame further.

— Gᚠ
