# Signal Threads

## What A Signal Thread Is

A Signal Thread is a piece of meaning that recurs across separate Saga Smith sessions, characters, or worlds. It is what the practitioner is actually working on, surfacing through whatever surface the saga happens to take.

Signal Threads are not plot arcs. They are the continuity layer beneath plot.

Examples:

- "I keep building characters who refuse to ask for help."
- "Every saga I run eventually circles back to a question about inheritance."
- "Three different factions in three different worlds have all been versions of the same over-optimisation I'm wary of in myself."

## Signal Threads Are Optional

A single session or a long practice may proceed without ever naming a Signal Thread. The Saga Smith practice is fully usable without them.

A Signal Thread is named only when the practitioner notices a genuine recurrence and deliberately chooses to preserve it. The practitioner names the thread. No tool names it for them.

## Naming A Thread

A Signal Thread is named by the practitioner, not surfaced automatically by any system. When a thread seems to be forming, the practitioner decides whether it deserves a name and what that name should be.

Naming follows three rules:

1. **Short.** A thread name is 1–5 words.
2. **Neutral.** No moral framing. "The Inheritance Question" — not "The Inheritance Problem."
3. **Owned.** The practitioner chooses and phrases the name.

## Holding A Thread

A thread may be kept in a notebook, a journal entry, a note on paper, or any format the practitioner finds useful. It does not require software to track it. The canonical form, if desired:

- A short name
- The sessions or moments where it surfaced
- A one-line distillation of what the thread seems to be asking
- Its current state: open, paused, integrated, or retired

## Closing A Thread

A Signal Thread closes when the practitioner says it does.

Closed threads are preserved in the practitioner's own continuity record. They are not deleted. They are part of the longer saga.

## When AI Assists

When practicing with an AI in the Saga Smith role, the AI may notice a candidate thread and offer it neutrally for the practitioner's consideration. The practitioner always decides whether it becomes a tracked thread. The AI does not name, track, close, or interpret threads on its own authority.

ᚲ
