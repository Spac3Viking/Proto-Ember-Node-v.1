---
title: "ᛋᚲ᛬ Sentinel Armory"
description: "Philosophy, ethics, and tactical frameworks for the prepared individual"
category: "foundational-works"
order: 7
---

# ᛋᚲ᛬Sentinel Armory

A Codex of Warfare, Survival, and Endurance


# Preface: Flames of War

Weapons are not toys.

They are not trophies.

They are not idols to be worshipped by weak hands and weaker minds.

A weapon is a responsibility.

A weapon is a burden.

A weapon is a promise — one forged in the fires of sovereignty and sealed with the blood of duty.

In the Green Fire philosophy, the weapon is understood not as a source of power, but as an extension of the self — a reflection of the spirit that wields it.

It is not the blade or the rifle that defines the warrior.

It is the will behind it.

It is the clarity of purpose that lifts it.

It is the discipline of restraint that sharpens it.

The Sentinel does not seek domination.

The Sentinel does not revel in bloodshed.

The Sentinel stands as shield and spear — protector, deterrent, and when all else fails, destroyer of those who would trample freedom and life.

This Codex is not written for armies of conquest.

It is not written for tyrants, despots, or cowards hiding behind uniforms.

It is written for those who choose responsibility over comfort.

It is written for those who understand that survival is not merely endurance, but honorable resistance.

It is written for those who will carry the flame forward — whether in battle, in teaching, in rebuilding, or in remembering.

The Sentinel Armory is not merely a vault of weapons.

It is a forge — a living, breathing testament to skill, honor, and resilience.

It holds not just tools, but the techniques, principles, and spirit that allow a free people to remain free.

The knowledge contained within these pages is not an end.

It is a beginning.

A living foundation for Sentinels yet unforged — warriors not born, but crafted through friction, hardship, and sacred duty.

Each rifle polished in quiet readiness.

Each blade sharpened in silent prayer.

Each breath taken in the stillness before chaos.

Each choice to protect, to hold fire, to act with both ferocity and mercy.

These are the true weapons.

These are the eternal flames.

You, reader, are the inheritor of this fire.

Tend it well.

Hone it with purpose.

Carry it forward into the dark places where others falter.

Be not merely a survivor.

Be a Sentinel.

# The Armory Awaits.


# ᛋᚲ᛬ Part I: Psychological Mastery — The Inner Fire

There is a weapon older than the bow,

deadlier than the sword,

more enduring than the bullet:

the mind that refuses to break.

Before the rifle is lifted, before the blade is drawn, before the charge is placed —

the battle is fought and won within.

The body can be starved.

The hands can be broken.

The weapons can be lost.

But if the will remains unbroken,

then the Sentinel still stands victorious.

This section forges the first weapon every Sentinel must master:

psychological resilience, emotional discipline, sovereign leadership of the self.

Without it, all is lost in the flames of hardship.

With it, the flames can be wielded to forge something stronger.


# Chapter I: Psychological Discipline and Field Resilience

## Breathwork and Stress Control Under Fire

When chaos erupts, the body betrays itself.

The heart races.

Vision tunnels.

Hands tremble.

The mind fogs.

The first battlefield is always within.

Breath is the bridge between fear and clarity.

In the heart of violence, the Sentinel trains themselves to command their breath as surely as they command their rifle.

Combat Breath Discipline \(Tactical Box Breathing\):

- Inhale for four seconds,  

- Hold for four seconds,  

- Exhale for four seconds,  

- Hold empty for four seconds.  


Even a single cycle can break the panic loop.

Three cycles can sharpen the mind like a blade.

Under fire, breath is armor.

Under pressure, breathing control is weaponry.

Amidst chaos, breath is life.

Train it.

Sharpen it.

Trust it.

## Trigger Ethics: The Discipline to Hold Fire

It is easy to kill in fear.

It is easy to waste bullets in panic.

It is easy to become the thing you once swore to resist.

It is harder — infinitely harder — to hold the trigger in wisdom.

The Sentinel understands that every shot is a prayer, a decision, a mark upon the future.

Before firing, ask:

- Is this shot necessary for survival or mission?  

- Is this shot aligned with duty, not anger?  

- Does this shot protect the innocent, or endanger them?  

- Is there another way to complete the task?  


To hold fire when it is righteous to do so

is a greater act of strength than to empty a magazine in rage.

Killing is not proof of strength.

Mastery of violence — and its restraint — is.

The Sentinel wields death only when necessary.

And in that necessity, wields it cleanly.

## After\-Action Memory Rituals: Journaling, Carvings, Oral Reports

The mind erodes faster than the body in war.

What is not captured, honored, and studied is lost forever.

The Sentinel treats memory as sacred ground.

After every engagement, every battle, every decision point:

record the lessons.

Journaling:

- Brief notes: actions taken, results seen, emotions felt.  

- Honest, brutal, clear.  

- Write for the future Sentinel — not for pride.  


Carvings and Markings:

- Etch small sigils or short runic phrases into safe places.  

- Stones, bunker beams, hidden trail signs.  

- Silent testimony that “We were here. We learned. We endured.”  


Oral Reports:

- Story circles within units.  

- After\-action debriefs in calm tones.  

- Speaking truth before ego poisons memory.  


Memory, codified, becomes wisdom.

Wisdom, carried, becomes survival.

Forget nothing.

Forgive where necessary.

Honor the living flame.

## Training the Will: Hardship Drills and Endurance Practice

The will is not born strong.

It is battered, shaped, tested — like steel in fire.

Sentinel Will\-Training Drills:

- Voluntary hunger and thirst marches.  

- Navigation under sleep deprivation.  

- Stress shooting after exhaustion runs.  

- Endurance tasks: Carrying wounded comrades, building defenses by hand.  

- Adversity bonding: Training with teammates through deprivation and pain.  


Hardship is not cruelty.

Hardship is refinement.

The warrior who has faced themselves in controlled suffering

will not shatter when real darkness falls.

They will stand while others collapse.

They will think while others panic.

They will act while others freeze.

And in that difference, they will become the blade others cannot match.

## Taking Ownership: Respect and Leadership of Self, Allies, Noncombatants, and Enemy

Freedom without responsibility is rot.

Power without restraint is corruption.

Victory without honor is defeat dressed in stolen colors.

The Sentinel does not merely survive.

They do not merely kill.

They do not merely win.

They take ownership — total and sovereign — of every life touched by their actions.

Leadership of the Self:

- Self\-discipline without waiting for orders.  

- Self\-correction without waiting for punishment.  

- Self\-honor without needing recognition.  


Leadership of Allies:

- Protecting teammates not as burdens, but as extensions of one’s soul.  

- Lifting the wounded.  

- Bearing the weight of decision without casting blame.  


Respect for Noncombatants:

- Shielding those who cannot fight.  

- Refusing to become a predator while pretending to be protector.  

- Understanding that protection, not power, defines true strength.  


Respect for the Enemy:

- Fighting with clarity, not hatred.  

- Recognizing humanity even as you confront it.  

- Ending only what must be ended, and no more.  


A Sentinel takes ownership because they know this truth:

The world is broken by those who refuse to govern themselves.

It is healed, however slowly, by those who stand as sovereign fires in the darkness —

who bear the weight willingly.

You are that fire.

You are that Sentinel.

Forge yourself accordingly.


# ᛋᚲ᛬ Part II: Philosophy and Foundations of War

Before hands are laid on steel,

before breath is drawn behind sights,

before the first oath is whispered beneath the stars —

there must be understanding.

War, in the Sentinel view, is not chaos.

Weapons are not toys, nor gods, nor machines of unchecked destruction.

Combat is not a game of ego.

The Armory is not a warehouse.

The Armory is not a showroom.

The Armory is a forge.

It is a living structure of knowledge, skill, discipline, and sacred memory —

a flame carried not in gear, but in the mind, the spirit, and the will.

This section carves the philosophy that underpins all Sentinel warfare.

Without it, tactics are flickering flames.

With it, every act becomes a meaningful blaze.


# Chapter II: The Armory Philosophy

## Weapons as Tools, Reflections of the Sentinel Spirit

A blade can carve wood or flesh.

A rifle can be used to extort a village or topple a tyrant.

A hand can build or destroy.

The weapon is not evil, nor holy.

It is only what the wielder chooses it to be.

The Sentinel understands:

Weapons are tools — nothing more, and nothing less.

But though they are mere tools, they are reflections.

What someone chooses to carry — and how they choose to wield it — reveals who they truly are.

A sharpened blade reflects preparation.

A scarred rifle reflects experience.

A well\-maintained sidearm reflects discipline.

A quiver of arrows, carried despite age or scarcity, reflects defiant hope.

The weapon itself is mute.

The spirit behind it speaks volumes.

The Sentinel cleans their rifle not for vanity, but for duty.

The Sentinel trains with their blade not to glorify violence, but to master necessity.

In all things:

It is the Sentinel — not the tool — who carries the burden, the choice, the flame.

## Ethical Use of Force: Protection, Deterrence, Disruption

Force is a form of language.

Each act of violence speaks to the world:

it reveals the heart of the fighter, the soul of the tribe, the truth of the cause.

The Sentinel wields force with three ethical purposes:

1. Protection:  

	- The first, highest purpose.  

	- To defend the innocent, the helpless, the future.  

	- To stand as shield before predator, tyrant, desolation.  

2. Deterrence:  

	- To project strength so clearly, so efficiently, that conflict is avoided.  

	- To make the act of aggression so costly that even fools reconsider.  

3. Disruption:  

	- When no other path remains,  

	- To strike with precision, to unmake that which seeks to enslave or destroy,  

	- To break machines of oppression, to disrupt engines of tyranny,  

	- Not for pleasure, not for conquest — but to reset balance, to reopen the path to peace.  


The Sentinel does not kill because they enjoy it.

The Sentinel does not burn because they hunger for destruction.

The Sentinel fights so that fighting may one day become unnecessary.

They carry force not as a trophy, but as a final mercy.

## Mastery of Skill, Self, and Team Over Gear

In a world obsessed with equipment, technology, and specialization,

the Sentinel carries an older truth:

Skill is superior to gear.

Mind is superior to muscle.

Teamwork is superior to resources.

An untrained man with a machine gun dies against an experienced man with a bow.

An undisciplined squad with armor falls to a disciplined trio with rifles and a plan.

Gear may break.

Supplies may run out.

Technology may falter.

But skill endures in the body, mind, and heart.

The Sentinel trains with his team as an extension of himself:

Thinking together, moving together, firing together, enduring together.

No Sentinel fights alone — even in solitude, they carry the wisdom, training, and memory of the Green Fire.

Thus the armory is not merely external:

it is carried within every step, every breath, every decision made under the weight of survival.

Master the skill.

Master the self.

Forge the team.

Then, and only then, master the gear.

## The Codex as a Living Flame — Not a Finished Monument

This Codex — the Sentinel Armory — is not finished.

It is not perfect.

It is not complete.

It is not meant to be a stone tablet etched once and worshipped blindly.

It is a living flame.

Every Sentinel who studies these words, who trains these skills, who fights these battles —

adds fuel to the fire.

Shapes the light in new ways.

Refines the steel in new heat.

This Codex will grow.

It will change.

It will be challenged, amended, rewritten by blood and dust and time.

And that is as it should be.

The world itself is not static.

Neither must our knowledge, our tactics, or our philosophy be frozen in arrogance.

To honor the past, we must forge the future.

Every engagement will evolve us.

Every mistake will teach us.

Every victory, every defeat, every scar, will refine the fire.

Thus the Sentinel who reads these pages carries not a rulebook —

but a torch.

May you carry it wisely.

May you carry it fiercely.

May you carry it forward into the dark —

and may it never be extinguished.


# Chapter III: Warfare Doctrine of the Few Against the Many

## Introduction: The Laws of the Outnumbered

The Sentinel does not fight for conquest.

The Sentinel does not fight for plunder.

The Sentinel does not fight to impose a throne upon a broken world.

The Sentinel fights to protect the flame of life itself.

The world the Sentinels defend —

its lands, waters, trees, skies, children, memories —

is not a possession.

It is a sacred trust.

Where others see only resources, the Sentinel sees a living world worth saving.

Where others see only crowds, the Sentinel sees kindred hearts worth defending.

Where others see only ashes, the Sentinel sees embers ready to blaze anew.

Thus the Sentinel fights —

outnumbered, outgunned, outshouted —

but never outlived.

Because the flame they carry is fed not by numbers, but by purpose.

This is the Warfare Doctrine of the Few Against the Many.

## Core Principles of Asymmetry: Terrain, Tempo, Multiplication

When facing superior numbers, the world itself becomes your ally.

Terrain:

- The forests, mountains, rivers, and ruins favor those who know them best.  

- Fight not in open plains, but in twisted paths and shadowed valleys.  

- Shape the field with traps, obstacles, and concealments the enemy cannot predict.  


Tempo:

- Control the rhythm of engagement.  

- Attack suddenly, disappear swiftly, return unexpectedly.  

- Deny the enemy the comfort of planning and routine.  


Multiplication:

- A small team with sharp minds becomes a force greater than its size.  

- A few rifles in skilled hands can paralyze columns.  

- One quiet ambush can echo across an entire region.  


Victory is not in overpowering.

Victory is in shaping the enemy’s exhaustion and uncertainty until collapse becomes inevitable.

## Unpredictability as a Weapon

The predictable are the first to die.

The Sentinel learns to move like wind:

- Shifting patterns, shifting sounds, shifting silhouettes.  

- Never attacking the same way twice.  

- Striking where the enemy feels safest — when they least expect it.  


To the enemy, the Sentinels become a phantom.

An echo of fire.

A rumor made flesh.

The enemy’s greatest weapon — organization — becomes their greatest weakness when they cannot predict what cannot be charted.

Unpredictability is invisibility made kinetic.

## Decentralized Action and Mutual Purpose

Sentinels do not wait for distant commands.

They do not freeze when plans collapse.

They carry their orders within —

intent etched into their spirit, not their paperwork.

Each team, each fighter, acts with autonomy, for a shared sacred cause:

The protection of Green Fire.

The defense of the living world and the souls within it.

Mutual trust replaces rigid hierarchy.

Understanding replaces micromanagement.

Honor replaces obedience.

Sentinels are not isolated embers.

They are sparks in a living, breathing fire —

feeding each other even across distance, hardship, silence.

## Responsibility and Sovereignty Through Leadership

Leadership in Sentinel culture is not given by rank or decree.

It is earned by those who:

- Take ownership of their decisions.  

- Stand first in danger, last in safety.  

- Refuse to abandon their allies, their charges, or their cause.  


True Sovereignty:

- The authority to act born from the willingness to bear consequences.  

- The leadership of self, so that leadership of others becomes an extension, not an imposition.  


The Sentinel leads by being the most disciplined.

The most reliable.

The most centered.

Not by shouting commands — but by wielding an unseen light that others choose to follow.

In this way, Sentinel leadership becomes invisible and unbreakable — a force woven through the unit like breath through lungs.

## Shaping Engagement Zones Before Contact

Battles are won long before the first shot is fired.

The Sentinel prepares:

- Choosing ground where terrain is an ally and enemy is exposed.  

- Building false camps, decoys, dead trails.  

- Caching supplies, mapping escapes, booby\-trapping the approaches.  


The Sentinel does not stumble into combat.

The Sentinel orchestrates it — like a hunter steering prey into an unseen snare.

To the enemy, the engagement seems a chaotic accident.

To the Sentinel, it is a carefully composed symphony.

## The Sentinel and the People — The True Center of Gravity

The Sentinels are not an isolated army.

They are the guardians of the land, the communities, and the memories that nourish Green Fire.

Without the trust and support of the people:

- Every trail betrays them.  

- Every village hides dangers.  

- Every night closes like a trap.  


But when the people recognize the Sentinels as their protectors:

- Paths open.  

- Food and shelter flow generously.  

- Warnings are whispered before danger arrives.  

- The enemy’s power dissolves like mist in sunlight.  


Thus, the true war is not only against the enemy —

it is for the soul of the land and those who dwell upon it.

The Sentinel earns this trust:

- By protecting, not exploiting.  

- By honoring, not ruling.  

- By living alongside, not above.  


When the Sentinels and the people stand as one —

the invaders will find that they are not fighting a small force.

They are fighting a living world awakened.

And no empire, no machine, no tyrant has ever outlasted the fire of a people who remember who they are.

## Lessons from War of the Flea, Indirect Approach Strategy, and Unconventional Warfare

The Sentinels are heirs to forgotten truths:

From War of the Flea:

- Attrition is a blade sharper than slaughter.  

- Time bleeds the oppressor when the people resist quietly.  


From Indirect Approach Strategy:

- Strike weakness, not strength.  

- Disrupt and dislocate until the enemy collapses under their own weight.  


From Unconventional Warfare Doctrine:

- Victory belongs to those who live in the land’s memory,  
  
 not those who build castles upon its face.  


The Sentinels do not copy these lessons blindly.

They reforge them anew — sharpened to the era, the place, the fire they defend.

They are not the armies of old.

They are the echoes of a future still being born.

# Conclusion: Protectors of the Green Fire

The few will stand against the many.

Not because they seek death, but because they protect life.

Not because they desire power, but because they guard the sacred.

Not because they crave violence, but because they carry peace forward, shielded in flame and will.

The Sentinels are the caretakers of Green Fire —

the stewards of life, liberty, and memory across the ruins of fallen empires.

They do not fight alone.

The land stands with them.

The people stand with them.

The spirits of those who came before stand with them.

And through them, the fire shall not be extinguished.


# ᛋᚲ᛬Part III: Combat Application — Fire on the Field

Once purpose is clear,

once doctrine is understood,

the time comes to act.

But action without preparation is suicide.

Speed without structure is slaughter.

Courage without planning is tragedy.

The Sentinel’s fire is not wild.

It is shaped, aimed, and tempered.

This part of the Codex teaches how to transmute spirit into motion —

to think clearly, plan wisely, move fiercely, and adapt unstoppably across the living battlefield.


# Chapter IV: Mission Planning and Decentralized Operations

## The Alchemy of Action: From Philosophy to Movement

Mission planning is the living bridge between the Green Fire philosophy and battlefield reality.

It is the weapon with the greatest impact —

the forging of thought into kinetic reality.

A poorly\-planned operation squanders lives, resources, and opportunities.

A well\-planned operation multiplies strength beyond numbers.

Sentinel mission planning is built on:

- Clear intent,  

- Deep adaptability,  

- Autonomous cells bound by shared spirit,  

- Relentless preparation for chaos.  


## Information Gathering: Seeing Before Moving

No mission begins without knowing the ground, the enemy, and oneself.

Three Pillars of Intelligence:

### 1. Direct Observation

- Patrols, listening posts, forward scouts.  

- Quiet shadowing of enemy patrols, camps, resupply chains.  

- Recording patterns: when they move, when they relax, when they shift.  


Field Principle:

Observe unseen, move unheard, remember everything.

### 2. Human Intelligence \(HUMINT\) and Local Support

- The people are the lifeblood of the land.  

- Allies in villages, farms, trading posts offer early warnings, subtle intelligence.  

- Never exploit — build bonds of mutual defense and respect through generosity and reciprocity.  


Field Principle:

Trust is armor. Betrayal is a wound you inflict upon yourself through others.

### 3. Environmental Intelligence

- Season, moon phase, weather fronts, animal activity.  

- Reading the living signs of the land for opportunity and danger.  


Field Principle:

The land speaks. The wind whispers. Listen and learn

## Developing Mission Intent: Purpose\-First Planning

No plan survives the battlefield intact — but purpose does.

Sentinels build plans rooted not in orders, but in shared intent.

Steps for Developing Mission Intent:

- Define the Purpose:  

	- Protect? Destroy? Delay? Resupply? Evacuate?  

- Identify Success:  

	- What outcome fulfills the mission — not just tactically, but philosophically?  

- Identify Failure:  

	- What outcome must be avoided at all costs?  


Consensus Building Among Teams:

- Every Sentinel involved understands the why behind the mission.  

- As implicit understanding grows: a glance, a signal, a single word triggers entire shifts of plan.  

- Rehearsals are mental and physical:  

	- Walkthroughs, role\-switching, silent planning circles.  


Field Principle:

The plan is drawn in sand. The intent is etched in stone.

## Branching Plans and Decision Trees: Building Flexibility into the Framework 

Static plans die.

Living plans survive.

Sentinels forge decision trees rather than rigid orders.

Elements of Operational Branching:

### Primary Objectives

- Clear mission anchor points: seize cache, ambush convoy, exfiltrate personnel.  


### Secondary Contingencies

- If the primary succeeds: How to exploit momentum?  

- If the primary fails: How to regroup, salvage, or escape without collapse?  


### Extraction and Recovery Paths

- Routes mapped for withdrawal under:  

	- Light contact,  

	- Heavy pursuit,  

	- Wounded extraction.  

- Rally Points marked clearly before deployment.  


Field Principle:

Even when the trunk appears still, the branches are constantly moving. 

## Operational Flow Structures: Plan → Adapt → Flow → Act

Sentinel operations move like a living river:

1. Plan

- Establish intent, branches, rally points, contingencies.  


2. Adapt

- Read the battlefield as it changes.  

- Switch paths instantly when needed.  


3. Flow

- Maintain cohesion without rigidity.  

- Maintain clarity without micromanagement.  


4. Act

- Seize opportunities immediately.  

- Strike where needed without hesitation.  


Field Principle:

The river carves stone not through strength, but persistence and adaptability.

## Distributed Command Philosophy: Empowered Individuals, Unified Purpose

Sentinels operate without dependency on central control.

Each fighter is:

- A sensor,  

- A thinker,  

- A decision\-maker,  

- A bearer of sacred intent.  


Principles of Distributed Command:

- Every member must know the mission deeply enough to complete it alone if necessary.  

- Leadership shifts to whoever has the best perspective in the moment.  

- Coordination happens through mutual understanding, not shouted orders.  


In collapse conditions:

- Radio silence may be critical.  

- Physical separation may be common.  

- Chaos must be embraced, not feared.  


Field Principle:

If one ember remains, the fire still burns.

## Protecting Operational Security \(OPSEC\) in Collapse Conditions

The enemy does not need to defeat the Sentinel if they can predict them.

Thus, Sentinels weave their operations in shadows and smoke:

1. Codes and Ciphers

- Simple substitution codes for basic field signals.  

- More complex ciphers for detailed communication between cells.  


2. Story and Symbology

- Mythic overlays: referring to operations and targets through story references.  

- Runic shorthand to mark rally points, dead drops, sabotage points without exposing plans if intercepted.  


3. Behavioral OPSEC

- Never over\-rely on technology — assume every radio transmission can be intercepted.  

- Blend patterns into daily life where possible.  

- Deception operations: false trails, dummy signals, misinformation leaks to the enemy.  


Field Principle:

Truth moves under shadow. Victory is the story the enemy never reads.

# Conclusion: The Mind Before the Sword

The Sentinel’s true first strike is not a bullet, a blade, or a bomb.

It is a decision.

It is a breath taken in stillness.

It is a plan shaped in flame and patience.

Mission planning is the art of forging objectives into actions —

turning observation into momentum,

turning chaos into opportunity,

turning survival into victory.

The battlefield belongs to the prepared.

The future belongs to the sovereign.

The flame belongs to those who think before they strike.


# Chapter V: Small Unit Dynamics and Tactical Movement

## Introduction: Movement as Living Will

Movement is life.

Stillness is death.

But not all movement is survival — and not all stillness is defeat.

Sentinel warfare demands a new relationship with motion:

- Movement as sensing,  

- Movement as deception,  

- Movement as survival,  

- Movement as strike.  


This chapter forges how Sentinels move through a hostile world as living extensions of the Green Fire —

resilient, flowing, unpredictable, and unbreakable.

## Sentinel Squad Structure: Ecosystem of Combined Arms

The Sentinel squad is not a machine.

It is a living ecosystem — breathing, shifting, evolving.

Each squad member is a unique strand of skill:

- Rifle marksmanship,  

- Suppression fire,  

- Demolitions,  

- Medical care,  

- Reconnaissance,  

- Indirect fire support.  


No role is static.

Flexibility and cross\-training are sacred doctrines.

Squad Structure Truths:

- Every Sentinel can fight, move, and survive independently.  

- Every Sentinel strengthens the whole.  

- Leadership flows naturally through competence and awareness — not hierarchy.  


The squad flows like a living current, not a rigid formation.

## Buddy Teams, Triangles, and Diamond Formations

Buddy Teams \(2 Sentinels\)

- The foundational combat unit.  

- Mutual overwatch, care, and extraction.  

- One fights while one covers or supports.  


Triangle Teams \(3 Sentinels\)

- Mobile, flexible reconnaissance and assault elements.  

- 360\-degree awareness and overlapping firepower.  


Diamond Teams \(4 Sentinels\)

- Primary combat patrol unit.  

- Balances offense, defense, extraction, and sustainment.  

- Can fracture instantly into two buddy teams or reconfigure dynamically.  


Formation Field Principles:

- Formations are states of mind, not fixed geometric shapes.  

- Distance, position, and flow adjust constantly based on terrain and threat.  

- Every Sentinel is responsible for maintaining local cohesion and mutual support.  


## Terrain\-Adaptive Movement

There is no neutral ground.

Every inch of the world favors you — or your enemy.

Sentinel movement shifts to suit every environment:

### Road Movement

- Vulnerability is high: exposure to ambush, mines, surveillance.  

- Use flanking overwatch where possible.  

- Move unpredictably: vary spacing, speed, patterns.  

- Control intersections with decisive aggression.  


### Forest Movement

- Cover and concealment abound — but so does noise discipline.  

- Move slowly, feel the rhythm of the woods.  

- Avoid snapping branches, dragging gear.  

- Navigation by sun, moss, water flow, bird patterns.  


### Urban Movement

- 360° threat environment: rooftops, windows, basements.  

- Move from cover to cover: doorways, pillars, corners.  

- Control verticality: stairs, rooftops, balconies.  

- Expect ambush from above, below, and flanks simultaneously.  


### Cold Weather Movement

- Snow masks trails but magnifies visibility.  

- Breath control critical to prevent signature detection.  

- Weapons must be maintained against freezing and jamming.  

- Hypothermia precautions and calorie management are survival priorities: wear light weather blocking outer layers while moving, add warming layers while stationary

### Swamp and Water Movement

- Slow, exhausting, but stealthy.  

- Watch for disease, parasites, and exhaustion traps.  

- Silent water crossings for flanking movements at night.  


### Mountain Movement

- Altitude affects stamina, perception, decision\-making.  

- Movement must adapt to verticality: climbing, rappelling, slow stalking.  

- Sound carries differently — whisper winds and echo valleys require constant recalibration.  


Field Principle:

Move as the land dictates. It can be your mightiest ally.

## Combat Multipliers: Vehicles, Bikes, E\-Bikes, Boats, Gliders, Climbing Gear

Tools are not crutches.

They are momentary gifts — to be used and abandoned as needed.

Multipliers in Sentinel Doctrine:

- Vehicles:  
  
 Rapid displacement. Immediate fire support. Risk of ambushes and tracking.  

- Bikes / E\-Bikes:  
  
 Silent infiltration or rapid withdrawal over medium distances. Best for reconnaissance teams and courier missions.  

- Boats:  
  
 Waterways as invisible highways. Night crossings enable stealth operations deep into enemy territory.  

- Gliders / Ultralights:  
  
 Rare but devastating for surprise insertions or escapes across otherwise impassable terrain.  

- Climbing Gear:  
  
 Vertical movement: cliffs, city ruins, dense urban cores. Enables assaults or withdrawals others consider impossible.  


Multiplier Field Principle:

Tools serve the plan — not the other way around.

## Modular Elastic Spacing and Flow Doctrine

Movement must breathe:

- Expand when terrain demands.  

- Contract when threats tighten.  

- Always maintain the ability to sense, cover, and support each other.  


Elastic Movement Structures:

- No fixed distances.  

- Adjust spacing to noise discipline, cover density, enemy sensor threats.  

- Think like a living organism: nerve impulses \(signals\), blood flow \(movement\), healing responses \(adaptation\).  


## Signaling Systems: Stealth as Language

Silent communication is the true spine of Sentinel fieldcraft.

Hand Signs:

- Primary immediate communication: halt, move, enemy sighted, regroup, assault.  


Light Codes:

- Shielded strobes, flash patterns, colored signals for night operations.  


Noise Cues:

- Subtle clicks, hisses, taps — low\-audibility codes across short ranges.  


Animal Sounds:

- Birdcalls, frog croaks, subtle pack sounds used to mask signals in rural and forested terrain.  


Markings and Glyphs:

- Temporary symbols scratched in earth, drawn on trees, or left in ruins to silently guide trailing forces.  


Warhorns and Flares \(Combat and Emergencies Only\):

- Signals for attacking, shifting fires, breaking contact, etc
- Last resort signals: extraction needed, incoming danger, mass rally to fallback.  


Signal Field Principle:

The loudest signal is the one never needed.

## Rapid Reorganization and Chaos Adaptation: Flow Under Fire

The moment the first shot is fired, plans fracture.

Reorganization Techniques:

- Break into buddy pairs immediately if disrupted.  

- Fall back to triangle or diamond formations when safe.  

- Use visual or sound cues to realign fire sectors.  

- Rapid leadership shifts to whoever has clearest perspective.  


Rally Points and Micro\-Realignments:

- Predefined fallback and regroup points reduce confusion under chaos.  

- Rallies are mobile and flexible — no “last stand” mentality unless absolutely necessary.  


Adaptation Field Principle:

The river does not resist the rocks. It flows around them — and wears them down.

## The Battle Rhythm of Movement: Breathe, Flow, Survive

Battle movement is not frantic.

It is deliberate, rhythmic, breathing.

Sentinel Movement Cycle:

- Inhale: Assess terrain, sense threats, plan motion.  

- Exhale: Move, flow, strike, cover.  


Breathe when moving.

Breathe when pausing.

Breathe when aiming.

Breathe when surviving.

Field Principle:

Survival is breath made conscious.

Victory is breath made kinetic.

# Conclusion: Movement is Fire Made Flesh

The Sentinel does not stumble.

The Sentinel does not march.

The Sentinel flows —

through dust, through ruin, through storm —

a living extension of the Green Fire’s will to endure and protect.

Where others move mechanically,

the Sentinel moves with living rhythm, hidden patience, and silent force.

Movement is not transit.

Movement is survival.

Movement is war.


# Chapter VI: Precision Fire and Suppressive Warfare

## Introduction: The Rifle as the Backbone of Freedom

The great armies of empire lean on tanks, drones, and machines.

The true defense of liberty, life, and the future rests on something far simpler:

A Sentinel, breathing steadily, rifle steady, will unbroken.

The rifle is not a fetish object.

It is not a toy.

It is not a symbol of empty bravado.

It is the backbone of survival.

It is the voice of sovereignty when all other voices are silenced.

It is the tool by which Green Fire protects what must endure.

The rifle in a Sentinel’s hands is more than metal —

it is living will made force.

This chapter forges how the rifle — and the mind behind it — shapes battle.

## The Three Ways of Combat Shooting

Precision is not a singular skill.

It is an evolving flow, adapting to distance, environment, and chaos.

Sentinel marksmanship doctrine flows through three overlapping disciplines:

### Way of Stillness: Precision at Distance \(100–500m\+\)

Principles:

- Calm breath, calm body, clean trigger break.  

- Maximal use of natural or improvised support \(bipods, rocks, trees\).  

- Wind reading, light adjustment, terrain awareness.  


Training Focus:

- Fundamental marksmanship: natural point of aim, steady hold, smooth press.  

- Adjusting for environmental factors \(wind, humidity, elevation\).  

- Understanding minute of angle \(MOA\) and basic ballistic drop without reliance on electronics.  


Purpose:

- Accurate elimination of threats before they can endanger the team.  

- Initiating engagements on Sentinel terms.  


Field Mantra:

Stillness kills the noise. Stillness wins the moment.

### Way of Movement: Midrange Combat Fluidity \(25–100m\)

Principles:

- Movement and firing become one rhythm.  

- Rapid target acquisition under dynamic conditions.  

- “Flash sight picture” and instinctive adjustments rather than perfect form.  


Training Focus:

- Controlled pair and hammer drills.  

- Movement\-to\-cover and fire\-on\-the\-move training.  

- Zone shooting under pressure: center\-mass acquisition and adjustment drills.  


Purpose:

- Engage enemies during maneuver.  

- Dominate space in dynamic engagements without losing precision.  


Field Mantra:

Movement is life. Movement is control. Movement is fire.

### Way of Chaos: Close Quarters and Night Engagements \(<25m\)

Principles:

- Speed, violence of action, immediate threat elimination.  

- Point shooting and reflexive fire.  

- Maximum simplicity: minimum gear snag, maximum sensory awareness.  


Training Focus:

- Instinctive shooting at bad\-breath distances.  

- Target transitions and snap decision shooting.  

- Low\-light shooting: flashlight discipline, silhouette engagement, night movement firing.  


Purpose:

- Survive and dominate unexpected contact at breathing range.  

- Maintain fire superiority in blind or confused conditions.  


Field Mantra:

Chaos is the brother of death. Dance faster than him.

## Suppression Tactics: Breaking Enemy Will Through Fire

Suppression is not about killing.

It is about controlling the enemy’s mind and body through violence and pressure.

Principles of Effective Suppression:

- Fix the enemy behind cover: they cannot see, move, or fire accurately.  

- Force enemy mistakes through relentless pressure.  

- Shift fire to herd, fracture, or isolate targets.  


Key Sentinel Suppression Techniques:

### Talking Guns Concept

Multiple rifles, machineguns, or fireteams coordinate fire to create an overlapping, unbroken cadence of fire:

- One weapon fires.  

- As it reloads or cools, another weapon fires.  

- Constant rhythm keeps the enemy pinned and disoriented.  


Even small teams, if trained, can create the illusion of a much larger force.

Field Mantra:

The guns speak. The enemy listens in terror.

### Massed Rifle Fire to Replace Machineguns

In collapse conditions:

- Machineguns may be rare.  

- Ammunition may be precious.  


Thus, teams of Sentinels with battle rifles, DMRs, and carbines coordinate suppressive fire:

- Rapid, aimed shots at known or suspected enemy positions.  

- Overlapping fields of fire and bounding overwatch.  

- Short fire bursts to control muzzle rise and conserve ammo.  


Massed precision beats careless volume.

Five Sentinels with discipline can outfight twenty enemies with panic.

Field Mantra:

Accuracy is the new machinegun. Timing is the new volume.

## Fire and Maneuver: Flowing Fire Across the Field

Fire without movement is death.

Movement without fire is suicide.

Fire and Maneuver Doctrine:

- One element fires to suppress.  

- Another element maneuvers to flank, assault, extract, or bypass.  

- Constant communication — verbal, visual, intuitive.  


Maneuver Elements:

- Buddy teams peel left or right under suppressive cover.  

- Triangles and diamonds fracture and regrow based on cover, enemy position, and terrain.  


Field Execution:

- Bound in short bursts.  

- Never move across open ground without cover or overwatch.  

- Every movement is coordinated, or covered instinctively by allies.  


Field Mantra:

Flow through fire. Flow through death. Flow toward freedom.

# Conclusion: The Fire that Guards the Future

The rifle is not sacred.

The rifle is not profane.

The rifle is a responsibility.

It is the extension of the Sentinel’s mind, heart, and spirit:

- Sharpened by breath.  

- Steeled by training.  

- Aimed by love for the land and life protected behind it.  


One breath. One trigger press. One will.

The enemy may have more soldiers.

The enemy may have heavier weapons.

The enemy may have louder voices.

But the Sentinel has what they lack:

Clarity.

Precision.

Restraint.

Fire that flows, never fades.


# Chapter VII: Shotgunnery — Cornerstone of Adaptability, Suppression, and Disruption

## Introduction: The Practical Force Multiplier

In Sentinel operations, the shotgun is not a secondary weapon.

It is a versatile primary tool that fills critical gaps in collapse\-era combat.

- Breaching structures and obstacles,  

- Dominating close quarters,  

- Suppressing enemy movement,  

- Disabling drones,  

- Damaging vehicles and barriers,  

- Providing adaptable firepower when resources are limited.  


The shotgun’s strength lies in its flexibility, reliability, and overwhelming short\-range stopping power —

essential for decentralized, resource\-constrained warfare.

## Sentinel Shotgun Doctrine: Core Applications

Shotguns serve a wide range of operational roles within Sentinel units:

- Breacher: Mechanical and ballistic entry into fortified spaces.  

- Close Combat Assaulter: Room clearance and building domination.  

- Drone Defense: Anti\-air suppression at short to mid\-ranges.  

- Anti\-Vehicle Disruption: Slugs used against lightly armored targets.  

- Morale Impact: Psychological pressure during assaults.  

- Survival Utility: Hunting, signaling, and improvised defense.  


A well\-trained Sentinel with a shotgun can disrupt enemy formations, protect movement corridors, and enforce dominance inside confined terrain.

## Battlefield Use: Adapting to the Environment

### Breaching Operations

- Shotgun breaching uses buckshot, slugs, or dedicated breaching rounds.  

- Targets include:  

	- Door locks,  

	- Hinges,  

	- Barricaded entries.  


Key Techniques:

- Focus fire at structural weak points.  

- Use two rapid shots to ensure full breach.  

- Follow immediate entry protocols to avoid bottlenecking in fatal funnels.  


### Close Quarters Battle \(CQB\)

- Buckshot is highly effective inside buildings, alleyways, and tunnels.  

- Slug loadouts extend shotgun effective range slightly and provide penetration against light cover.  


Principles:

- Rapid movement through confined spaces,  

- Immediate threat neutralization,  

- Controlled, disciplined use of violence.  


Sentinels assigned to CQB roles should cross\-train in shotgun handling alongside their primary rifle systems.

### Suppression and Assault Support

- Shotguns provide short\-range suppression in ambushes, building assaults, or urban maneuver.  

- Massed shotgun fire disrupts enemy movement, forces retreats, and pins defenders inside structures.  


Tactical Use:

- Shotgun teams can lead the breach, providing shock effect,  

- They can also operate on flanks to prevent enemy escape from suppression fire zones.  


### Drone Defense

- Birdshot loads are used to target reconnaissance or attack drones at low altitude.  

- Open choke configurations maximize pellet spread to increase hit probability.  

- Slugs or flechettes may be employed for larger drones or higher\-altitude threats.  


Engagement Tips:

- Ambush drones from concealed positions when possible.  

- Prioritize disabling optics, rotors, and payload arms.  


### Anti\-Vehicle and Anti\-Equipment Tactics

- Slug rounds allow Sentinels to:  

	- Damage vehicle engines,  

	- Shatter windshields,  

	- Puncture tires,  

	- Disable mechanical systems.  


Engagement Strategy:

- Target vulnerable vehicle points \(engine blocks, tires\) at ambush sites.  

- Combine slug fire with explosives or indirect fire when possible for full vehicle kill.  


## Ammunition Flexibility

Common Shell Types and Their Use Cases:

- Buckshot: General\-purpose combat at short ranges \(0–40 meters\).  

- Birdshot: Drone engagement, small game hunting.  

- Slugs: Anti\-vehicle, barrier defeat, midrange precision \(up to ~100 meters\).  

- Flechettes: Extended range suppression; enhanced brush penetration.  

- Breaching Loads: Reduced\-penetration rounds for close\-quarters door and obstacle breaching.  


Improvised Ammunition \(Emergency Use Only\):

- Cut\-shells,  

- Loaded lead balls,  

- Modified handloads using available scrap —  
  
 \(only in last resort conditions, after rigorous testing\).  


## Maintenance, Repair, and Field Durability

Shotguns are mechanically simple, resilient weapons — well\-suited for collapse conditions.

Common Field Repairs:

- Replace worn springs with scavenged or fashioned wire.  

- Rebuild wooden stocks from field materials if necessary.  

- Keep chambers and actions clean to prevent fouling\-induced jams.  


General Maintenance:

- Routine lubrication is less critical for pump\-action designs — field\-reliable even with minimal care.  

- Breakdowns often occur at ejector springs, firing pins, or magazine tubes — know how to inspect and field\-repair these areas.  


## Operational Considerations and Limitations

While shotguns offer adaptability, they also have limits:

- Range: Effective under ~50 meters unless using slugs.  

- Reload Speed: Tube\-fed shotguns require frequent reloading; combat loading must be drilled.  

- Weight and Bulk: Ammunition can be heavy compared to rifle calibers; carry considerations matter.  


Tactical Solutions:

- Train reloading drills intensively.  

- Carry mixed ammo loads carefully organized by priority.  

- Know when to transition to rifle or secondary weapon if engagement range shifts beyond shotgun capability.  


# Conclusion: A Cornerstone of Adaptability

The shotgun is not a specialized niche weapon in Sentinel warfare.

It is a:

- Breaching tool,  

- Room\-clearer,  

- Drone killer,  

- Vehicle disabler,  

- Suppression multiplier,  

- Field survivor’s best companion.  


With proper training, mission\-specific ammunition selection, and disciplined use,

the shotgun becomes a critical force multiplier across multiple tactical domains.

For Sentinels operating in decentralized, resource\-scarce environments,

the shotgun is an enduring ally — simple, brutal, reliable, and endlessly adaptable.


# Chapter VIII: Breaching and Close\-Combat Operations

## Introduction: Close Combat Realities

Close combat is not clean.

It is fast, violent, and often decided in seconds.

In hallways, stairwells, ruins, and rooms,

decisions must be immediate, movement must be purposeful, and violence must be disciplined.

There is no time for hesitation.

There is no luxury for perfection.

This chapter provides a practical guide to small\-unit breaching and room\-clearing techniques appropriate for Sentinel units — emphasizing simplicity, speed, and survivability.

## CQB Fundamentals: Simplicity and Fluidity

In close combat:

- Simplicity wins.  

- Overthinking loses.  

- Preparation and practiced reflexes save lives.  


Three CQB fundamentals:

- Speed: Move fast enough to disrupt, but not so fast you outrun your ability to react.  

- Violence of Action: Dominate the space immediately and without half\-measures.  

- Fluid Movement: Once committed, do not stop — flow through obstacles, clear threats, secure ground.  


Sentinel Field Principle:

Hesitation kills. Simplicity survives.

## Room Clearing Techniques for Solo and Buddy Teams

Most Sentinel operations rely on small teams or individual clearing, not large unit tactics.

Solo Room Clearing:

- Approach the door at an angle \(not directly in front\).  

- “Slice the pie”: systematically clear sectors of the room before entry by pie\-ing the doorway.  

- When committed, move decisively through the threshold, clearing high, low, and blind spots.  


Buddy Team Room Clearing:

- Point Sentinel moves immediately through the doorway, clears the immediate threat zone.  

- Second Sentinel flows opposite: clears the far corner, checks behind cover, maintains crossfire discipline.  

- Clear primary threats first — doorways, windows, other points of enemy entry.  


General CQB Notes:

- Never stop in the fatal funnel \(doorways\).  

- Avoid bunching up in rooms.  

- Always prioritize threats over room order.  


Simple CQB Priorities:

1. Survive entry.  

2. Eliminate immediate threats.  

3. Control room.  

4. Secure movement path.  


## Breaching Tools and Techniques

Entry is often required — quickly, decisively, and sometimes forcibly.

Mechanical Breaching \(Preferred when Stealth Permits\):

- Crowbars, sledges, pry bars.  

- Leverage hinges or locks rather than battering at random.  


Ballistic Breaching \(When Speed Demands\):

- Shotgun breaching:  

	- Aim buckshot or slugs at lock or hinge assemblies.  

	- Two quick shots: one to break, one to ensure.  


Explosive Breaching \(If Resources Allow\):

- Small field charges placed directly on lock or hinge points.  

- Shaped charges \(improvised or salvaged\) can direct blast force to minimize room damage.  


Field Improvisation:

- Car jacks, wedges, even reinforced sticks can be leveraged for low\-noise breaches.  

- Pre\-breaching weakened doors with pry pressure before final entry.  


Sentinel Field Principle:

The goal is to enter with control, not with drama.

## Fallback Combatives: When Close Becomes Closer

When the distance closes to inches and firearms cannot be brought to bear cleanly,

fallback combatives are mandatory.

Weapon Retention and Rifle Strikes:

- Muzzle strikes, butt strokes, and weapon retention drills are basic survival skills.  

- Always fight to maintain control of your primary weapon unless absolutely forced to draw secondary or melee weapon.  


Knife and Blade Applications:

- Practical knife use focuses on short, fast thrusts into high\-value target areas:  

	- Neck, armpits, groin, kidneys.  

- Never engage in “knife fights” — fight to break free or end the encounter immediately.  


Improvised Weapons:

- Entrenching tools, short clubs, crowbars — all effective at close range if firearms are unusable.  


Tactical Grappling:

- Trip and break contact where possible — prolonged grappling in confined spaces is dangerous.  


Movement in Fallback Combatives:

- Keep moving.  

- Get back to your feet or regain your weapon as a first priority.  

- Know where your buddies are or where your fallback route is.  


Sentinel Field Principle:

Break contact when you must. Win it when you can. Fight to live, not to impress.

## Summary: Professionalism Under Pressure

The Sentinel approaches CQB with professionalism, not excitement.

There is no “rush” worth risking lives.

There is no “heroic entry” worth failure.

In close quarters:

- Think clearly.  

- Move deliberately.  

- Strike ruthlessly when necessary.  

- Control yourself first, then the fight.  


The breach and the room are not won by rage or passion —

they are won by discipline, simplicity, and execution under pressure.


# Chapter IX: Explosive Warfare — Field Demolitions and Engineering

## Introduction: Explosive Power with Disciplined Purpose

Explosives are not simply tools of destruction.

They are tools of disruption, mobility, denial, and psychological dominance —

if used intelligently.

A Sentinel treats explosives the same way they treat weapons:

- With respect,  

- With precision,  

- With discipline.  


This chapter presents a grounded guide to using field explosives effectively — not as a thrill, but as a strategic extension of will on the battlefield.

## Explosive Compounds: Performance and Handling

In collapse conditions, Sentinels may encounter or manufacture a range of explosive materials.

Common Compounds and Characteristics:

Compound

Primary Use

Handling Notes

C\-4

Shaped charges, precision breaching

Highly stable, moldable

TNT

General\-purpose demolition

Robust, reliable, moderate sensitivity

Ammonium Nitrate/Fuel Mix

Heavy charges, cratering

Requires careful containment and initiators

Black Powder

Improvised charges, signal explosives

Highly sensitive to sparks, static

ANFO \(Ammonium Nitrate/Fuel Oil\)

Large\-scale demolition, mining

Requires booster charges to detonate fully

Homemade Energetics

Varies by design — unstable

Only used when absolutely necessary, with caution

General Handling Principles:

- Minimize friction, shock, and static electricity.  

- Store in separate, padded containers until ready for assembly.  

- Work slowly, in clean, organized environments — even in field conditions.  


Sentinel Field Principle:

The careless worker destroys themselves first.

## Shaped Charges, Breaching, and Disruption

Shaped Charges: Focused Power

- A shaped charge directs explosive force into a tight, focused jet capable of punching through steel, concrete, or heavy doors.  

- Often constructed using:  

	- Cone\-shaped metal liners \(salvaged scrap, copper preferred\),  

	- Proper standoff distance \(typically 1.5x the diameter of the charge\).  


Practical Applications:

- Punching through vehicle armor,  

- Breaching fortified walls,  

- Targeted sabotage of infrastructure \(power poles, bridges, support beams\).  


Breaching Demolitions:

- Precision cutting charges used for entry through walls, doors, and barriers.  

- Small charges focused at structural weak points.  

- Field expedient linear cutting charges can be made with malleable explosives shaped around flexible materials \(wires, hoses\).  


Disruption Tactics:

- Target enemy mobility by disabling bridges, roads, railways.  

- Sabotage critical supply depots, ammunition dumps, or fuel storage.  


Field Principle:

Explosives are not for brute destruction. They are for opening doors the enemy thought closed.

## Improvised Traps and Resource Denial

Explosives extend the Sentinel’s reach beyond direct engagements.

Improvised Explosive Traps:

- Command\-Detonated Charges:  

	- Preferable for control and accountability.  

	- Wires, radio triggers, pressure switches.  

- Passive Traps:  

	- Pressure plates, tripwires, tilt devices.  

	- Higher risk of unintended collateral, used with extreme caution.  


Examples:

- Tripwire shotgun shell traps for building denial.  

- Pressure\-plate IEDs along key trails or convoy routes.  

- Improvised bounding charges \(grenade\-based or black powder\) for ambush zones.  


Resource Denial Techniques:

- Explosive charges on:  

	- Fuel stores,  

	- Ammunition caches,  

	- Water treatment plants \(only when absolutely necessary to deny enemy resources without causing civilian harm\).  


Ethical Considerations:

- Civilian safety and collateral damage must remain core planning concerns.  

- Sentinels fight with strategic discipline, not with reckless terror.  


Field Principle:

Traps buy time. They do not replace vigilance.

## Psychological Effects of Controlled Chaos

Explosives are not just tools of physics —

they are tools of mind warfare.

- Small, well\-placed explosive attacks create fear disproportionate to their physical impact.  

- Enemy morale degrades when they realize movement, resupply, and defense are never guaranteed safe.  

- Psychological pressure forces enemy mistakes — withdrawal, hasty advances, surrender.  


Controlled Chaos Tactics:

- Nighttime demolition of minor targets to deny enemy rest.  

- Ambushes supported by directional charges to confuse enemy command and control.  

- Periodic, seemingly random detonations to fracture enemy unit cohesion.  


Key Principle:

- Explosives are not used for spectacle.  

- They are used for psychological effects that create real tactical opportunities.  


Sentinel Field Principle:

The mind breaks before the body — if the earth beneath it shatters first.

# Conclusion: Fire as a Tool, Not a Toy

In Sentinel warfare, explosives are not used to show force —

they are used to shape force.

A properly employed charge can:

- Save lives by breaching a barricade,  

- Win battles by disabling enemy logistics,  

- Break enemy morale by sowing chaos at key moments.  


Explosive work demands:

- Caution,  

- Planning,  

- Respect.  


Every detonation shapes the flow of battle.

Every blast changes the landscape of survival.

Handled correctly, explosives are not just weapons — they are tools of life, movement, and enduring victory.


# Chapter X: Indirect Fire — Mortars, Launchers, and Heavy Improvised Systems

## Introduction: Force Without Direct Contact

Indirect fire allows small forces to strike enemies without facing them head\-on.

It enables Sentinels to:

- Disrupt enemy movements,  

- Harass morale,  

- Destroy critical positions,  

- Shape the battlefield before direct engagement.  


Indirect fire systems, even in crude or improvised form, act as force multipliers —

allowing decentralized fighters to influence a larger battlespace with minimal exposure.

This chapter provides a grounded overview of practical indirect fire methods suitable for collapse warfare environments.

## Field Mortar Systems: Powder, Air, and Spring

### Powder\-Fired Mortars

- Classic design: tube, baseplate, adjustable angle.  

- Propelled by black powder, smokeless powder, or scavenged charges.  

- Simple construction from salvaged steel tubing with welded or bolted base plates.  


Operational Notes:

- Powder quantity must be carefully measured for consistent range control.  

- Always fuse projectiles with delayed or impact\-sensitive charges to prevent premature detonation.  

- Barrel burst risks increase with overloading — careful maintenance and regular inspection are mandatory.  


### Compressed Air Mortars

- Safer but lower\-power option.  

- Air tanks \(scavenged from compressors or dive systems\) used to pressurize firing chambers.  

- Good for:  

	- Firing distraction munitions \(smoke, flares\),  

	- Launching light payloads at soft targets.  


Advantages:

- Lower risk of catastrophic failure.  

- Quieter launch signature compared to powder systems.  


Limitations:

- Limited projectile weight and range \(~100–200 meters optimal\).  


### Spring\-Loaded or Elastic Energy Mortars

- Cruder systems relying on heavy springs or elastic cords.  

- Suitable for short\-range harassment or field signaling.  

- Launch light explosive packages, fragmentation devices, or even weighted noise\-makers.  


Advantages:

- Simple materials.  

- Low noise signature.  


Limitations:

- Extremely limited range and payload capacity.  


## Crude Artillery Devices

When resources or mobility limit mortar use,

Sentinels adapt heavier improvised launch systems.

### Fencepost Ballistae

- Large tension\-based crossbows using metal posts and scavenged materials.  

- Launches heavy bolts, flaming payloads, or chemical delivery systems.  


Best Used For:

- Defending static locations \(enclaves, ambush sites\),  

- Psychological intimidation during sieges.  


### Soda\-Can Launchers

- Short\-barrel, powder or air\-pressured cannons sized for standard soda cans.  

- Cans can be loaded with:  

	- Black powder charges,  

	- Small fragmentation materials \(nails, bearings\),  

	- Smoke chemicals,  

	- Non\-lethal harassment devices.  


Advantages:

- Extremely easy to fabricate.  

- Excellent for harassment fire and noise disruption.  


### Barrel Trebuchets

- Medieval\-style counterweight trebuchets using barrels, rocks, or scrap weight.  

- Launch heavier projectiles across walls, rivers, or enemy fortifications.  


Best Used For:

- Siege harassment,  

- Disrupting fortified enemy camps.  


Tactical Note:

- Accuracy is secondary to effect.  

- Indirect fire is intended to harass, displace, and disrupt — not to snipe.  


## Psychological Harassment Through Indirect Fire

Even if casualties are minimal, indirect fire weakens enemy morale by:

- Denying safe rest periods,  

- Disrupting defensive preparations,  

- Forcing constant relocations,  

- Creating uncertainty and mental fatigue.  


Effective Harassment Techniques:

- Randomize firing times and locations.  

- Target enemy sleep cycles \(night harassment\).  

- Vary munitions between lethal and non\-lethal \(noise, smoke, shock devices\).  

- Attack high\-visibility targets to amplify perceived risk.  


Psychological Goal:

Make the enemy feel surrounded, vulnerable, and hunted.

## Dynamic Fire and Displacement Tactics

Static indirect fire is vulnerable to counterbattery fire, drone detection, and precision strikes.

Thus, Sentinel indirect fire doctrine emphasizes mobility and rapid displacement:

### Shoot\-and\-Scoot Procedures:

- Fire no more than 2–3 rounds per position.  

- Relocate immediately after firing.  

- Pre\-survey secondary firing positions before engagement.  


### Multiple Fire Teams:

- Scatter fire units across wide areas.  

- Rotate firing teams to prevent enemy from zeroing in on patterns.  


### Decoys and False Positions:

- Set up dummy mortars, fires, and smoke at decoy sites.  

- Force enemy forces to waste resources on empty fields.  


Sentinel Field Principle:

Move as soon as you are heard. Strike again before you are seen.

# Conclusion: Pressure Without Exposure

Indirect fire is not about killing alone.

It is about creating pressure:

- Breaking concentration,  

- Depleting resources,  

- Forcing mistakes,  

- Weakening will.  


Even simple, improvised indirect fire systems can shape entire battles if used with:

- Planning,  

- Mobility,  

- Psychological intent.  


In collapse warfare,

the ability to project force beyond the line of sight is a critical advantage.

The Sentinel who masters indirect fire holds not just a weapon —

but control over time, space, and fear.


# Chapter XI: Sabotage, Urban Disruption, and Stealth Engineering

## Introduction: Precision Disruption Over Blind Destruction

In collapse warfare, brute destruction is rarely strategic.

Precision disruption — applied at the right time, against the right systems — has far greater effect.

Sabotage operations aim to:

- Delay enemy operations,  

- Strain enemy resources,  

- Collapse enemy morale,  

- Force strategic realignments without direct open confrontation.  


Stealth, timing, and minimal exposure are more valuable than raw force.

This chapter details how Sentinels identify, infiltrate, and disrupt critical systems to maximize battlefield advantage.

## Identifying Infrastructure Weak Points

All organized forces — even decentralized ones — depend on critical infrastructure.

Targeting these systems forces the enemy into reactive, inefficient behavior:

### Primary Categories of Targets:

- Power Systems  

	- Substations, transformers, overhead lines, fuel storage for generators.  

	- Disruption cripples communications, surveillance, and logistics.  

- Water Systems  

	- Wells, water towers, pumping stations, pipelines.  

	- Disruption causes health crises, limits mobility, and erodes morale.  

- Transport Networks  

	- Bridges, overpasses, tunnels, railways, shipping lanes.  

	- Disruption isolates enemy elements and slows resupply.  

- Communication Hubs  

	- Radio towers, satellite links, relay stations, fiber optics nodes.  

	- Disruption severs command\-and\-control cohesion.  


### Target Selection Considerations:

- Impact:  

	- Choose targets that create cascading disruption \(e.g., taking out a relay station that serves multiple districts\).  

- Visibility:  

	- Select whether to make disruption obvious \(morale weapon\) or subtle \(slow strangulation\).  

- Repair Difficulty:  

	- Prioritize targets that are slow or expensive to repair.  

- Collateral Risk:  

	- Minimize harm to civilian noncombatants unless absolutely necessary for strategic survival.  


Sentinel Field Principle:

Precision denies the enemy resources. Recklessness builds new enemies.

## Stealth Infiltration and Disguise Techniques

Silent infiltration is the core of sabotage operations.

### Movement Techniques:

- Slow, deliberate motion — noise discipline over speed.  

- Blend into background patterns: mimic local civilians, maintenance crews, security staff.  

- Avoid eye contact and unnatural movements.  


### Visual Camouflage:

- Neutral clothing blends better than tactical gear.  

- Carry tools or equipment appropriate for the disguise \(clipboards, toolboxes, security vests\).  


### Behavioral Camouflage:

- Act like you belong: purposeful walking, predictable posture, minimal attention\-drawing.  

- Carry light loads or documents to justify presence.  


### Entry Techniques:

- Bypass access points through social engineering when possible.  

- Physical breach only if absolutely necessary — prioritize minimal damage on entry.  


Sentinel Field Principle:

Invisible movement wins battles before the first charge is planted.

## Priority Target Selection and Operational Risk Management

Sabotage missions must be weighed carefully against risks:

### Target Prioritization Flow:

1. Impact Level:  

	- Will disruption seriously affect enemy logistics, morale, or operations?  

2. Risk to Operators:  

	- Can Sentinels infiltrate and exfiltrate with a reasonable chance of survival?  

3. Civilian Harm Assessment:  

	- Avoid actions that turn local populations against Sentinel forces.  

4. Redundancy Analysis:  

	- Ensure the target is not easily bypassed by backups.  

5. Timing Alignment:  

	- Ideally, disruption supports larger operations — assaults, retreats, psychological campaigns.  


If risk exceeds expected strategic value,

alternate targets should be selected.

Sentinel Field Principle:

Every mission must weigh cost against consequence — not in glory, but in survival.

## Glyph and Stealth Sigil Communication for Hidden Teams

Open communication in hostile territory is a liability.

Glyphwork and stealth sigils allow Sentinels to silently coordinate sabotage operations:

### Field Glyphs:

- Temporary marks placed on surfaces:  

	- Chalk, charcoal, mud, grease.  

- Coded symbols indicate:  

	- Entry points,  

	- Cleared paths,  

	- Danger areas,  

	- Target confirmed.  


### Stealth Sigils:

- Small, subtle modifications of the environment:  

	- Broken twigs at certain angles,  

	- Stone piles arranged in specific patterns,  

	- Scratched surfaces invisible to casual observers.  


### Glyph Discipline:

- Use minimally.  

- Remove or disrupt glyphs after mission success or abort.  

- Rotate code systems to prevent enemy learning.  


Field Examples:

- “X” slash over door frame = Entry compromised, avoid.  

- Triple stacked stones = Target verified, move at next phase.  

- Two crossed lines in dirt = Danger active, fallback route recommended.  


Sentinel Field Principle:

Words fail where marks endure.

# Conclusion: Targeted Disruption, Silent Survival

Sabotage operations are not about maximizing destruction.

They are about maximizing disruption while minimizing risk.

A properly executed operation:

- Forces the enemy into reactive spirals,  

- Weakens enemy morale and cohesion,  

- Buys time, resources, and positional advantage for Sentinel forces and their allies.  


Sabotage is war by precision, patience, and restraint —

and a core weapon in the arsenal of those who must fight many with few.

Handled correctly,

a single sabotage team can move more mountains than a thousand rifles.


# Part IV: Sustainment — The Forge That Endures


# Chapter XII: Combat Logistics and the War of Survival

## Introduction: Logistics as the Hidden Battlefield

Every war is a war of movement.

Every victory is a victory of endurance.

The most disciplined fighters fall without food, water, ammunition, and shelter.

The fastest\-moving units die without resupply.

The strongest wills falter when exhaustion and scarcity take hold.

Collapse warfare magnifies this reality:

- Traditional supply chains vanish.  

- Industrial manufacturing slows or stops.  

- Mobility becomes both more vital and more vulnerable.  


Sentinels must master the art of decentralized, resilient sustainment to survive and prevail.

## Tactical Sustainment Under Collapse Conditions

In collapse warfare:

- There are no reliable depots.  

- There are no guaranteed resupply convoys.  

- There is only what you bring, cache, trade, scavenge, or manufacture.  


Primary Sustainment Priorities:

1. Ammunition \(rifles, shotguns, specialty munitions\).  

2. Weapons and Parts \(repair kits, lubricants, spare critical parts\).  

3. Food and Water \(caloric density, portability, purity\).  

4. Medical Supplies \(trauma kits, field surgery tools, infection control\).  

5. Shelter and Clothing \(weather adaptation, concealment\).  

6. Power and Communications \(batteries, radios, signaling devices\).  


### Sustainment Core Principles:

- Durability over delicacy.  

- Multi\-use tools over specialized gadgets.  

- Portability over bulk stockpiling.  

- Repairability over disposable equipment.  


Sentinel Field Principle:

Survive first. Endure second. Dominate third.

## Balancing Stockpiling vs Mobility

Static stockpiles provide security and depth —

but mobility preserves life when static positions become targets.

The balance between the two defines long\-term survival:

### Stockpiling Strategies:

- Decentralized Caches:  

	- Small, hidden supply dumps distributed across broad areas.  

	- Ammunition, rations, medical gear, cold weather equipment sealed and buried or concealed.  

- Rotational Storage:  

	- Rotate supplies based on expiration dates, seasonal needs, and regional activity.  

	- Example: extra water purification gear cached near dry\-season routes.  

- Layered Redundancy:  

	- Never place all critical resources in one cache.  

	- Maintain at least three fallback positions per operating cell.  


### Mobility Sustainment:

- Pack Discipline:  

	- Carry only essential gear for mission profile and environment.  

	- Pre\-load packs for specific missions: reconnaissance, assault, sabotage, escape.  

- Vehicle Sustainment:  

	- Small, inconspicuous vehicles \(bikes, e\-bikes, ATVs\) prepped for fast movement and cache retrieval.  

	- Fuel and mechanical parts cached separately when possible.  

- Micro\-Resupply:  

	- Infiltration of abandoned facilities, scavenging missions, and allied trading networks to supplement supplies.  


### Resupply Mindset:

- Treat every day without resupply as a potential turning point.  

- Every successful scavenging or trade operation extends survival and influence.  


Sentinel Field Principle:

The loaded rifle is not enough. The loaded mind, the loaded hand, and the loaded pack win wars.

## Invisible Supply Chains and Distributed Resources

In collapse, visible supply chains become targets.

Thus Sentinels cultivate invisible logistics:

### Invisible Supply Chain Techniques:

- Hidden Movement:  

	- Supply transfers disguised as civilian traffic, farming operations, or migration patterns.  

- Disguised Storage:  

	- Weapons stored inside sealed agricultural bins, buried in abandoned wells, or camouflaged in false walls.  

- Rotational Custodianship:  

	- Supplies cared for by decentralized community allies rather than centralized depots.  

	- No single custodian holds enough to cripple operations if compromised.  

- Organic Production Cells:  

	- Black powder manufacture, basic ammunition reloading, field repair stations distributed across wide zones.  


### Distributed Resource Philosophy:

- No single cache, team, or facility is indispensable.  

- The loss of any one node slows operations — it does not collapse them.  

- Resilience is measured by ability to lose pieces and continue fighting.  


Sentinel Field Principle:

The spider’s web stretches across the ruins — and it does not break when one thread is cut.

# Conclusion: The War After the Battle

Logistics is not glamorous.

It does not fire bullets.

It does not breach doors.

It does not wave banners.

But it wins wars.

Collapse warfare will favor those who think three steps beyond the firefight:

- Where will you reload?  

- Where will you sleep?  

- Where will you heal?  

- How will you feed the next patrol?  


The battle is only the surface.

The war is fought underneath — in caches, in gardens, in hidden rooms, in silent trades.

The Sentinels who survive the first month are not the strongest or the most heavily armed.

They are the ones who understood:

- Mobility,  

- Supply,  

- Preservation.  


Those who sustain — endure.

Those who endure — protect the future.


# Chapter XIII: Healing the Warriors — Trauma Medicine and Field Care

## Introduction: The Fight After the Fight

Victory in battle is hollow if your wounded are left to die afterward.

Sustainment is not only about weapons and supplies —

it is about preserving human life under impossible conditions.

In collapse warfare:

- Hospitals may not exist.  

- Casualty evacuation may be delayed or impossible.  

- Life\-saving treatment must begin immediately — often with limited tools.  


Tactical medicine is not optional for Sentinels.

It is a foundational survival skill.

## Tactical Medicine: MARCH Protocols

The foundation of field trauma care is the MARCH sequence —

a prioritization method for treating life\-threatening injuries under fire.

### MARCH Overview:

1. Massive Hemorrhage  

	- Immediate control of life\-threatening bleeding using:  

		- Tourniquets \(commercial or improvised\),  

		- Direct pressure,  

		- Wound packing with hemostatic agents or cloth.  

2. Airway Management  

	- Ensure casualty can breathe:  

		- Position airway \(chin lift, jaw thrust\),  

		- Remove obstructions,  

		- Insert nasopharyngeal airway if trained and equipped.  

3. Respiration  

	- Identify and treat chest wounds:  

		- Apply chest seals to sucking chest wounds,  

		- Needle decompression if tension pneumothorax is suspected and responder is trained.  

4. Circulation  

	- Assess for shock:  

		- Elevate legs if no pelvic or spinal injury suspected,  

		- Keep warm,  

		- Begin fluid resuscitation if available and necessary.  

5. Head Injury / Hypothermia Prevention  

	- Protect from secondary injury,  

	- Cover with insulation or shelter against weather exposure,  

	- Monitor mental status and responsiveness.  


Principles of Tactical Field Care:

- Apply life\-saving interventions immediately — perfection is secondary to speed.  

- Casualties who can fight should continue fighting after self\-care.  

- Casualties unable to move must be secured and protected if evacuation is delayed.  


Sentinel Field Principle:

The fight to live is not separate from the fight to survive.

## Improvised Field Surgery and Recovery

When evacuation is impossible,

Sentinels must sometimes perform rudimentary field surgery to preserve life.

Field Surgery Priorities:

- Control major bleeding.  

- Prevent infection.  

- Remove major impalements if absolutely necessary.  

- Stabilize fractures or major wounds for movement.  


### Improvised Surgical Tools and Materials:

- Sterilized blades \(heated over fire, alcohol wash\).  

- Suture kits \(commercial or improvised with fishing line or heavy thread\).  

- Antiseptics \(iodine, alcohol, honey if nothing else\).  

- Clean cloth or plastic wrap for wound covering.  


### Recovery Field Notes:

- Hydration and nutrition are critical to healing.  

- Prevent movement of injured areas if possible.  

- Rotate guards and caretakers to prevent fatigue.  

- Monitor for infection signs: redness, swelling, fever.  


Field Principle:

Stopping the bleeding is only the first battle. Healing the body is the war that follows.

## Extraction and Evacuation Under Fire

Casualty extraction is often the most dangerous phase —

where speed, cover, and teamwork are crucial.

### Extraction Techniques:

- One\-Person Drag:  

	- Grab casualty under arms, pull low to the ground.  

	- Use webbing, belts, or makeshift drag lines if possible.  

- Two\-Person Carry:  

	- Each rescuer under one arm; fastest method if mobility allows.  

- Litter Construction:  

	- Blankets, ponchos, or jackets tied between poles or strong branches.  

- Use Terrain:  

	- Drag casualties downhill when possible.  

	- Use smoke, suppressive fire, or deception to cover extraction.  


Prioritize Extractions:

- First: Casualties who can move with assistance.  

- Second: Unresponsive but salvageable casualties.  

- Last: Confirmed dead \(only recover if it does not endanger the living\).  


Sentinel Field Principle:

Saving the wounded is an act of survival — not sentiment alone.

## Psychological Recovery and Long\-Term Morale

Physical wounds heal.

Psychological wounds can fester unseen if untreated.

Collapse conditions will expose Sentinels to:

- Violence against innocents,  

- Loss of comrades,  

- Isolation,  

- Long periods of fear and hardship.  


Maintaining psychological resilience is critical for:

- Unit cohesion,  

- Mission endurance,  

- Personal survival beyond the battlefield.  


### Psychological Recovery Techniques:

- After\-Action Debriefs:  

	- Create space to talk about what happened — facts first, emotions afterward.  

- Ritualized Memorial Practices:  

	- Silent acknowledgments, carved stones, fire rituals, or journal entries to honor the fallen.  

- Routine Maintenance:  

	- Sleep discipline, nutritional care, controlled work\-rest cycles.  

- Peer Monitoring:  

	- Sentinels watch each other for signs of burnout, depression, or reckless behavior.  


Signs of Psychological Degradation:

- Withdrawal from group,  

- Reckless or fatalistic behavior,  

- Neglect of personal hygiene or equipment,  

- Refusal to plan for the future.  


Early intervention — even if only peer\-based — can prevent total collapse of individuals and teams.

Sentinel Field Principle:

Strong minds carry weak bodies. Weak minds kill strong bodies.

# Conclusion: Healing as Strategic Warfare

Healing is not weakness.

Healing is survival.

The armies that last are not the ones that kill the most.

They are the ones who protect their wounded, strengthen their survivors, and return to the field wiser, not broken.

Field medicine is a weapon —

not of destruction,

but of endurance.

And in the wars of collapse,

endurance wins more battles than bullets alone.


# Chapter XIV: Feeding the Flame — Food Logistics, Nutrition, and Survival Cooking

## Introduction: Food as Fuel for Endurance

In warfare, food is not a luxury.

It is not entertainment.

It is not comfort.

It is fuel for movement, clarity, strength, and survival.

Collapse warfare will destroy industrial food supply chains.

Supermarkets, mass agriculture, and refrigeration will degrade or vanish.

The Sentinels who endure will be those who understand:

- Nutrition is tactical.  

- Food is strategic mobility.  

- Supply discipline is survival itself.  


Natural, whole foods — as fresh, wild, and nutrient\-dense as possible — must form the core of Sentinel nutritional doctrine.

## Traditional Combat Foods: Proven Through Time

History offers proven answers for combat endurance diets:

### Pemmican

- Ingredients:  

	- Dried lean meat \(jerky\),  

	- Rendered fat \(tallow\),  

	- Dried berries \(optional for vitamins\).  

- Properties:  

	- High caloric density,  

	- Long shelf life \(months to years if sealed properly\),  

	- Lightweight, compact.  

- Usage:  

	- Consumed in small portions throughout the day,  

	- Best combined with water intake to prevent digestive issues.  


Field Principle:

Pemmican is the original combat ration — it endures longer than any machine.

### Jerky

- Ingredients:  

	- Thin\-sliced lean meat \(beef, venison, fish\),  

	- Salted and dried.  

- Properties:  

	- Moderate shelf life,  

	- High protein with low moisture,  

	- Easy to make in field drying racks or low\-temperature fires.  

- Usage:  

	- Snack fuel on patrols,  

	- Rehydrated into stews and broths.  


### Bone Broth

- Ingredients:  

	- Animal bones \(wild game, livestock\),  

	- Water, salt, optional herbs.  

- Properties:  

	- Rich in minerals, collagen, amino acids,  

	- Restorative for injury recovery and exhaustion.  

- Usage:  

	- Base for soups,  

	- Hydration support,  

	- Immune system support in harsh conditions.  


### Trail Meals

- Construction:  

	- Dried beans, rice, oats,  

	- Nuts and seeds,  

	- Dried fruits.  

- Properties:  

	- Balanced macro\-nutrients,  

	- Long\-term storage,  

	- Simple to prepare in field conditions \(boil or soak\).  


Field Principle:

Your body is the rifle. Feed it as you would maintain your weapon — carefully and intentionally.

## Survival Gardening and Seasonal Harvest Strategies

In prolonged conflict, hunting alone will not sustain enclaves.

Survival gardens and wild harvesting must supplement diets:

### Tactical Gardening:

- Crop Selection:  

	- High\-yield, fast\-maturing staples: potatoes, beans, corn, squash.  

	- Hardy greens: kale, chard, wild lettuces.  

	- Medicinal plants: garlic, yarrow, comfrey.  

- Methods:  

	- Decentralized micro\-plots to avoid detection.  

	- Companion planting for pest control and nutrient preservation.  

	- Heirloom seeds preferred for seed\-saving resilience.  

- Security:  

	- Hide gardens in broken terrain, abandoned lots, or natural clearings.  

	- Avoid conspicuous cultivation patterns.  


### Seasonal Wild Harvesting:

- Spring: greens, early berries, edible shoots.  

- Summer: fruits, tubers, mature seeds.  

- Autumn: nuts, root vegetables, late fruits.  

- Winter: stored roots, ice fishing, trapping.  


Sentinel Field Principle:

The land feeds the patient — not the desperate.

## Tactical Field Cooking Systems

Efficient food preparation without revealing position is crucial.

### Field Cooking Methods:

- Dakota Fire Holes:  

	- Sub\-surface firepits with air intake tunnels.  

	- Minimize smoke signature and thermal detection.  

- Rocket Stoves:  

	- Small, efficient combustion units built from cans or clay.  

	- High heat, low visibility.  

- Solar Dehydrators:  

	- Dry fruits, vegetables, and meats without fire.  

	- Essential for long\-term storage without energy expenditure.  

- Field Ovens:  

	- Clay or stone enclosures for baking flatbreads, roasting meats.  


Field Cooking Discipline:

- Cook at dawn or dusk to reduce smoke detection risk.  

- Rotate fire locations if operating in hostile territory.  

- Bury or scatter food waste to avoid attracting predators or enemies.  


## Black Market and Barter Survival Strategies

In collapse environments, informal trade networks often replace formal economies.

### Black Market Survival Principles:

- Tradeable Foods:  

	- Dried meat,  

	- Hard cheeses,  

	- Fermented vegetables,  

	- Honey, alcohol \(if safely produced\).  

- Barter Dynamics:  

	- Food is more valuable than gold in scarcity.  

	- Never display entire stocks during trade.  

	- Establish trusted networks gradually through small exchanges.  

- Security Concerns:  

	- Always assume trade could become robbery.  

	- Conduct trades in secure or controlled environments.  

	- Vet all trading partners through observation and intelligence gathering.  


Sentinel Field Principle:

The harvest feeds the rifle. The rifle guards the harvest.

# Conclusion: Feeding the Flame

Weapons may decide battles.

But nutrition, endurance, and discipline decide wars.

Sentinels who understand how to:

- Harvest wild resources,  

- Store food for seasons,  

- Prepare meals with minimal signatures,  

- Trade carefully in collapse environments —  


are the ones who will outlast not just battles — but generations.

In the wars ahead,

the belly must be as ready as the rifle.

The mind must be as patient as the garden.

The fire must burn slow, but it must burn steady.

This is the way the flame endures.


# Chapter XV: Ammunition Management and Weapon Sustainment

## Introduction: Bullets as Blood

In collapse warfare, every cartridge becomes sacred.

Every shot must be weighed.

Weapons without ammunition are just deadweight.

Ammunition management is life management — it is the bloodstream of armed survival.

The Sentinels who endure will not be those who shoot the most,

but those who shoot wisely, repair what they have, and produce when supply lines break.

This chapter outlines the disciplined principles of ammunition sustainment in a collapsing world.

## Caliber Realities and Regional Adaptations

When collapse fractures centralized supply,

regional factors will determine available calibers.

### Common North American Calibers \(by Likelihood of Survival\):

- 5.56 NATO / .223 Remington — military and civilian commonality.  

- 7.62x39mm — imported AK platforms, heavy use in rural areas.  

- .308 Winchester / 7.62 NATO — hunting rifles, designated marksman rifles.  

- 9mm Luger — dominant civilian handgun caliber.  

- .22 Long Rifle — small game, training, discreet operations.  

- 12 Gauge — shotguns for breaching, hunting, close combat.  

- .45 ACP / .40 S&W — legacy law enforcement and civilian sidearms.  


### Regional Factors:

- Urban Zones:  

	- 9mm, 5.56, 12 gauge dominate due to population density and law enforcement surplus.  

- Rural/Mountainous Areas:  

	- .308, 30\-06, .30\-30, and 12 gauge more common from hunting stockpiles.  

- Border Territories:  

	- 7.62x39mm, 5.45x39mm, 9mm due to imported platforms.  


Sentinel Field Principle:

You fight with what the land provides — not what the manuals prefer.

## Field Reloading, Powder Craft, and DIY Ammunition

When industrial resupply collapses,

Sentinels must reclaim and reproduce ammunition wherever possible.

### Field Reloading Basics:

- Brass Collection:  

	- Priority during all operations — every casing is potential future firepower.  

- Essential Tools:  

	- Hand\-press reloaders, salvaged dies, powder scales, priming tools.  

- Components for Reloading:  

	- Brass casings \(salvaged or reformed\),  

	- Primers \(commercial stock or improvised fallback\),  

	- Powder \(commercial, salvaged, or black powder substitutes\),  

	- Bullets \(cast lead, scavenged projectiles, or reformed jacketed rounds\).  


### Black Powder Fallback:

- Ingredients:  

	- Potassium nitrate \(scavenged from old fertilizers or bat guano\),  

	- Charcoal \(from hardwoods\),  

	- Sulfur \(mined or chemical sources\).  

- Uses:  

	- Muzzleloaders,  

	- Improvised smoothbore firearms,  

	- Pipe mortars,  

	- Signal devices.  


Tactical Note:

- Black powder weapons sacrifice range and precision,  

- They provide strategic continuity when all else fails.  


### DIY Ammunition and Adaptation:

- Slugs cast from scrap lead for shotguns.  

- Homemade percussion caps using chemical matches or adapted primer compounds.  

- Reloaded 12 gauge shells using salvaged wadding and improvised shot.  


Caution:

- Improvised loads are inherently risky; strict testing and discipline are mandatory.  


Sentinel Field Principle:

Every casing saved is a future life spared.

## Community Ammo Pools and Rotational Logistics

Ammunition is too critical to be managed individually over time.

Community\-level management ensures long\-term survival.

### Community Ammo Pools:

- Distributed Stockpiles:  

	- Ammunition divided among trusted cells, families, and secure caches.  

- Caliber Standardization:  

	- Enclaves should standardize primary fighting calibers to:  

		- Streamline resupply,  

		- Enable weapon and magazine sharing,  

		- Ease repair logistics.  

- Ammo Rotation Cycles:  

	- Oldest stockpiles fired first during training or engagements.  

	- Fresh production cached in hidden reserve.  


### Logistical Redundancy:

- No single cache critical to survival.  

- No single operator holds all of a cell’s ammunition.  

- Movement of ammo between caches conducted by decentralized, low\-profile runners.  


Tactical Security Principles:

- No public records.  

- No obvious central arsenals.  

- Distribute knowledge of cache locations only on a need\-to\-know basis.  


### Training Discipline:

- Dry fire training maximized to reduce live fire consumption.  

- Training ammunition \(reduced loads, imperfect rounds\) separated from combat\-ready stock.  


Sentinel Field Principle:

The community that manages bullets like blood survives longer than the army that wastes them like water.

# Conclusion: Weapons Are Alive Only with Ammunition

The rifle is silent without a cartridge.

The Sentinel is weakened when careless with firepower.

In collapse warfare:

- Ammunition must be treated as precious,  

- Weapons must be maintained like living extensions of the self,  

- Communities must be organized to preserve, produce, and deploy firepower for the long war.  


Those who waste ammunition die first.

Those who hoard without firing die next.

Those who preserve, train, and renew —

become the hammer that endures generations.


# Chapter XVI: Improvised Armory and Fractal Forge Craftsmanship

## Introduction: The Warrior as Maker

Collapse shatters mass production.

Factories crumble. Supply lines rot.

Precision machines wear down.

But the Sentinel endures —

because the forge of survival never closes.

Those who can repair, rebuild, or reforge weapons under collapse conditions will wield power far greater than armies chasing the last crates of factory ammunition.

This chapter guides the principles and practices of field armory work —

the sacred survival craft of maintaining, adapting, and building the tools needed for the wars ahead.

## Makeshift Suppressors, Field Optics, and Weapon Conversions

In collapse warfare, modification is not vanity — it is survival engineering.

### Makeshift Suppressors:

- Oil Filter Adapters:  

	- Threaded adapters allow disposable oil filters to serve as effective suppressors for limited\-use missions.  

	- Useful for hunting, discrete ambushes, or evasion scenarios.  

- PVC and Metal Tube Designs:  

	- Simple baffle structures fabricated from metal spacers and tubing.  

	- Workable for pistol calibers, but require extreme caution for durability.  


Notes:

- Improvised suppressors have limited lifespan.  

- Always test under controlled conditions.  

- Legal risks in peacetime environments — only practical post\-collapse or active conflict.  


### Field Optics Improvisation:

- Scavenged Optics:  

	- Re\-purpose old scopes from hunting rifles, broken military optics.  

	- Modify mounts using hose clamps, cut steel, JB Weld, or handmade brackets.  

- Red Dot Fabrication:  

	- Glass prisms and painted reticles can simulate simple aiming devices if electronics fail.  

- Iron Sight Refinement:  

	- Maintain and improve battle rifle iron sights as baseline systems for when optics fail.  


Field Principle:

Precision is not bought — it is built.

### Weapon Conversions:

- Shotgun Slug Rifles:  

	- Rifled choke tubes or barrel sleeve inserts allow pump shotguns to double as short\-range rifled slug guns.  

- Hand\-Conversions:  

	- Cut\-down rifles, modified carbines, and hybrid receivers adapted for scavenged ammunition or specific mission profiles.  

- Multi\-Caliber Adaptations:  

	- Custom\-chambered barrels, insert sleeves, or hybrid actions allow multi\-caliber survival weaponry when standard ammunition is unavailable.  


Tactical Note:

- Every conversion reduces long\-term mechanical lifespan — applied only when operational advantage outweighs risk.  


## Barrel Forging, Stock Fabrication, and Emergency Repairs

When supply chains vanish,

Sentinels must become weapon keepers, not just weapon users.

### Barrel Work in Collapse Conditions:

- Field Straightening:  

	- Carefully heating slightly bent barrels over flame, using weighted jigs and slow correction.  

- Rough Barrel Forging:  

	- Using salvaged steel pipe stock with careful bore honing for low\-pressure black powder firearms \(fallback muzzleloaders, smoothbores\).  

- Fire Lapping and Polishing:  

	- Using abrasive slurries and soft lead slugs to smooth imperfect bores for survival\-grade accuracy improvements.  


### Stock Fabrication:

- Woods Used:  

	- Hickory, walnut, maple, or salvaged treated hardwoods.  

- Tools Needed:  

	- Hatchets, draw knives, files, sanding stones, wood glue or lashings.  

- Fitting Process:  

	- Hand\-fitting action groups into fresh wood beds.  

	- Reinforcing fracture\-prone areas with wire wraps or metal bands.  


### Emergency Repairs:

- Bolt Replacements:  

	- Hand\-forged firing pins or reformed nails as emergency solutions.  

- Gas Block and Tube Repairs:  

	- Simple tube metal patching for broken gas systems in semi\-automatics.  

- Trigger Group Work:  

	- Bypass or field\-fix broken springs using watch springs, scavenged steel wire.  


Sentinel Field Principle:

If you can repair it — you command time itself.

## Sentinel Smithing Philosophy: Story\-bound Weapons and Legacy Tools

Sentinel weaponry is not just mechanical.

It is memory carried forward through action.

Every rifle repaired, every blade reforged, every optic patched becomes a living archive of struggle, survival, and brotherhood.

### The Fractal Forge Concept:

- Weapons evolve — modified, repaired, re\-barreled, re\-birthed across battles and generations.  

- Gear is living — not preserved in pristine showroom condition, but adapted, scarred, improved.  


Every scratch, every field weld, every replacement stock tells a story:

- Of patrols at dawn,  

- Of stand\-offs in broken towns,  

- Of silent camps deep in the mountains,  

- Of lost friends honored in the care of the tools they carried.  


### Legacy Tools:

Some weapons will survive so many battles that they become more than steel and wood.

They become:

- Heirlooms of enclaves,  

- Symbols of stubborn resistance,  

- Silent companions passed to future Sentinels yet to be forged.  


Such legacy weapons are maintained with care:

- Regular cleaning and inspections,  

- Minor cosmetic repairs left visible as living memory,  

- Stories attached to usage — told orally or carved into grips, receivers, scabbards.  


Sentinel Field Principle:

A rifle is not just a tool. It is the flame carried through storms.

# Conclusion: Makers Forge the Future

In collapse warfare:

- He who can fix wins.  

- He who can adapt survives.  

- He who can craft and maintain becomes the father of future warriors.  


Factory production will collapse.

Artisan survival will rise.

The Sentinel who hammers metal, fits stocks, sights weapons, and breathes life back into damaged tools —

is the same Sentinel who protects the Green Fire when no other structure stands.

Where factories fall silent —

the forge of survival will still ring.


# Chapter XVII: Field Engineering and Green Fire Fortifications

## Introduction: The Ground Itself as a Weapon

Fortifications are not walls for cowards.

They are survival engines — carefully shaped to:

- Slow enemies,  

- Funnel movement,  

- Shelter the defenders,  

- Turn the land itself into a weapon.  


In collapse warfare, heavy machinery may be scarce or absent.

The Sentinels must return to first principles: shaping the earth, weaving obstacles, blending shelter into terrain.

This chapter lays the foundation for practical, concealed, adaptive field fortifications — built not for comfort, but for survival and endurance.

## Concealment\-Based Defensive Construction

In the collapse environment, overt fortresses are beacons for destruction.

Concealment is the first layer of defense.

### Principles of Concealment\-Focused Engineering:

- Low Profile:  

	- Bunkers built below ground level, roofs flush with natural contours.  

	- No hard edges visible from aerial or long\-range observation.  

- Material Matching:  

	- Cover structures with local vegetation, loose stone, moss, and natural debris.  

	- Blend camouflage into the surrounding biome, not just lay it over.  

- Minimal Signature:  

	- No visible spoil piles from digging — remove excavated soil offsite or disguise it.  

	- Use vented fire pits or Dakota fire holes for low\-smoke cooking and warmth.  

- Silent Construction:  

	- Build slowly over time.  

	- Prioritize hand tools \(shovels, mattocks, sledges\) over power tools to avoid noise signatures.  


### Bunker Basics:

- Depth:  

	- Minimum 18–24 inches of overhead cover \(more if using sand, rock, or timber\).  

- Overhead Layers:  

	- Stone, sandbags, logs, earth — layered for ballistic protection.  

- Drainage:  

	- Slight slope to floors.  

	- Gravel sumps or weep holes to prevent flooding.  

- Escape Routes:  

	- Concealed rear exits or emergency tunnel bolt\-holes mandatory for all semi\-permanent positions.  


Sentinel Field Principle:

The best bunker is the one they never find.

## Dynamic Layered Fortification Systems

Fortifications must not be static.

Layered defenses create survival ecosystems rather than simple strongpoints.

### Primary Defensive Layers:

1. Early Warning Zone:  

	- Scouts, observation posts, silent alarm traps \(tripwires, rockfall markers, tension lines\).  

2. Disruption Zone:  

	- Obstacles to slow, split, or funnel attackers:  

		- Felled trees,  

		- Hidden pits,  

		- Spike fields \(stakes embedded at angles\).  

3. Fighting Positions:  

	- Covered fire points embedded into hillsides, stone walls, thick tree clusters.  

	- Clear, overlapping fields of fire.  

4. Final Shelter:  

	- Bunkers, dugouts, reinforced positions for last\-ditch stand or fallback regrouping.  


### Adaptive Fortification Philosophy:

- Flexibility:  

	- Every layer must allow for flexible withdrawal or reinforcement.  

- Fall\-Back Pathways:  

	- Safe corridors for defenders to retreat and regroup without exposing themselves.  

- Environmental Shaping:  

	- Design defenses to shift with seasons — snow drifts, flood plains, leaf fall, and mud seasons should enhance, not hinder, defenses.  


Sentinel Field Principle:

Fortifications are not prisons. They are breathing organisms: they flex, constrict, and survive.

## Weaving Tactical Obstacles, Natural Terrain, and Seasonal Defense

### Tactical Obstacles:

- Deadfalls:  

	- Weighted logs or stones triggered by tripwires or pressure plates.  

- Punji Pits:  

	- Hidden stake\-filled pits to injure or slow intruders \(careful use — ethics and targeting matter\).  

- Barbed Entanglements:  

	- Salvaged fencing wire strung low between trees, overgrown with vegetation to conceal.  

- Vehicle Traps:  

	- Hidden trenches, buried spike strips, oil traps \(slicks to disable tires\).  


### Natural Terrain as a Force Multiplier:

- Swamps and Marshes:  

	- Redirect enemy movement into bogs or soft ground.  

- Rocky Outcrops:  

	- Build camouflaged firepoints into cliff faces or stone ridges.  

- Forest Density:  

	- Create illusion of open trails leading into ambush sites or false clearings.  

- Waterways:  

	- Manipulate streams, creeks, or ice flows to obscure approach or force choke points.  


### Seasonal Adaptation:

- Winter:  

	- Snow walls reinforced with ice layers for bullet\-resistant barriers.  

	- Frozen trenches cut and concealed under snowpack.  

- Spring:  

	- Flooded ground zones used to isolate access routes.  

- Summer:  

	- Heavy foliage used for total canopy concealment.  

- Autumn:  

	- Fallen leaves packed into berms for thermal insulation of shelters.  


Sentinel Field Principle:

The land is the first and last defender — if you learn to speak its language.

# Conclusion: The Living Fortress

Fortifications are not monuments to fear.

They are not symbols of defeat.

They are tools for survival, endurance, and future rebuilding.

A well\-designed field position:

- Lives with the land, not against it.  

- Shifts with the seasons, not against them.  

- Shields the flame of survival through the long winters of collapse.  


The Sentinel learns:

- Not to defy the earth,  

- Not to enslave it,  

- But to listen, weave, and fight alongside it.  


In doing so,

the fortress becomes a living memory — not just of survival, but of future generations yet to be forged.


# Chapter XVIII: Enclave Logistics and Generational Stewardship

## Introduction: Survival is an Ecosystem, Not a Weapon

Collapse war is not won by bullets alone.

It is not sustained by the rifle, nor even by the sword.

Collapse war is won by ecosystems — living, breathing communities — hardened to hardship, trained to endurance, and bound by purpose.

The future belongs not to the strongest shooters —

but to the enclaves who master how to live, heal, farm, fix, trade, and teach while fighting with discipline and clarity.

This chapter lays out the full structure required for true Sentinel survival and stewardship across generations.

## The Full Circle of Survival: Roles Beyond Warriors

A surviving enclave must become a living body —

where every person is a vital organ in its survival.

### Essential Roles for Long\-Term Survival:

### Combat Roles:

- Riflemen and Marksmen:  

	- Core defense and offensive capability.  

- Breachers and Demolitionists:  

	- Overcome fortified obstacles, sabotage enemy supplies.  

- Scouts and Pathfinders:  

	- Reconnaissance, early warning, terrain navigation.  

- Medics and Trauma Specialists:  

	- Immediate casualty care, long\-term recovery support.  


### Engineering and Technical Roles:

- Gunsmiths and Armorers:  

	- Maintain, repair, and adapt weaponry across generations.  

- Field Engineers:  

	- Build fortifications, trenches, field shelters, hidden camps.  

- Explosives Artisans:  

	- Powder making, improvised munitions crafting.  

- Transportation Mechanics:  

	- Maintain bikes, e\-bikes, boats, scavenged vehicles for logistics and mobility.  

- Signal Operators and Field Communicators:  

	- Maintain radios, encryption, stealth signaling systems.  


### Agriculture and Resource Roles:

- Farmers and Herders:  

	- Grow food crops, preserve seeds, raise hardy livestock.  

- Foragers and Hunters:  

	- Supplement food stocks with wild harvests and game.  

- Gardening and Herbal Medicine Experts:  

	- Cultivate not just food, but healing plants, fiber crops, and medicinal trees.  


### Craftsmanship and Fabrication Roles:

- Clothiers and Gear Menders:  

	- Sew, repair, and fabricate field gear, boots, packs, slings.  

- Toolmakers and Field Smiths:  

	- Produce and maintain hand tools, trapping gear, improvised mechanical parts.  

- Builders and Carpenters:  

	- Shelter construction, bridge repair, siege crafting.  


### Knowledge and Cultural Roles:

- Teachers and Lorekeepers:  

	- Pass down survival skills, tactical doctrine, cultural memory.  

- Archivists and Scribes:  

	- Record knowledge in durable formats — clay tablets, metal engraving, preserved books.  

- Ritual Keepers and Story Weavers:  

	- Maintain morale, unity, and collective identity through story, song, glyph, and fire ceremony.  


Sentinel Field Principle:

An army without farmers, menders, teachers, and healers is already a dead army.

## Hidden Armories and Rotational Caches

Survival depends on distributed supply systems, invisible to enemies but reliable for future warriors.

### Best Practices for Cache Systems:

- Small, Secure, Dispersed:  

	- No large depots vulnerable to total loss.  

	- Small arms, tools, and critical supplies spread across wide territory.  

- Rotational Maintenance:  

	- Each cache checked and refreshed on an annual seasonal cycle.  

- Skill Memory Built Into Storage:  

	- Simple manuals or engraved guides hidden with caches to teach repair and use \(e.g., basic gunsmithing primers, seed\-saving guides, trap diagrams\).  

- Cache Camouflage:  

	- Stored under fallen trees, submerged in water\-sealed containers, hidden inside ruined structures.  


Cache Composition Examples:

- Primary fighting arms and magazines.  

- Garden seeds and soil supplements.  

- Field repair kits: sewing, soldering, lockpicking.  

- Dehydrated food and water purification tools.  

- First aid and trauma kits.  


Sentinel Field Principle:

If you can disappear your supplies, you can survive any siege.

## Barter Economies and Tactical Trade Networks

A lone enclave will eventually perish without contact and trade.

### Trade Network Principles:

- Trusted Node Networks:  

	- Small enclaves linked by vetted runners and couriers.  

- Commodity Focus:  

	- Weapons, medicine, seeds, food, tools, textile fiber, mechanical parts — not luxuries.  

- Mutual Defense Agreements:  

	- Trade agreements often sealed with combined defensive pacts.  

- Silent Commerce:  

	- Dead drops, coded glyph signs, ceremonial exchange rituals.  


Items of High Collapse Value:

- Reloading supplies \(primers, powder, brass\),  

- Preserved combat foods \(pemmican, jerky\),  

- Simple weapons \(bows, crossbows, black powder arms\),  

- Durable clothing and repair kits,  

- Solar panels, batteries, charging circuits.  


Sentinel Trade Wisdom:

Trade as if every buyer could be your executioner — but build trust as if the next generation depends on it.

## Building Living, Self\-Sustaining Combat Communities

### Key Pillars of Survival:

- Skill Cross\-Training:  

	- Every fighter learns farming.  

	- Every medic learns marksmanship.  

	- Every farmer learns basic field repair.  

	- Every child learns survival skills before reading.  

- Resilient Redundancy:  

	- No single leader, no single location, no single craftsman becomes critical.  

- Distributed Leadership:  

	- Leadership is earned by discipline, honor, skill —  
  
 not birth, appointment, or self\-importance.  

- Cultural Resilience:  

	- Songs, glyphs, rituals, and stories that outlive broken radios and burned archives.  


### Generational Stewardship Practices:

- Legacy Weapons:  

	- Maintain and record histories of tools passed down through battles.  

- Community Smithies:  

	- Forge local metalwork, tool repair, and weapon maintenance in every major enclave.  

- Training Camps:  

	- Children raised with seasonal survival drills, combat fieldcraft, and tactical games.  

- Rotational Farming Teams:  

	- Food security through moving garden squads and seed\-sharing rituals.  


# Conclusion: Communities That Can Endure

An army fights.

A community endures.

The future belongs to those who can plant crops, forge steel, heal wounds, and teach their sons and daughters not just to survive — but to live honorably.

Collapse is not death.

It is the clearing of the field —

for new gardens, new forges, new flame\-bearers.

Sentinels do not carry only rifles.

They carry the seeds of survival, rebirth, and freedom.

This is the stewardship of the Armory.

This is how the flame is passed — not by words —

but by life built with patient, bloody hands.


# Chapter XIX: Field Spirit, Warrior Traditions, and the Culture of Endurance

## Introduction: Why We Endure

Weapons rust.

Armories burn.

Even victories fade in the fog of forgotten wars.

But the spirit of the warriors —

their stories, their rites, their remembered fires —

can survive collapse, famine, exile, and even death itself.

This final chapter honors the unseen armor that binds Sentinels across generations:

the Field Spirit — the Culture of Endurance — the unbroken memory passed hand to hand, breath to breath, fire to fire.

## Living Memorials and Rituals of the Forge

Victory is hollow if the fallen are forgotten.

Survival is bitter if purpose is lost.

Thus, the Sentinels keep living memorials —

traditions, rites, and forges of remembrance that honor the sacrifices made to preserve the Green Fire.

### Memorial Practices:

- Forge Stones:  

	- Fallen warriors have their names, glyphs, or deeds engraved into stones placed in sacred fires or hidden cairns.  

- Weapon Rituals:  

	- Weapons carried by fallen Sentinels are reforged, repaired, or passed down.  

	- Minor scars or marks preserved, not polished away.  

- Ceremonial Fire Circles:  

	- Small, quiet gatherings where stories of the fallen are spoken aloud.  

	- Not glorification — remembrance through fact, honor, and humility.  


### Forging Rituals:

- Naming Weapons:  

	- Major reforged arms \(crafted under hardship, born of battle\) may be named after fallen warriors or key events.  

- Forge Circles:  

	- Community events where new tools are crafted collectively, blessing both the tool and the work that follows.  

- Trial Forges:  

	- Young Sentinels forge or repair their first weapon or tool as a rite of passage into adulthood and responsibility.  


Sentinel Field Principle:

The hand that fights must also remember. The heart that survives must also forge.

## Warrior Guilds, Lodges, and Fire Circles

Isolation kills communities.

Loneliness kills warriors.

Thus, even among hardship, Sentinels form brotherhoods and sisterhoods of spirit —

guilds, lodges, and fire circles dedicated to skills, stewardship, and the survival of purpose.

### Guilds and Lodges:

- Role\-Specific Guilds:  

	- Guilds for blacksmiths, gunsmiths, healers, teachers, farmers, scouts.  

- Cross\-Enclave Brotherhoods:  

	- Warrior lodges spanning enclaves — a loose alliance built on ritual trust, shared history, and oaths of mutual defense.  

- Initiatory Trials:  

	- Entrance into lodges based on feats of endurance, service, or demonstrated loyalty — not birth or charisma.  


### Fire Circles:

- Seasonal Gatherings:  

	- Winter fires to recount battles survived, summer fires to bless coming harvests.  

- Oath Renewal Ceremonies:  

	- Reaffirming each warrior’s commitment to the Green Fire — to protect, to endure, to carry wisdom forward.  

- Cross\-Training Events:  

	- Trade skills between enclaves through friendly competitions: marksmanship, blacksmithing, herbalism, fieldcraft.  


Sentinel Field Principle:

We are not only kept alive by blood and steel — but by the fires we tend together.

## Glyphwork, Oral Histories, and Cultural Archives

Collapse destroys written records.

Libraries burn. Servers die.

Memory must live in the mind, in the voice, in the stone, and in the hand.

### Glyphwork:

- Runes and Symbols:  

	- Used to mark caches, sacred sites, battlefields, memorials.  

	- Serve as mnemonic anchors for stories and lessons.  

- Glyphbooks:  

	- Portable, durable codices of glyphs etched into leather, stone, or wood.  

- Dynamic Story Glyphs:  

	- Carvings that tell entire histories in compact visual language, to survive even if language shifts or fragments.  


### Oral Histories:

- Storyteller Roles:  

	- Selected members of enclaves responsible for memorizing key histories, battle accounts, and wisdom tales.  

- Memory Chains:  

	- Structured oral repetitions through lodges to reinforce long\-term recall \(songs, chants, ritual retellings\).  

- Embedded Lessons:  

	- Survival tactics, medical knowledge, and engineering principles woven into parables and legends.  


### Cultural Archives:

- Multi\-Media Preservation:  

	- If technology survives: encrypted data crystals, portable solar devices, ruggedized tablets hidden in caches.  

- Analog Preservation:  

	- Handwritten codices, maps, journals hidden in waterproof containers.  

	- Carved tablets and stone archives for permanent memory.  


Sentinel Field Principle:

When paper burns and voices fail, stone and spirit must remember.

## Sentinels and the Stewardship of Memory

Survival is not enough.

Survival must have meaning.

The Sentinels are not merely fighters. They are stewards.

They carry:

- The memory of free fields,  

- The names of the fallen,  

- The wisdom of battles,  

- The seeds of new gardens.  


### Stewardship Duties:

- Protect the young — train the next flame\-bearers.  

- Preserve the tools — teach the use and care of weapons and seeds alike.  

- Pass on the spirit — not only tactics and lore, but the honor, clarity, and discipline that made them possible.  


Final Sentinel Principle:

You are not the end.

You are the bridge.

You are the shield for what must be remembered.

You are the sword for what must be defended.

You are the fire for what must be rebuilt.

# Conclusion: The Eternal Flame

Weapons rust.

Memories fade.

Even empires fall.

But the Green Fire survives —

not because it was the strongest,

but because it was carried by those who remembered.

You, Sentinel, are the carrier of that flame.

Not merely a fighter.

Not merely a survivor.

But a steward. A builder. A memory keeper. A forger of futures.

Carry it well.

Carry it with honor.

Carry it forward.

᛬ᛃᛋ


# Final Words: The Legacy of the Armory

## The Codex is Never Complete

This Armory —

these words, these principles, these tactics —

are not a monument.

They are a beginning.

They are a forge left burning for those yet to come.

Every battle fought,

every weapon repaired,

every field planted after a firefight,

adds new pages to this Codex.

It will never be finished.

Because true survival, true endurance, true honor —

are living fires, not finished statues.

The Codex will change.

It will evolve.

It will carry new scars, new glyphs, new wisdom written in blood and hope.

It must.

Because the world itself is never finished —

and neither is the fight to protect what matters.

## The Impact Outlives the Weapon

A rifle can be broken.

A blade can be dulled.

A bunker can be shattered.

But the will that wielded them —

the discipline, the clarity, the spirit —

outlives every tool.

It passes through memory, through story, through the quiet rebuilding after the storm.

The true weapon is not steel.

The true weapon is not gunpowder.

The true weapon is the spirit that says:

“I will endure. I will protect. I will build again.”

What you carry inside you —

your discipline, your honor, your memory —

is the real Armory.

And it cannot be taken unless you surrender it.

## Sentinels Are Forged, Not Born

No one is born ready for this path.

No one emerges perfect, prepared, invincible.

Sentinels are made —

through fire, through hardship, through choice.

You are forged when you pick up the weight of responsibility,

when you discipline yourself to truth over comfort,

when you choose honor even when no one sees you.

You are forged every time you:

- Shoulder a fallen brother’s pack,  

- Plant a seed in a burned field,  

- Teach a child how to build, not just how to fight,  

- Step into danger to shield the innocent.  


Sentinels are not made by bloodlines.

They are made by the blood they are willing to protect.

You are not born into the Armory.

You forge yourself into it.

Strike by strike. Breath by breath. Step by step.

And you will leave it stronger than you found it —

for the hands yet to come.

# Carry the Fire.

# Forge the Future.

# Be the Sentinel the world will remember.

