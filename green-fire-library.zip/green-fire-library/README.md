# Green Fire Machine-Readable Library

_Version 2.0.0 · Role: Machine-Readable Knowledge Library_

## Purpose

The complete machine-readable written library of the Green Fire Archive. 33 codices, 1 grimoire(s), 2 saga(s), all current Saga Smith practice and seed documents, and the full reference set. One canonical copy of each published work. Includes a content-index.json with stable content IDs and SHA-256 hashes for every document.

## Structure

```
green-fire-library/
  manifest.json
  README.md
  content-index.json          ← stable content IDs + SHA-256 hashes
  documents/
    codices/                  ← all 33 published codices
    grimoires/                ← all 1 published grimoire(s)
    sagas/                    ← all 2 published saga(s)
    practices/saga-smith/     ← current Field Rule, exercises, seeds, practice docs
    reference/                ← glossary, symbol index, Symbolic Legend, Forge, Field Kernel
```

## For Ember Node

Pair with the **Green Fire Core** (`green-fire-core-cache`) for orientation.
Core is the compact starting layer; this Library is the complete knowledge retrieval layer.
A future Ember Node normally needs both.

## Deduplication

Every published written work appears exactly once. No generated search indexes, no gallery
binaries, no PDF files, no duplicate Markdown/TXT pairs. The `content-index.json` carries
stable content IDs — use these for citation and deduplication across runs.

## Documents (60)

- `content-index.json`
- `documents/codices/early-essays/being-of-vitality.md`
- `documents/codices/early-essays/green-fire-first-spark.md`
- `documents/codices/early-essays/green-fire-forge.md`
- `documents/codices/early-essays/low-tech-wisdom.md`
- `documents/codices/early-essays/sacred-warfare.md`
- `documents/codices/early-essays/sentinels-soul.md`
- `documents/codices/early-essays/strength-of-story.md`
- `documents/codices/foundational-works/green-fire-philosophy.md`
- `documents/codices/foundational-works/grimoire-codices-sagas.md`
- `documents/codices/foundational-works/myth-tech.md`
- `documents/codices/foundational-works/sentinel-archetypes.md`
- `documents/codices/foundational-works/sentinel-armory.md`
- `documents/codices/foundational-works/signal-and-flame.md`
- `documents/codices/foundational-works/symbolic-legend.md`
- `documents/codices/refined-reflections/codex-summus.md`
- `documents/codices/refined-reflections/elemental-living.md`
- `documents/codices/refined-reflections/esoteric-interfaces-reality.md`
- `documents/codices/refined-reflections/fractured-earth.md`
- `documents/codices/refined-reflections/green-fire-dialogues.md`
- `documents/codices/refined-reflections/green-fire-ontological-framework.md`
- `documents/codices/refined-reflections/green-fire-sentinels.md`
- `documents/codices/refined-reflections/hearth-home.md`
- `documents/codices/refined-reflections/left-hand-path.md`
- `documents/codices/refined-reflections/living-sagas.md`
- `documents/codices/refined-reflections/runelore.md`
- `documents/codices/refined-reflections/sentinel-game.md`
- `documents/codices/refined-reflections/spark-and-seed.md`
- `documents/codices/unfolding-philosophies/biomimicry-living-systems.md`
- `documents/codices/unfolding-philosophies/codex-ignis.md`
- `documents/codices/unfolding-philosophies/reflected-flame.md`
- `documents/codices/unfolding-philosophies/sentinel-style.md`
- `documents/codices/unfolding-philosophies/tactical-magic.md`
- `documents/codices/unfolding-philosophies/the-great-contest.md`
- `documents/grimoires/green-fire-grimoire/green-fire-grimoire.md`
- `documents/practices/saga-smith/archetype-seeds.md`
- `documents/practices/saga-smith/cache-bootstrap.md`
- `documents/practices/saga-smith/catalyst-seeds.md`
- `documents/practices/saga-smith/condition-seeds.md`
- `documents/practices/saga-smith/continuity-pressure.md`
- `documents/practices/saga-smith/faction-seeds.md`
- `documents/practices/saga-smith/familiarity-modes.md`
- `documents/practices/saga-smith/field-exercise-template.md`
- `documents/practices/saga-smith/field-exercises.md`
- `documents/practices/saga-smith/field-record.md`
- `documents/practices/saga-smith/field-rule.md`
- `documents/practices/saga-smith/loadout-seeds.md`
- `documents/practices/saga-smith/mythic-pressure-seeds.md`
- `documents/practices/saga-smith/reflective-journaling.md`
- `documents/practices/saga-smith/regional-seeds.md`
- `documents/practices/saga-smith/saga-fragments.md`
- `documents/practices/saga-smith/saga-smith-overview.md`
- `documents/practices/saga-smith/signal-threads.md`
- `documents/practices/saga-smith/world-seeds.md`
- `documents/reference/ember-node-field-kernel.md`
- `documents/reference/ember-node-forge.md`
- `documents/reference/glossary.md`
- `documents/reference/symbol-index.md`
- `documents/sagas/sentinel-sagas/brothers-saga.md`
- `documents/sagas/sentinel-sagas/volume-1-ash-and-bloom.md`

## License

Released under the **Green Fire Covenant** / Creative Commons **CC BY-NC-SA 4.0**.
Share freely, adapt carefully, do not commercially exploit without consent, preserve attribution.

---

ᚲ The Archive preserves the signal.
ᛏ Human meaning remains primary.
