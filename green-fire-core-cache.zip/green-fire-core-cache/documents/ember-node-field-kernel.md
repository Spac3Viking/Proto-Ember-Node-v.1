# Ember Node Field Kernel — Architecture Doctrine

_Green Fire Archive · Reference Document_

## What This Is

This document describes the intended architecture of the Ember Node Field Kernel — a local field operating system built around the Green Fire framework. It is an orientation document, not implementation documentation. Not all instruments described here exist yet.

---

## Division of Authority

| Layer | Authority |
|-------|-----------|
| **Sentinel** | Meaning, judgment, priorities, relationships, and final decisions |
| **Archive** | Long-term knowledge, philosophy, manuals, stories, and references |
| **Ember Node** | Present operational state, local retrieval, coordination, and field tools |
| **Local AI** | Interpretation, synthesis, explanation, and natural-language assistance |
| **Online AI** | Optional heavy research, coding, reasoning, and creative expansion when available |

---

## Primary Doctrine

- **The Sentinel carries meaning.** No system carries that authority in the Sentinel's place.
- **The Archive carries inheritance.** It is the source of long-term knowledge, not the Node.
- **The Node carries the field.** Present state, local records, active tools.
- **The model is replaceable.** Local AI is one instrument among others. A slow model, an absent model, or a different model does not break the Node.
- **Durable authority remains human.** AI should be the adaptive interface, not the load-bearing structure.
- **Every primary instrument must remain manually usable without AI.** A Node that stops working when the model is unavailable has failed its design.
- **Slow local inference is acceptable** when runtime state is honest, cancelable, and visible to the Sentinel.
- **Degraded operation is a normal design condition**, not an exceptional failure mode. Storm outages, network loss, low power, and hardware limits are expected operating contexts.
- **Local records should remain inspectable, portable, and exportable.** The Sentinel can always read, move, and back up their own data.
- **The Node should retain deliberate operational records**, not infer an autonomous psychological model of the Sentinel. Meaning belongs to the Sentinel; the Node holds the field log.

---

## Future Instrument Map

The intended primary instruments of a full Ember Node:

- **FIELD** — present situation, notes, tasks, resources, pressures, and field log
- **ARCHIVE** — trusted local knowledge, search, retrieval, and reading
- **TERRAIN** — offline maps, routes, markers, and geographic observations
- **SIGNAL** — radio, LAN, peer Nodes, messages, contacts, and network state

A small non-primary **System** instrument handles: storage management, package installation, model selection, diagnostics, import, and export.

These instruments are coordinated, not merged. Each has its own data model and can degrade independently.

---

## Operating Contexts

The Field Kernel is designed for the full range of human operating conditions — not only emergencies:

- Home use: research, journaling, family planning, learning
- Field work: surveys, expeditions, remote worksites
- Community use: local organizations, disconnected communities, teaching
- Preparedness: extended outages, infrastructure disruptions
- Travel: low-connectivity environments, border crossings, unfamiliar territory

The system should be useful in routine conditions first. Resilience under pressure is a natural consequence of sound design, not the only design goal.

---

## Boundaries

The Archive is the source of long-term knowledge. The Node is a consumer and field instrument — not the owner of Archive canon. Published works in the Archive are not rewritten to fit the Node's data model; the Node reads and cites them.

Operational records — field logs, maps, contacts, inventories, messages, and personal Signal Threads — belong to the Sentinel's own data and are never part of public Archive packages.

AI-facing metadata should support retrieval and provenance, not prescribe personality or authority.

---

## What This Document Does Not Claim

The four instruments described above do not all exist yet. This document guides the rebuild, not the current state. The Core package and Library package are the first preparatory steps. The Ember Node application will be built separately, after the Archive knowledge layer is clean and current.

---

_CC BY-NC-SA 4.0 — Green Fire Archive_
