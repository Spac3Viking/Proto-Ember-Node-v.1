# Condition Seeds

*What Tightens the Spiral*

Immediate pressure. Examples: Injury, moral debt, weather, time pressure, dependency on failing tech, conflicting loyalties. These are story accelerants.

## Seeds

### 1. The Last Winter

Supplies were calculated incorrectly. Someone will go hungry unless something changes.

### 2. Running on Reserves

Everything still works—barely. Every use brings failure closer.

### 3. Injury Without Relief

A wound that won't kill quickly, but won't heal either. Movement, morale, and time are compromised.

### 4. Moral Debt

A past mercy or betrayal returns demanding repayment.

### 5. Time Compression

A hard deadline with no margin. Waiting is as dangerous as acting.

### 6. Supply Illusion

Resources appear plentiful until distribution collapses.

### 7. Weather Turn

Conditions shift suddenly. Preparation was correct—just not for this.

### 8. Trust Deficit

Recent betrayal or rumor poisons cooperation. Information becomes unreliable.

### 9. Surveillance Shadow

Someone—or something—is watching. Behavior changes even without confirmation.

### 10. Skill Mismatch

The needed expertise is absent. Improvisation becomes mandatory.

### 11. Fatigue Spiral

Sleep deprivation erodes judgment. Small mistakes compound.

### 12. Contested Ground

Every action is observed and potentially challenged.

### 13. Resource Gate

Access to water, power, medicine, or shelter is controlled by another group.

### 14. Delayed Consequence

An earlier decision hasn't paid its price yet—but will.

### 15. False Urgency

Pressure is manufactured or misread. Acting fast may be the mistake.

### 16. Cultural Misstep

An action violates local custom. Repair requires humility—or strength.

### 17. Loadout Failure

A critical tool breaks or proves inadequate at the worst moment.

### 18. Divided Loyalties

Two obligations demand incompatible actions.

### 19. Environmental Hostility

The land itself resists presence. Exposure is cumulative.

### 20. Memory Collapse

Maps, records, or guidance are wrong—or missing.

### 21. Communication Blackout

Coordination fails. Isolation magnifies risk.

### 22. Overwatch Denial

No vantage point. No advance warning. Surprise favors the unseen.

### 23. Innocents in the Way

Action risks collateral harm. Inaction risks worse outcomes.

### 24. Escalation Trap

Any response increases the stakes. De-escalation requires sacrifice.

### 25. Moral Asymmetry

The opposing side doesn't share the same rules—or values.

### 26. Attrition Pressure

Nothing catastrophic happens—just slow erosion of capability.

### 27. Identity Exposure

A secret, symbol, or past action is revealed.

### 28. Leadership Vacuum

Authority disappears suddenly. Decisions still must be made.

### 29. Dependency Revealed

Survival hinges on someone or something unreliable.

### 30. Ritual Breakdown

A stabilizing habit or ceremony fails. Meaning frays.

### 31. False Safety

Shelter exists—but only temporarily.

### 32. Choice Without Clarity

Action must be taken without sufficient information.

### 33. Alignment Test

The correct action ensures survival—but violates core values.

---

*33 seeds. Derived from `client/src/data/saga-seeds.ts`. Re-run `tsx scripts/build-saga-cache-content.ts` after edits.*
